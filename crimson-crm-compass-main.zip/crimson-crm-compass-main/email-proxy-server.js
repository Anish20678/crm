
// ===============================
// EMAIL PROXY SERVER (Option 1)
// ===============================
//
// USAGE:
// 1. npm install express nodemailer cors dotenv
// 2. Create a .env file in the same directory with the following variables:
//    SMTP_HOST=smtp.yourdomain.com
//    SMTP_PORT=465
//    SMTP_SECURE=true
//    SMTP_USER=your@email.com
//    SMTP_PASS=********
// 3. Run server: node email-proxy-server.js
//
// The server will expose POST /send-email. Point your frontend or Lovable app to http://localhost:4000/send-email.
//
// ===============================
const express = require("express");
const cors = require("cors");
const nodemailer = require("nodemailer");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 4000;

// Middleware
app.use(cors());
app.use(express.json());

// POST /send-email => sends SMTP email with user's credentials
app.post("/send-email", async (req, res) => {
  const { to, subject, body } = req.body;

  if (!to || !subject || !body) {
    return res
      .status(400)
      .json({ error: "Missing required fields: to, subject, body" });
  }

  // Create a transporter using provided ENV credentials
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === "true", // true for 465, false for 587
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

  try {
    const info = await transporter.sendMail({
      from: process.env.SMTP_USER,
      to,
      subject,
      text: body,
      html: body.replace(/\n/g, "<br>"), // basic conversion for email clients
    });

    // Respond with the messageId and status
    res.status(200).json({ success: true, messageId: info.messageId });
  } catch (error) {
    console.error("SMTP Proxy Send Error:", error);
    res.status(500).json({ error: error.message });
  }
});

// Health check endpoint
app.get("/", (req, res) => {
  res.send("Email Proxy Server is running!");
});

app.listen(PORT, () => {
  console.log(`Email Proxy Server listening on http://localhost:${PORT}`);
});

