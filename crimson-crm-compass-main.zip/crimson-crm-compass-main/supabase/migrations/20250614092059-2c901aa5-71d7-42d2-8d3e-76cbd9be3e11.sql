
-- Drop existing policies if they exist to avoid conflicts
DROP POLICY IF EXISTS "Users can view their own activities" ON public.activities;
DROP POLICY IF EXISTS "Users can create their own activities" ON public.activities;
DROP POLICY IF EXISTS "Users can update their own activities" ON public.activities;
DROP POLICY IF EXISTS "Users can delete their own activities" ON public.activities;

DROP POLICY IF EXISTS "Users can view their own email templates" ON public.email_templates;
DROP POLICY IF EXISTS "Users can create their own email templates" ON public.email_templates;
DROP POLICY IF EXISTS "Users can update their own email templates" ON public.email_templates;
DROP POLICY IF EXISTS "Users can delete their own email templates" ON public.email_templates;

-- Enable RLS on existing tables
ALTER TABLE public.activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_templates ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for activities
CREATE POLICY "Users can view their own activities" 
  ON public.activities 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own activities" 
  ON public.activities 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own activities" 
  ON public.activities 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own activities" 
  ON public.activities 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Create RLS policies for email templates
CREATE POLICY "Users can view their own email templates" 
  ON public.email_templates 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own email templates" 
  ON public.email_templates 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own email templates" 
  ON public.email_templates 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own email templates" 
  ON public.email_templates 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Add additional columns to activities table for enhanced tracking
ALTER TABLE public.activities 
ADD COLUMN IF NOT EXISTS duration_minutes integer,
ADD COLUMN IF NOT EXISTS location text,
ADD COLUMN IF NOT EXISTS participants text[],
ADD COLUMN IF NOT EXISTS outcome text,
ADD COLUMN IF NOT EXISTS follow_up_required boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS follow_up_date timestamp with time zone,
ADD COLUMN IF NOT EXISTS tags text[];

-- Create activity templates table
CREATE TABLE IF NOT EXISTS public.activity_templates (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  activity_type text NOT NULL DEFAULT 'note',
  template_title text NOT NULL,
  template_description text,
  default_duration_minutes integer,
  is_active boolean DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS for activity templates
ALTER TABLE public.activity_templates ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for activity templates
CREATE POLICY "Users can view their own activity templates" 
  ON public.activity_templates 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own activity templates" 
  ON public.activity_templates 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own activity templates" 
  ON public.activity_templates 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own activity templates" 
  ON public.activity_templates 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Create workflow automation table
CREATE TABLE IF NOT EXISTS public.workflow_automations (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  trigger_type text NOT NULL, -- 'activity_created', 'deal_stage_changed', 'task_completed', etc.
  trigger_conditions jsonb,
  actions jsonb NOT NULL, -- Array of actions to execute
  is_active boolean DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS for workflow automations
ALTER TABLE public.workflow_automations ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for workflow automations
CREATE POLICY "Users can view their own workflow automations" 
  ON public.workflow_automations 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own workflow automations" 
  ON public.workflow_automations 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own workflow automations" 
  ON public.workflow_automations 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own workflow automations" 
  ON public.workflow_automations 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_activities_user_id_date ON public.activities(user_id, activity_date DESC);
CREATE INDEX IF NOT EXISTS idx_activities_type ON public.activities(activity_type);
CREATE INDEX IF NOT EXISTS idx_email_templates_user_type ON public.email_templates(user_id, template_type);
CREATE INDEX IF NOT EXISTS idx_workflow_automations_user_active ON public.workflow_automations(user_id, is_active);
