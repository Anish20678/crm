
-- Table to define custom fields per user/module
CREATE TABLE public.custom_fields (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  module TEXT NOT NULL, -- e.g., 'lead', 'deal', 'contact', 'task'
  name TEXT NOT NULL, -- Internal name (for referencing in code)
  label TEXT NOT NULL, -- What is shown in the UI
  field_type TEXT NOT NULL, -- e.g.: 'text', 'number', 'date', 'boolean', 'select'
  options JSONB, -- for select fields, e.g. ['A', 'B']
  required BOOLEAN DEFAULT FALSE,
  visible BOOLEAN DEFAULT TRUE,
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Table to store values of fields per entity instance (record_id)
CREATE TABLE public.custom_field_values (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  module TEXT NOT NULL,
  record_id UUID NOT NULL, -- PK of entity (lead, deal, etc.)
  field_id UUID NOT NULL REFERENCES public.custom_fields(id) ON DELETE CASCADE,
  value TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Row Level Security: allow users only access to their own fields and values
ALTER TABLE public.custom_fields ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.custom_field_values ENABLE ROW LEVEL SECURITY;

-- Select/Update/Delete/Insert: only if user_id matches auth.uid()
CREATE POLICY "user_can_crud_own_fields"
  ON public.custom_fields
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "user_can_crud_own_field_values"
  ON public.custom_field_values
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());
