
-- Phase 1: Clean up orphaned system field configurations for lead module
DELETE FROM system_field_configs WHERE module = 'lead';

-- Phase 2: Update the create_default_field_groups function to exclude lead module system groups
CREATE OR REPLACE FUNCTION public.create_default_field_groups(target_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Lead module now has no default system groups - fully customizable
  -- Users can create their own groups as needed
  
  -- Contact module groups  
  INSERT INTO public.field_groups (id, user_id, module, label, description, default_expanded, group_order, is_system) VALUES
  ('basic', target_user_id, 'contact', 'Basic Information', 'Core contact details', true, 0, true),
  ('business', target_user_id, 'contact', 'Business Details', 'Company and professional information', true, 1, true),
  ('custom', target_user_id, 'contact', 'Custom Fields', 'User-defined custom fields', false, 2, true)
  ON CONFLICT (user_id, module, id) DO NOTHING;

  -- Deal module groups
  INSERT INTO public.field_groups (id, user_id, module, label, description, default_expanded, group_order, is_system) VALUES
  ('basic', target_user_id, 'deal', 'Basic Information', 'Core deal details', true, 0, true),
  ('project', target_user_id, 'deal', 'Project Details', 'Project scope and requirements', true, 1, true),
  ('timeline', target_user_id, 'deal', 'Timeline & Delivery', 'Dates and milestones', false, 2, true),
  ('payment', target_user_id, 'deal', 'Payment Information', 'Financial and payment details', false, 3, true),
  ('custom', target_user_id, 'deal', 'Custom Fields', 'User-defined custom fields', false, 4, true)
  ON CONFLICT (user_id, module, id) DO NOTHING;

  -- Task module groups
  INSERT INTO public.field_groups (id, user_id, module, label, description, default_expanded, group_order, is_system) VALUES
  ('basic', target_user_id, 'task', 'Basic Information', 'Core task details', true, 0, true),
  ('assignment', target_user_id, 'task', 'Assignment & Priority', 'Assignment and priority settings', true, 1, true),
  ('relations', target_user_id, 'task', 'Related Items', 'Related contacts and deals', false, 2, true),
  ('custom', target_user_id, 'task', 'Custom Fields', 'User-defined custom fields', false, 3, true)
  ON CONFLICT (user_id, module, id) DO NOTHING;
END;
$$;

-- Phase 3: Clean up any lead system field groups that might still exist
-- Remove system field groups for lead module (keep custom ones)
DELETE FROM field_groups 
WHERE module = 'lead' 
AND is_system = true 
AND id IN ('basic', 'business', 'tracking', 'notes');

-- Phase 4: Ensure leads table has proper RLS policies (already exists from previous migration)
-- The leads table and its policies are already in place, so no changes needed

-- Phase 5: Add indexes for better performance on leads table
CREATE INDEX IF NOT EXISTS idx_leads_user_id ON leads(user_id);
CREATE INDEX IF NOT EXISTS idx_leads_created_at ON leads(created_at);
