
-- DELETE policy for custom_field_values
CREATE POLICY "user_can_delete_own_field_values"
  ON public.custom_field_values
  FOR DELETE
  USING (user_id = auth.uid());
