
-- Create proposals table
CREATE TABLE public.proposals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  contact_id UUID REFERENCES public.contacts(id),
  title TEXT NOT NULL,
  content JSONB NOT NULL DEFAULT '{}',
  brand_guidelines JSONB DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'draft',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  sent_at TIMESTAMP WITH TIME ZONE,
  viewed_at TIMESTAMP WITH TIME ZONE,
  accepted_at TIMESTAMP WITH TIME ZONE,
  expires_at TIMESTAMP WITH TIME ZONE,
  template_id UUID,
  metadata JSONB DEFAULT '{}'
);

-- Create proposal templates table
CREATE TABLE public.proposal_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  content JSONB NOT NULL DEFAULT '{}',
  brand_guidelines JSONB DEFAULT '{}',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create brand guidelines table
CREATE TABLE public.brand_guidelines (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  name TEXT NOT NULL,
  colors JSONB DEFAULT '{}',
  fonts JSONB DEFAULT '{}',
  logo_url TEXT,
  brand_voice TEXT,
  guidelines_content JSONB DEFAULT '{}',
  is_default BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.proposals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.proposal_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.brand_guidelines ENABLE ROW LEVEL SECURITY;

-- RLS policies for proposals
CREATE POLICY "Users can view their own proposals" 
  ON public.proposals 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own proposals" 
  ON public.proposals 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own proposals" 
  ON public.proposals 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own proposals" 
  ON public.proposals 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- RLS policies for proposal templates
CREATE POLICY "Users can view their own proposal templates" 
  ON public.proposal_templates 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own proposal templates" 
  ON public.proposal_templates 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own proposal templates" 
  ON public.proposal_templates 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own proposal templates" 
  ON public.proposal_templates 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- RLS policies for brand guidelines
CREATE POLICY "Users can view their own brand guidelines" 
  ON public.brand_guidelines 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own brand guidelines" 
  ON public.brand_guidelines 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own brand guidelines" 
  ON public.brand_guidelines 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own brand guidelines" 
  ON public.brand_guidelines 
  FOR DELETE 
  USING (auth.uid() = user_id);
