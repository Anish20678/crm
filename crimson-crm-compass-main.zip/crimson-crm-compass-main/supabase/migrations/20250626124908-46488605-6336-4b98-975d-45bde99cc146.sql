
-- Remove system field dependencies for leads module
-- Update field_groups table to remove system constraints for leads
UPDATE field_groups 
SET is_system = false 
WHERE module = 'lead' AND is_system = true;

-- Create a new table to store lead records with only essential fields
CREATE TABLE IF NOT EXISTS leads (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on leads table
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

-- Create policies for leads table
CREATE POLICY "Users can view their own leads" 
  ON leads 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own leads" 
  ON leads 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own leads" 
  ON leads 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own leads" 
  ON leads 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Migrate existing contacts data to leads (if any exist)
INSERT INTO leads (id, user_id, created_at, updated_at)
SELECT id, user_id, created_at, updated_at 
FROM contacts 
WHERE user_id IS NOT NULL
ON CONFLICT (id) DO NOTHING;

-- Update custom_field_values to reference leads for lead module
UPDATE custom_field_values 
SET module = 'lead' 
WHERE module = 'contact' AND record_id IN (
  SELECT id FROM contacts WHERE user_id IS NOT NULL
);

-- Remove all lead-related system field configurations to start fresh
DELETE FROM system_field_configs WHERE module = 'lead';

-- Clear any existing lead field groups to start fresh
DELETE FROM field_groups WHERE module = 'lead';
