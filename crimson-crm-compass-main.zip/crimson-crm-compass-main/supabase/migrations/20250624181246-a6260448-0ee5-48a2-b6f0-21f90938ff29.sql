
-- Add deal-related columns to the tasks table
ALTER TABLE public.tasks 
ADD COLUMN deal_id uuid REFERENCES public.deals(id) ON DELETE SET NULL;

-- Add new task statuses for deal-related tasks
-- Note: We're not adding a constraint here to allow flexibility
-- The frontend will handle the validation of allowed statuses

-- Create an index for better performance when filtering tasks by deal
CREATE INDEX IF NOT EXISTS idx_tasks_deal_id ON public.tasks(deal_id);

-- Create an index for better performance when filtering by status and deal
CREATE INDEX IF NOT EXISTS idx_tasks_status_deal ON public.tasks(status, deal_id);
