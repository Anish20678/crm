
-- Create field_groups table to store custom field groups
CREATE TABLE public.field_groups (
  id TEXT PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  module TEXT NOT NULL,
  label TEXT NOT NULL,
  description TEXT,
  default_expanded BOOLEAN DEFAULT true,
  group_order INTEGER DEFAULT 0,
  is_system BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, module, id)
);

-- Enable RLS
ALTER TABLE public.field_groups ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view their own field groups"
  ON public.field_groups
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own field groups"
  ON public.field_groups
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own field groups"
  ON public.field_groups
  FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own field groups"
  ON public.field_groups
  FOR DELETE
  USING (auth.uid() = user_id AND is_system = false);

-- Insert default system field groups for each module
INSERT INTO public.field_groups (id, user_id, module, label, description, default_expanded, group_order, is_system) VALUES
-- Lead module groups
('basic', (SELECT id FROM auth.users LIMIT 1), 'lead', 'Basic Information', 'Core lead details and contact information', true, 0, true),
('business', (SELECT id FROM auth.users LIMIT 1), 'lead', 'Business Details', 'Company and business-related information', true, 1, true),
('tracking', (SELECT id FROM auth.users LIMIT 1), 'lead', 'Lead Tracking', 'Source, campaign and tracking details', false, 2, true),
('notes', (SELECT id FROM auth.users LIMIT 1), 'lead', 'Notes & Communication', 'Call notes and communication history', false, 3, true),
('custom', (SELECT id FROM auth.users LIMIT 1), 'lead', 'Custom Fields', 'User-defined custom fields', false, 4, true),

-- Contact module groups  
('basic', (SELECT id FROM auth.users LIMIT 1), 'contact', 'Basic Information', 'Core contact details', true, 0, true),
('business', (SELECT id FROM auth.users LIMIT 1), 'contact', 'Business Details', 'Company and professional information', true, 1, true),
('custom', (SELECT id FROM auth.users LIMIT 1), 'contact', 'Custom Fields', 'User-defined custom fields', false, 2, true),

-- Deal module groups
('basic', (SELECT id FROM auth.users LIMIT 1), 'deal', 'Basic Information', 'Core deal details', true, 0, true),
('project', (SELECT id FROM auth.users LIMIT 1), 'deal', 'Project Details', 'Project scope and requirements', true, 1, true),
('timeline', (SELECT id FROM auth.users LIMIT 1), 'deal', 'Timeline & Delivery', 'Dates and milestones', false, 2, true),
('payment', (SELECT id FROM auth.users LIMIT 1), 'deal', 'Payment Information', 'Financial and payment details', false, 3, true),
('custom', (SELECT id FROM auth.users LIMIT 1), 'deal', 'Custom Fields', 'User-defined custom fields', false, 4, true),

-- Task module groups
('basic', (SELECT id FROM auth.users LIMIT 1), 'task', 'Basic Information', 'Core task details', true, 0, true),
('assignment', (SELECT id FROM auth.users LIMIT 1), 'task', 'Assignment & Priority', 'Assignment and priority settings', true, 1, true),
('relations', (SELECT id FROM auth.users LIMIT 1), 'task', 'Related Items', 'Related contacts and deals', false, 2, true),
('custom', (SELECT id FROM auth.users LIMIT 1), 'task', 'Custom Fields', 'User-defined custom fields', false, 3, true);
