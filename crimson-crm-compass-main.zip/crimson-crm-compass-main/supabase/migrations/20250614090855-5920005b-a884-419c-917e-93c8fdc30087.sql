
-- Drop existing policies if they exist (using IF EXISTS to avoid errors)
DROP POLICY IF EXISTS "Users can view their own contacts" ON public.contacts;
DROP POLICY IF EXISTS "Users can create their own contacts" ON public.contacts;
DROP POLICY IF EXISTS "Users can update their own contacts" ON public.contacts;
DROP POLICY IF EXISTS "Users can delete their own contacts" ON public.contacts;

DROP POLICY IF EXISTS "Users can view deals for their contacts" ON public.deals;
DROP POLICY IF EXISTS "Users can create deals for their contacts" ON public.deals;
DROP POLICY IF EXISTS "Users can update deals for their contacts" ON public.deals;
DROP POLICY IF EXISTS "Users can delete deals for their contacts" ON public.deals;

DROP POLICY IF EXISTS "Users can view their own tasks" ON public.tasks;
DROP POLICY IF EXISTS "Users can create their own tasks" ON public.tasks;
DROP POLICY IF EXISTS "Users can update their own tasks" ON public.tasks;
DROP POLICY IF EXISTS "Users can delete their own tasks" ON public.tasks;

-- Enable RLS on all tables that don't have it yet
ALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deals ENABLE ROW LEVEL SECURITY; 
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for contacts table
CREATE POLICY "Users can view their own contacts" ON public.contacts
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own contacts" ON public.contacts
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own contacts" ON public.contacts
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own contacts" ON public.contacts
  FOR DELETE USING (auth.uid() = user_id);

-- Create RLS policies for deals table
CREATE POLICY "Users can view deals for their contacts" ON public.deals
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.contacts 
      WHERE contacts.id = deals.contact_id 
      AND contacts.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create deals for their contacts" ON public.deals
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.contacts 
      WHERE contacts.id = deals.contact_id 
      AND contacts.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update deals for their contacts" ON public.deals
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.contacts 
      WHERE contacts.id = deals.contact_id 
      AND contacts.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete deals for their contacts" ON public.deals
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM public.contacts 
      WHERE contacts.id = deals.contact_id 
      AND contacts.user_id = auth.uid()
    )
  );

-- Create RLS policies for tasks table
CREATE POLICY "Users can view their own tasks" ON public.tasks
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own tasks" ON public.tasks
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own tasks" ON public.tasks
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own tasks" ON public.tasks
  FOR DELETE USING (auth.uid() = user_id);

-- Create activities table for tracking interactions
CREATE TABLE IF NOT EXISTS public.activities (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  related_to_type text NOT NULL,
  related_to_id uuid NOT NULL,
  activity_type text NOT NULL DEFAULT 'note',
  title text NOT NULL,
  description text,
  activity_date timestamp with time zone DEFAULT now(),
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Enable RLS on activities table
ALTER TABLE public.activities ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for activities table
CREATE POLICY "Users can view their own activities" ON public.activities
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own activities" ON public.activities
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own activities" ON public.activities
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own activities" ON public.activities
  FOR DELETE USING (auth.uid() = user_id);

-- Create email templates table
CREATE TABLE IF NOT EXISTS public.email_templates (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  subject text NOT NULL,
  body text NOT NULL,
  template_type text DEFAULT 'general',
  is_active boolean DEFAULT true,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Enable RLS on email templates table
ALTER TABLE public.email_templates ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for email templates table
CREATE POLICY "Users can view their own email templates" ON public.email_templates
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own email templates" ON public.email_templates
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own email templates" ON public.email_templates
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own email templates" ON public.email_templates
  FOR DELETE USING (auth.uid() = user_id);

-- Create pipeline stages table for deal progression
CREATE TABLE IF NOT EXISTS public.pipeline_stages (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  stage_order integer NOT NULL,
  color text DEFAULT '#3b82f6',
  is_active boolean DEFAULT true,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(user_id, stage_order)
);

-- Enable RLS on pipeline stages table
ALTER TABLE public.pipeline_stages ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for pipeline stages table
CREATE POLICY "Users can view their own pipeline stages" ON public.pipeline_stages
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own pipeline stages" ON public.pipeline_stages
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own pipeline stages" ON public.pipeline_stages
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own pipeline stages" ON public.pipeline_stages
  FOR DELETE USING (auth.uid() = user_id);
