
-- Create system_field_configs table to manage system field visibility and settings
CREATE TABLE public.system_field_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  module TEXT NOT NULL, -- e.g., 'lead', 'deal', 'contact', 'task'
  field_name TEXT NOT NULL, -- e.g., 'first_name', 'last_name', 'email'
  is_visible BOOLEAN DEFAULT TRUE,
  is_required BOOLEAN DEFAULT FALSE,
  field_order INTEGER DEFAULT 0,
  width_percentage INTEGER DEFAULT 100 CHECK (width_percentage > 0 AND width_percentage <= 100),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, module, field_name)
);

-- Enable RLS
ALTER TABLE public.system_field_configs ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "user_can_crud_own_system_field_configs"
  ON public.system_field_configs
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Insert default system field configurations for common modules
-- This will be populated via code for existing users, but new users will get defaults
