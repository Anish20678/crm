
-- Create email_settings table
CREATE TABLE public.email_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  from_name TEXT,
  from_email TEXT,
  reply_to_email TEXT,
  signature TEXT,
  track_opens BOOLEAN DEFAULT false,
  track_clicks BOOLEAN DEFAULT false,
  enable_auto_responder BOOLEAN DEFAULT false,
  bounce_handling BOOLEAN DEFAULT false,
  unsubscribe_link BOOLEAN DEFAULT true,
  daily_email_limit INTEGER DEFAULT 1000,
  time_zone TEXT DEFAULT 'UTC',
  sending_frequency TEXT DEFAULT 'normal',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add Row Level Security (RLS)
ALTER TABLE public.email_settings ENABLE ROW LEVEL SECURITY;

-- Create policies for email_settings
CREATE POLICY "Users can view their own email settings" 
  ON public.email_settings 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own email settings" 
  ON public.email_settings 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own email settings" 
  ON public.email_settings 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own email settings" 
  ON public.email_settings 
  FOR DELETE 
  USING (auth.uid() = user_id);
