
-- Add field grouping support to system_field_configs table
ALTER TABLE public.system_field_configs 
ADD COLUMN field_group TEXT DEFAULT 'basic',
ADD COLUMN group_order INTEGER DEFAULT 0;

-- Update existing records to have a default group
UPDATE public.system_field_configs 
SET field_group = 'basic', group_order = 0 
WHERE field_group IS NULL;

-- Add field grouping support to custom_fields table
ALTER TABLE public.custom_fields 
ADD COLUMN field_group TEXT DEFAULT 'custom',
ADD COLUMN group_order INTEGER DEFAULT 0;

-- Update existing custom fields to have a default group
UPDATE public.custom_fields 
SET field_group = 'custom', group_order = 0 
WHERE field_group IS NULL;

-- Create index for better performance on field ordering
CREATE INDEX idx_system_field_configs_order ON public.system_field_configs(user_id, module, field_group, group_order, field_order);
CREATE INDEX idx_custom_fields_order ON public.custom_fields(user_id, module, field_group, group_order, order_index);
