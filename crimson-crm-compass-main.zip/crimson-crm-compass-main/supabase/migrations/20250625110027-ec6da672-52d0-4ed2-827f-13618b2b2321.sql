
-- Create the field_groups table
CREATE TABLE IF NOT EXISTS public.field_groups (
    id TEXT NOT NULL,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    module TEXT NOT NULL,
    label TEXT NOT NULL,
    description TEXT,
    default_expanded BOOLEAN NOT NULL DEFAULT true,
    group_order INTEGER NOT NULL DEFAULT 0,
    is_system BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, module, id)
);

-- Enable Row Level Security
ALTER TABLE public.field_groups ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for field_groups
CREATE POLICY "Users can view their own field groups" 
    ON public.field_groups 
    FOR SELECT 
    USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own field groups" 
    ON public.field_groups 
    FOR INSERT 
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own field groups" 
    ON public.field_groups 
    FOR UPDATE 
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own field groups" 
    ON public.field_groups 
    FOR DELETE 
    USING (auth.uid() = user_id);

-- Create a function to insert default field groups for a user
CREATE OR REPLACE FUNCTION public.create_default_field_groups(target_user_id UUID)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Insert default system field groups for each module
  
  -- Lead module groups
  INSERT INTO public.field_groups (id, user_id, module, label, description, default_expanded, group_order, is_system) VALUES
  ('basic', target_user_id, 'lead', 'Basic Information', 'Core lead details and contact information', true, 0, true),
  ('business', target_user_id, 'lead', 'Business Details', 'Company and business-related information', true, 1, true),
  ('tracking', target_user_id, 'lead', 'Lead Tracking', 'Source, campaign and tracking details', false, 2, true),
  ('notes', target_user_id, 'lead', 'Notes & Communication', 'Call notes and communication history', false, 3, true),
  ('custom', target_user_id, 'lead', 'Custom Fields', 'User-defined custom fields', false, 4, true)
  ON CONFLICT (user_id, module, id) DO NOTHING;

  -- Contact module groups  
  INSERT INTO public.field_groups (id, user_id, module, label, description, default_expanded, group_order, is_system) VALUES
  ('basic', target_user_id, 'contact', 'Basic Information', 'Core contact details', true, 0, true),
  ('business', target_user_id, 'contact', 'Business Details', 'Company and professional information', true, 1, true),
  ('custom', target_user_id, 'contact', 'Custom Fields', 'User-defined custom fields', false, 2, true)
  ON CONFLICT (user_id, module, id) DO NOTHING;

  -- Deal module groups
  INSERT INTO public.field_groups (id, user_id, module, label, description, default_expanded, group_order, is_system) VALUES
  ('basic', target_user_id, 'deal', 'Basic Information', 'Core deal details', true, 0, true),
  ('project', target_user_id, 'deal', 'Project Details', 'Project scope and requirements', true, 1, true),
  ('timeline', target_user_id, 'deal', 'Timeline & Delivery', 'Dates and milestones', false, 2, true),
  ('payment', target_user_id, 'deal', 'Payment Information', 'Financial and payment details', false, 3, true),
  ('custom', target_user_id, 'deal', 'Custom Fields', 'User-defined custom fields', false, 4, true)
  ON CONFLICT (user_id, module, id) DO NOTHING;

  -- Task module groups
  INSERT INTO public.field_groups (id, user_id, module, label, description, default_expanded, group_order, is_system) VALUES
  ('basic', target_user_id, 'task', 'Basic Information', 'Core task details', true, 0, true),
  ('assignment', target_user_id, 'task', 'Assignment & Priority', 'Assignment and priority settings', true, 1, true),
  ('relations', target_user_id, 'task', 'Related Items', 'Related contacts and deals', false, 2, true),
  ('custom', target_user_id, 'task', 'Custom Fields', 'User-defined custom fields', false, 3, true)
  ON CONFLICT (user_id, module, id) DO NOTHING;
END;
$$;

-- Create a trigger function to automatically create default field groups for new users
CREATE OR REPLACE FUNCTION public.handle_new_user_field_groups()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Create default field groups for the new user
  PERFORM public.create_default_field_groups(NEW.id);
  RETURN NEW;
END;
$$;

-- Create the trigger on the profiles table (since that's where new users are created)
DROP TRIGGER IF EXISTS create_field_groups_for_new_user ON public.profiles;
CREATE TRIGGER create_field_groups_for_new_user
  AFTER INSERT ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user_field_groups();

-- Create default field groups for all existing users
DO $$
DECLARE
  user_record RECORD;
BEGIN
  FOR user_record IN SELECT id FROM public.profiles LOOP
    PERFORM public.create_default_field_groups(user_record.id);
  END LOOP;
END $$;
