
-- Add Row Level Security policies for system_field_configs table
ALTER TABLE public.system_field_configs ENABLE ROW LEVEL SECURITY;

-- Create policy that allows users to view their own field configurations
CREATE POLICY "Users can view their own field configs" 
  ON public.system_field_configs 
  FOR SELECT 
  USING (auth.uid() = user_id);

-- Create policy that allows users to create their own field configurations
CREATE POLICY "Users can create their own field configs" 
  ON public.system_field_configs 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Create policy that allows users to update their own field configurations
CREATE POLICY "Users can update their own field configs" 
  ON public.system_field_configs 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Create policy that allows users to delete their own field configurations
CREATE POLICY "Users can delete their own field configs" 
  ON public.system_field_configs 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Add RLS policies for custom_fields table if not already done
ALTER TABLE public.custom_fields ENABLE ROW LEVEL SECURITY;

-- Create policies for custom_fields
CREATE POLICY "Users can view their own custom fields" 
  ON public.custom_fields 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own custom fields" 
  ON public.custom_fields 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own custom fields" 
  ON public.custom_fields 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own custom fields" 
  ON public.custom_fields 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Add RLS policies for custom_field_values table if not already done
ALTER TABLE public.custom_field_values ENABLE ROW LEVEL SECURITY;

-- Create policies for custom_field_values
CREATE POLICY "Users can view their own custom field values" 
  ON public.custom_field_values 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own custom field values" 
  ON public.custom_field_values 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own custom field values" 
  ON public.custom_field_values 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own custom field values" 
  ON public.custom_field_values 
  FOR DELETE 
  USING (auth.uid() = user_id);
