
-- Allow new field types in custom_fields (just document intent, no column changes needed as field_type is text)
-- No SQL migration is actually required for adding logical types, as 'field_type' is already TEXT

-- (Optional but recommended) Add comment for future reference:
COMMENT ON COLUMN public.custom_fields.field_type IS
  'Allowed values: text, number, textarea, date, boolean, select, url, phone, currency';

-- (Optional) If you want to enforce values, add a check constraint. Uncomment to enforce:
-- ALTER TABLE public.custom_fields
--   ADD CONSTRAINT allowed_field_types CHECK (field_type IN ('text', 'number', 'textarea', 'date', 'boolean', 'select', 'url', 'phone', 'currency'));
