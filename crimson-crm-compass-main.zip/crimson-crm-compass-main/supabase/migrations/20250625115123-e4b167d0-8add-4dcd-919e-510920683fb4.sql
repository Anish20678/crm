
-- Add conditional visibility and validation tables for advanced field capabilities

-- Table for field validation rules
CREATE TABLE public.field_validation_rules (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  module TEXT NOT NULL,
  field_name TEXT NOT NULL,
  rule_type TEXT NOT NULL, -- 'required_if', 'min_length', 'max_length', 'regex', 'custom'
  rule_config JSONB NOT NULL DEFAULT '{}', -- Configuration for the rule
  error_message TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT unique_field_validation UNIQUE(user_id, module, field_name, rule_type)
);

-- Table for conditional field visibility
CREATE TABLE public.field_conditional_visibility (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  module TEXT NOT NULL,
  field_name TEXT NOT NULL,
  condition_type TEXT NOT NULL, -- 'field_value', 'field_empty', 'field_not_empty', 'custom'
  condition_config JSONB NOT NULL DEFAULT '{}', -- Configuration for the condition
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT unique_field_condition UNIQUE(user_id, module, field_name, condition_type)
);

-- Table for field templates and presets
CREATE TABLE public.field_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  template_name TEXT NOT NULL,
  template_type TEXT NOT NULL, -- 'field_group', 'complete_module', 'field_set'
  module TEXT NOT NULL,
  template_config JSONB NOT NULL DEFAULT '{}', -- Configuration for fields, groups, etc.
  description TEXT,
  is_system_template BOOLEAN NOT NULL DEFAULT false,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT unique_user_template UNIQUE(user_id, template_name, module)
);

-- Table for bulk operations history
CREATE TABLE public.field_bulk_operations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  operation_type TEXT NOT NULL, -- 'visibility_change', 'group_assignment', 'validation_rule', 'template_apply'
  module TEXT NOT NULL,
  affected_fields JSONB NOT NULL DEFAULT '[]', -- Array of field names affected
  operation_config JSONB NOT NULL DEFAULT '{}', -- Operation details
  status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'completed', 'failed'
  error_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS on new tables
ALTER TABLE public.field_validation_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.field_conditional_visibility ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.field_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.field_bulk_operations ENABLE ROW LEVEL SECURITY;

-- RLS policies for field_validation_rules
CREATE POLICY "Users can view their own validation rules" 
  ON public.field_validation_rules 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own validation rules" 
  ON public.field_validation_rules 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own validation rules" 
  ON public.field_validation_rules 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own validation rules" 
  ON public.field_validation_rules 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- RLS policies for field_conditional_visibility
CREATE POLICY "Users can view their own visibility conditions" 
  ON public.field_conditional_visibility 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own visibility conditions" 
  ON public.field_conditional_visibility 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own visibility conditions" 
  ON public.field_conditional_visibility 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own visibility conditions" 
  ON public.field_conditional_visibility 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- RLS policies for field_templates
CREATE POLICY "Users can view their own templates and system templates" 
  ON public.field_templates 
  FOR SELECT 
  USING (auth.uid() = user_id OR is_system_template = true);

CREATE POLICY "Users can create their own templates" 
  ON public.field_templates 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own templates" 
  ON public.field_templates 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own templates" 
  ON public.field_templates 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- RLS policies for field_bulk_operations
CREATE POLICY "Users can view their own bulk operations" 
  ON public.field_bulk_operations 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own bulk operations" 
  ON public.field_bulk_operations 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own bulk operations" 
  ON public.field_bulk_operations 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Insert some system templates for common field configurations
INSERT INTO public.field_templates (
  user_id, 
  template_name, 
  template_type, 
  module, 
  template_config, 
  description, 
  is_system_template
) VALUES
  (
    '00000000-0000-0000-0000-000000000000', 
    'Sales Lead Template', 
    'complete_module', 
    'lead',
    '{"groups": [{"id": "basic", "fields": ["first_name", "last_name", "email", "phone"]}, {"id": "business", "fields": ["company", "business_type", "emirates"]}], "validations": [{"field": "email", "type": "required_if", "condition": {"field": "status", "value": "qualified"}}]}',
    'Standard template for sales leads with essential fields and validations',
    true
  ),
  (
    '00000000-0000-0000-0000-000000000000', 
    'Contact Management Template', 
    'complete_module', 
    'contact',
    '{"groups": [{"id": "basic", "fields": ["first_name", "last_name", "email", "phone"]}, {"id": "business", "fields": ["company", "position"]}]}',
    'Basic template for contact management',
    true
  ),
  (
    '00000000-0000-0000-0000-000000000000', 
    'Deal Tracking Template', 
    'complete_module', 
    'deal',
    '{"groups": [{"id": "basic", "fields": ["name", "amount", "status"]}, {"id": "project", "fields": ["project_type", "service_package", "project_scope"]}]}',
    'Standard template for deal tracking and management',
    true
  );
