
import {
  LayoutDashboard,
  Briefcase,
  Contact2,
  BadgeDollarSign,
  CheckSquare,
  Activity,
  Mail,
  Brain,
  MessagesSquare,
  LineChart,
  FileBarChart,
  User,
  Building2,
  Users,
  CreditCard,
  Settings,
  Import,
  Grid2X2
  // Removed: Export
} from "lucide-react";

export const navigation = [
  {
    title: "Dashboard",
    icon: LayoutDashboard,
    href: "/",
  },
  {
    title: "Workspace",
    icon: Briefcase,
    items: [
      { title: "Leads", icon: Contact2, href: "/leads" },
      { title: "Deals", icon: BadgeDollarSign, href: "/deals" },
      { title: "Contacts", icon: User, href: "/contacts" },
      { title: "Tasks", icon: CheckSquare, href: "/tasks" },
      { title: "Activities", icon: Activity, href: "/activities" },
      { title: "Proposals", icon: FileBarChart, href: "/proposals" },
      { title: "Emails", icon: Mail, href: "/emails" },
      // Use Import icon for Import/Export (since Export is not available)
      { title: "Import/Export", icon: Import, href: "/import-export" },
    ],
  },
  {
    title: "Intelligence",
    icon: Brain,
    items: [
      { title: "AI Assistant", icon: MessagesSquare, href: "/ai-assistant" },
    ],
  },
  {
    title: "Insights",
    icon: LineChart,
    items: [
      { title: "Reports", icon: FileBarChart, href: "/reports" },
    ],
  },
  {
    title: "Settings",
    icon: Settings,
    items: [
      { title: "Profile", icon: User, href: "/profile" },
      { title: "Module Editor", icon: Grid2X2, href: "/module-editor" },
    ],
  },
];
