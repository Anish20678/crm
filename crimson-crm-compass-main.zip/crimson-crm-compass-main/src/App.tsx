
import { Routes, Route, Navigate } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { AuthProvider } from "@/contexts/AuthContext";
import { ThemeProvider } from "@/components/ThemeProvider";
import { AuthGuard } from "@/components/AuthGuard";
import { Layout } from "@/components/layout/Layout";
import Index from "@/pages/Index";
import Auth from "@/pages/Auth";
import Profile from "@/pages/Profile";
import ResetPassword from "@/pages/ResetPassword";
import NotFound from "@/pages/NotFound";
import Leads from "@/pages/Leads";
import LeadFormPage from "@/pages/LeadForm";
import DynamicLeadFormPage from "@/pages/DynamicLeadForm";
import LeadDetailsPage from "@/pages/LeadDetailsPage";
import Deals from "@/pages/Deals";
import DealForm from "@/pages/DealForm";
import DealDetails from "@/pages/DealDetails";
import Contacts from "@/pages/Contacts";
import ContactForm from "@/pages/ContactForm";
import ContactDetails from "@/pages/ContactDetails";
import Tasks from "@/pages/Tasks";
import TaskForm from "@/pages/TaskForm";
import TaskDetails from "@/pages/TaskDetails";
import Activities from "@/pages/Activities";
import ActivityFormPage from "@/pages/ActivityForm";
import Communications from "@/pages/Communications";
import Automation from "@/pages/Automation";
import Emails from "@/pages/Emails";
import Proposals from "@/pages/Proposals";
import ProposalEdit from "@/pages/ProposalEdit";
import FieldsEditorPage from "@/pages/FieldsEditor";
import AdvancedFieldEditor from "@/pages/AdvancedFieldEditor";
import ModuleEditor from "@/pages/ModuleEditor";
import ImportExportPage from "@/pages/ImportExport";
import { Toaster } from "@/components/ui/toaster";

const queryClient = new QueryClient();

function App() {
  return (
    <ThemeProvider defaultTheme="system" storageKey="vite-react-theme">
      <AuthProvider>
        <QueryClientProvider client={queryClient}>
          <Routes>
            <Route
              path="/"
              element={
                <AuthGuard>
                  <Layout>
                    <Index />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route path="/auth" element={<Auth />} />
            <Route
              path="/profile"
              element={
                <AuthGuard>
                  <Layout>
                    <Profile />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route
              path="/leads"
              element={
                <AuthGuard>
                  <Layout>
                    <Leads />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/leads/add"
              element={
                <AuthGuard>
                  <Layout>
                    <DynamicLeadFormPage />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/leads/add-static"
              element={
                <AuthGuard>
                  <Layout>
                    <LeadFormPage />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/leads/edit/:id"
              element={
                <AuthGuard>
                  <Layout>
                    <DynamicLeadFormPage />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/leads/:id"
              element={
                <AuthGuard>
                  <Layout>
                    <LeadDetailsPage />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/deals"
              element={
                <AuthGuard>
                  <Layout>
                    <Deals />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/deals/add"
              element={
                <AuthGuard>
                  <Layout>
                    <DealForm />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/deals/edit/:id"
              element={
                <AuthGuard>
                  <Layout>
                    <DealForm />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/deals/:id"
              element={
                <AuthGuard>
                  <Layout>
                    <DealDetails />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/contacts"
              element={
                <AuthGuard>
                  <Layout>
                    <Contacts />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/contacts/add"
              element={
                <AuthGuard>
                  <Layout>
                    <ContactForm />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/contacts/edit/:id"
              element={
                <AuthGuard>
                  <Layout>
                    <ContactForm />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/contacts/:id"
              element={
                <AuthGuard>
                  <Layout>
                    <ContactDetails />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/tasks"
              element={
                <AuthGuard>
                  <Layout>
                    <Tasks />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/tasks/add"
              element={
                <AuthGuard>
                  <Layout>
                    <TaskForm />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/tasks/edit/:id"
              element={
                <AuthGuard>
                  <Layout>
                    <TaskForm />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/tasks/:id"
              element={
                <AuthGuard>
                  <Layout>
                    <TaskDetails />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/activities"
              element={
                <AuthGuard>
                  <Layout>
                    <Activities />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/activities/add"
              element={
                <AuthGuard>
                  <Layout>
                    <ActivityFormPage />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/activities/edit/:id"
              element={
                <AuthGuard>
                  <Layout>
                    <ActivityFormPage />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/communications"
              element={
                <AuthGuard>
                  <Layout>
                    <Communications />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/automation"
              element={
                <AuthGuard>
                  <Layout>
                    <Automation />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/emails"
              element={
                <AuthGuard>
                  <Layout>
                    <Emails />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/proposals"
              element={
                <AuthGuard>
                  <Layout>
                    <Proposals />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/proposals/edit/:id"
              element={
                <AuthGuard>
                  <Layout>
                    <ProposalEdit />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/fields-editor"
              element={
                <AuthGuard>
                  <Layout>
                    <FieldsEditorPage />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/fields-editor/advanced/:module"
              element={
                <AuthGuard>
                  <AdvancedFieldEditor />
                </AuthGuard>
              }
            />
            <Route
              path="/module-editor"
              element={
                <AuthGuard>
                  <Layout>
                    <ModuleEditor />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="/import-export"
              element={
                <AuthGuard>
                  <Layout>
                    <ImportExportPage />
                  </Layout>
                </AuthGuard>
              }
            />
            <Route
              path="*"
              element={
                <Layout>
                  <NotFound />
                </Layout>
              }
            />
          </Routes>
          <Toaster />
        </QueryClientProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
