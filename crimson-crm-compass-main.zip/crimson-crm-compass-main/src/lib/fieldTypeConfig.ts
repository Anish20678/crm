
import type { CustomFieldType } from "./types/customFields";

export type FieldTypeOption = {
  label: string;
  value: CustomFieldType;
  needsOptions?: boolean;
  inputType?: string;
};

/**
 * Full list of supported field types and metadata
 */
export const FIELD_TYPE_OPTIONS: FieldTypeOption[] = [
  { label: "Text", value: "text", inputType: "text" },
  { label: "Number", value: "number", inputType: "number" },
  { label: "Textarea", value: "textarea" },
  { label: "Date", value: "date", inputType: "date" },
  { label: "Boolean", value: "boolean", inputType: "checkbox" },
  { label: "Select", value: "select", needsOptions: true },
  { label: "Email", value: "email", inputType: "email" },
  { label: "URL", value: "url", inputType: "url" },
  { label: "Phone", value: "phone", inputType: "tel" },
  { label: "Currency", value: "currency", inputType: "number" },
];

// Helper for quick lookup
export const FIELD_TYPE_LABELS = Object.fromEntries(
  FIELD_TYPE_OPTIONS.map(opt => [opt.value, opt.label])
);
