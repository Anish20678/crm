
/**
 * Shared utilities for custom field logic
 */
import type { CustomFieldType } from "./types/customFields";

// Safer, typed normalizeOptions utility.
export function normalizeOptions(input?: unknown): string[] | undefined {
  if (!input) return undefined;
  if (Array.isArray(input)) {
    // Ensure all elements are strings
    return input.filter(opt => typeof opt === "string" && opt.trim().length > 0);
  }
  if (typeof input === "string") {
    // Try to parse JSON; if not, fallback to comma-separated
    try {
      const maybeArray = JSON.parse(input);
      if (Array.isArray(maybeArray)) return maybeArray.map(s => String(s).trim()).filter(Boolean);
    } catch {
      // Not JSON, treat as "A, B, C"
    }
    return input.split(",").map(s => s.trim()).filter(Boolean);
  }
  return undefined;
}

// Additional validation helpers
export function isValidFieldName(name: string, existing: string[]): boolean {
  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name)) return false;
  return !existing.includes(name);
}
