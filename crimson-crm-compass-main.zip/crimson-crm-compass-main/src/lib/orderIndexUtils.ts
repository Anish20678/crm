
/**
 * Utility functions for managing order index values
 * Enhanced for precise drag-and-drop positioning
 */

export function generateOrderIndex(existingItems: Array<{ order_index: number }> = []): number {
  if (existingItems.length === 0) {
    return 1000; // Start with a reasonable base value
  }
  
  // Find the maximum order index and add 1000 for spacing
  const maxOrder = Math.max(...existingItems.map(item => item.order_index || 0));
  
  // Ensure we don't exceed PostgreSQL integer limits (2^31 - 1 = 2,147,483,647)
  const nextOrder = maxOrder + 1000;
  if (nextOrder > 2147483000) { // Leave some buffer
    console.warn("Order index approaching PostgreSQL integer limit, consider resequencing");
    return Math.floor(Math.random() * 1000000) + 1000; // Fallback to random order
  }
  
  return nextOrder;
}

/**
 * Calculate order index for precise insertion at a specific position
 */
export function calculateInsertOrderIndex(
  items: Array<{ order_index: number }>,
  insertIndex: number
): number {
  const sortedItems = [...items].sort((a, b) => a.order_index - b.order_index);
  
  if (insertIndex <= 0) {
    // Insert at beginning
    const firstOrder = sortedItems[0]?.order_index || 1000;
    return Math.max(100, firstOrder - 1000);
  }
  
  if (insertIndex >= sortedItems.length) {
    // Insert at end
    const lastOrder = sortedItems[sortedItems.length - 1]?.order_index || 0;
    return lastOrder + 1000;
  }
  
  // Insert between two items
  const prevOrder = sortedItems[insertIndex - 1]?.order_index || 0;
  const nextOrder = sortedItems[insertIndex]?.order_index || (prevOrder + 2000);
  
  // Calculate midpoint, ensuring minimum gap of 10
  const midpoint = Math.floor((prevOrder + nextOrder) / 2);
  
  if (nextOrder - prevOrder <= 10) {
    // Need to resequence if gap is too small
    console.log("Gap too small, using fallback order calculation");
    return prevOrder + 500; // Use a reasonable increment
  }
  
  return midpoint;
}

export function generateSequentialOrderIndexes(items: Array<{ id: string }>, startIndex: number = 1000): Array<{ id: string; order_index: number }> {
  return items.map((item, index) => ({
    id: item.id,
    order_index: startIndex + (index * 1000)
  }));
}

export function reorderItems<T extends { id: string; order_index: number }>(
  items: T[],
  sourceIndex: number,
  destinationIndex: number
): T[] {
  const result = Array.from(items);
  const [removed] = result.splice(sourceIndex, 1);
  result.splice(destinationIndex, 0, removed);
  
  // Reassign order indexes with proper spacing
  return result.map((item, index) => ({
    ...item,
    order_index: 1000 + (index * 1000)
  }));
}

export function insertItemAtPosition<T extends { id: string; order_index: number }>(
  items: T[],
  newItem: T,
  position: number
): T[] {
  const result = Array.from(items);
  result.splice(position, 0, newItem);
  
  // Reassign order indexes with proper spacing
  return result.map((item, index) => ({
    ...item,
    order_index: 1000 + (index * 1000)
  }));
}

/**
 * Resequence all order indexes to prevent overflow
 * Useful when order indexes get too high
 */
export function resequenceOrderIndexes<T extends { id: string; order_index: number }>(
  items: T[],
  startIndex: number = 1000,
  increment: number = 1000
): T[] {
  return items
    .sort((a, b) => a.order_index - b.order_index)
    .map((item, index) => ({
      ...item,
      order_index: startIndex + (index * increment)
    }));
}

/**
 * Check if order indexes need resequencing
 */
export function needsResequencing(items: Array<{ order_index: number }>): boolean {
  const maxOrder = Math.max(...items.map(item => item.order_index || 0));
  return maxOrder > 2000000000; // Approaching PostgreSQL limit
}
