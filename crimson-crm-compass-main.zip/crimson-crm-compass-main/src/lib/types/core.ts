
export interface Profile {
  id: string;
  full_name: string | null;
  avatar_url: string | null;
  bio?: string | null;
  website?: string | null;
  organization_name?: string | null;
  organization_role?: string | null;
  organization_website?: string | null;
  created_at: string;
  updated_at: string;
}

export interface Contact {
  id: string;
  user_id: string;
  first_name: string;
  last_name: string | null;
  email: string | null;
  phone: string | null;
  company: string | null;
  position: string | null;
  status: string;
  notes: string | null;
  created_at: string;
  updated_at: string;
  // New contact information fields
  business_name: string | null;
  business_type: string | null;
  emirates: string | null;
  phone_numbers: string[] | null;
  // Lead details fields
  lead_source: string | null;
  campaign_name: string | null;
  inquiry_date: string | null;
  initial_whatsapp_message: string | null;
  // Communication & proposal fields
  call_notes: string | null;
  proposal_sent: boolean | null;
  proposal_files: string[] | null;
  follow_up_date: string | null;
  preferred_contact_method: string | null;
  // Client onboarding
  is_client: boolean | null;
}

export interface Deal {
  id: string;
  contact_id: string;
  name: string;
  amount: number | null;
  status: string | null;
  created_at: string | null;
  updated_at: string | null;
  project_type?: string | null;
  service_package?: string | null;
  project_scope?: string | null;
  requirements_received?: string[] | null;
  start_date?: string | null;
  expected_delivery_date?: string | null;
  actual_delivery_date?: string | null;
  milestones?: { title: string; completed: boolean }[] | null;
  payment_status?: string | null;
  payment_received_date?: string | null;
  invoice_file?: string | null;
  client_notes?: string | null;
  internal_notes?: string | null;
  project_files?: string[] | null;
  final_deliverables?: string[] | null;
}

export interface Task {
  id: string;
  user_id?: string;
  title: string;
  description?: string;
  status: string;
  priority: string;
  due_date?: string;
  assigned_to?: string;
  related_to_type?: string;
  related_to_id?: string;
  deal_id?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Activity {
  id: string;
  user_id: string;
  related_to_type: string;
  related_to_id: string;
  activity_type: string;
  title: string;
  description?: string;
  activity_date?: string;
  created_at?: string;
  updated_at?: string;
  duration_minutes?: number | null;
  location?: string | null;
  participants?: string[] | null;
  outcome?: string | null;
  follow_up_required?: boolean | null;
  follow_up_date?: string | null;
  tags?: string[] | null;
}
