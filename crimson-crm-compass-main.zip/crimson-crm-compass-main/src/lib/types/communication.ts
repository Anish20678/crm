
export interface EmailTemplate {
  id: string;
  user_id: string;
  name: string;
  subject: string;
  body: string;
  template_type?: string;
  is_active?: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface EmailCampaign {
  id: string;
  user_id: string;
  name: string;
  subject: string;
  template_id?: string;
  status: 'draft' | 'scheduled' | 'sending' | 'sent' | 'paused';
  scheduled_at?: string;
  sent_at?: string;
  total_recipients: number;
  sent_count: number;
  opened_count: number;
  clicked_count: number;
  bounced_count: number;
  created_at: string;
  updated_at: string;
}

export interface EmailCampaignRecipient {
  id: string;
  campaign_id: string;
  contact_id: string;
  email: string;
  status: 'pending' | 'sent' | 'delivered' | 'opened' | 'clicked' | 'bounced' | 'failed';
  sent_at?: string;
  opened_at?: string;
  clicked_at?: string;
  bounced_at?: string;
  error_message?: string;
  created_at: string;
  updated_at: string;
}

export interface CommunicationLog {
  id: string;
  user_id: string;
  contact_id: string;
  communication_type: 'email' | 'whatsapp' | 'sms' | 'call' | 'meeting';
  direction: 'inbound' | 'outbound';
  subject?: string;
  content?: string;
  status: 'sent' | 'delivered' | 'read' | 'failed' | 'pending';
  external_id?: string;
  metadata?: any;
  created_at: string;
  updated_at: string;
}

export interface WhatsAppTemplate {
  id: string;
  user_id: string;
  name: string;
  template_name: string;
  language: string;
  category: 'marketing' | 'utility' | 'authentication';
  header_type?: 'text' | 'media' | 'location';
  header_content?: string;
  body_text: string;
  footer_text?: string;
  buttons: any[];
  status: 'pending' | 'approved' | 'rejected';
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface EmailSettings {
  id: string;
  user_id: string;
  from_name?: string;
  from_email?: string;
  reply_to_email?: string;
  signature?: string;
  track_opens?: boolean;
  track_clicks?: boolean;
  enable_auto_responder?: boolean;
  bounce_handling?: boolean;
  unsubscribe_link?: boolean;
  daily_email_limit?: number;
  time_zone?: string;
  sending_frequency?: string;
  created_at: string;
  updated_at: string;
}
