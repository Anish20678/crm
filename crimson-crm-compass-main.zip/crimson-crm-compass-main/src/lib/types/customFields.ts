
// Types for the custom fields editor system

export type CustomFieldType =
  | "text"
  | "number"
  | "textarea"
  | "date"
  | "boolean"
  | "select"
  | "url"
  | "phone"
  | "email"
  | "currency";

export interface CustomField {
  id: string;
  user_id: string;
  module: string;
  name: string;
  label: string;
  field_type: CustomFieldType;
  options?: string[]; // For select-type fields
  required: boolean;
  visible: boolean;
  order_index: number;
  field_group: string; // Added missing field_group property
  description?: string; // Added missing description property
  placeholder?: string; // Added missing placeholder property
  default_value?: string; // Added missing default_value property
  select_options?: string[]; // Added missing select_options property
  created_at: string;
  updated_at: string;
}

export interface CustomFieldValue {
  id: string;
  user_id: string;
  module: string;
  record_id: string;
  field_id: string;
  value: string;
  created_at: string;
  updated_at: string;
}
