
export interface DashboardMetrics {
  totalContacts: number;
  totalDeals: number;
  totalRevenue: number;
  activeDeals: number;
  conversionRate: number;
  avgDealSize: number;
  overdueTasks: number;
  upcomingFollowUps: number;
}

export interface AIInsight {
  id: string;
  type: 'opportunity' | 'risk' | 'trend' | 'recommendation';
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  actionable: boolean;
  relatedEntityType?: string;
  relatedEntityId?: string;
  confidence: number;
  createdAt: string;
}

export interface SalesMetric {
  period: string;
  revenue: number;
  deals: number;
  contacts: number;
  conversionRate: number;
}
