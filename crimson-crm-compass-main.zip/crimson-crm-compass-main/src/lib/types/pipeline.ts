
export interface PipelineStage {
  id: string;
  user_id: string;
  name: string;
  stage_order: number;
  color?: string;
  is_active?: boolean;
  created_at?: string;
  updated_at?: string;
}
