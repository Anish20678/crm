
// Core types
export type {
  Profile,
  Contact,
  Deal,
  Task,
  Activity,
} from './core';

// Communication types
export type {
  EmailTemplate,
  EmailCampaign,
  EmailCampaignRecipient,
  CommunicationLog,
  WhatsAppTemplate,
  EmailSettings,
} from './communication';

// Automation types
export type {
  AutomationRule,
  AutomationExecution,
} from './automation';

// Analytics types
export type {
  DashboardMetrics,
  AIInsight,
  SalesMetric,
} from './analytics';

// Pipeline types
export type {
  PipelineStage,
} from './pipeline';
