
export interface AutomationRule {
  id: string;
  user_id: string;
  name: string;
  description?: string;
  trigger_type: 'contact_created' | 'deal_stage_changed' | 'activity_created' | 'time_based' | 'manual';
  trigger_conditions: any;
  actions: any[];
  is_active: boolean;
  last_run_at?: string;
  run_count: number;
  created_at: string;
  updated_at: string;
}

export interface AutomationExecution {
  id: string;
  rule_id: string;
  contact_id?: string;
  deal_id?: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  started_at: string;
  completed_at?: string;
  error_message?: string;
  execution_log: any[];
  created_at: string;
}
