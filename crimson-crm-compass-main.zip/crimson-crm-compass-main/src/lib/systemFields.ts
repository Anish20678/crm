
// Definition of system fields for each module with grouping support
export interface SystemField {
  name: string;
  label: string;
  type: "text" | "email" | "phone" | "date" | "boolean" | "number" | "textarea" | "select";
  required: boolean;
  defaultVisible: boolean;
  defaultWidth: number;
  fieldGroup: string;
  groupOrder: number;
  description?: string;
}

export interface FieldGroup {
  id: string;
  label: string;
  description?: string;
  defaultExpanded?: boolean;
}

export const FIELD_GROUPS: Record<string, FieldGroup[]> = {
  lead: [], // Lead module is fully customizable - no predefined groups
  contact: [
    { id: "basic", label: "Basic Information", description: "Essential contact details", defaultExpanded: true },
    { id: "business", label: "Business Details", description: "Company and position information", defaultExpanded: true },
    { id: "custom", label: "Custom Fields", description: "User-defined custom fields", defaultExpanded: false },
  ],
  deal: [
    { id: "basic", label: "Deal Information", description: "Basic deal details", defaultExpanded: true },
    { id: "project", label: "Project Details", description: "Project type and scope", defaultExpanded: true },
    { id: "timeline", label: "Timeline & Delivery", description: "Important project dates", defaultExpanded: false },
    { id: "payment", label: "Payment Information", description: "Payment status and details", defaultExpanded: false },
    { id: "custom", label: "Custom Fields", description: "User-defined custom fields", defaultExpanded: false },
  ],
  task: [
    { id: "basic", label: "Task Information", description: "Core task details", defaultExpanded: true },
    { id: "assignment", label: "Assignment & Priority", description: "Task assignment and priority", defaultExpanded: true },
    { id: "relations", label: "Related Items", description: "Connections to other records", defaultExpanded: false },
    { id: "custom", label: "Custom Fields", description: "User-defined custom fields", defaultExpanded: false },
  ],
};

export const SYSTEM_FIELDS: Record<string, SystemField[]> = {
  lead: [], // Lead module has no system fields - fully customizable
  contact: [
    { name: "first_name", label: "First Name", type: "text", required: true, defaultVisible: true, defaultWidth: 15, fieldGroup: "basic", groupOrder: 0 },
    { name: "last_name", label: "Last Name", type: "text", required: false, defaultVisible: true, defaultWidth: 15, fieldGroup: "basic", groupOrder: 1 },
    { name: "email", label: "Email", type: "email", required: false, defaultVisible: true, defaultWidth: 20, fieldGroup: "basic", groupOrder: 2 },
    { name: "phone", label: "Phone", type: "phone", required: false, defaultVisible: true, defaultWidth: 15, fieldGroup: "basic", groupOrder: 3 },
    { name: "company", label: "Company", type: "text", required: false, defaultVisible: true, defaultWidth: 15, fieldGroup: "business", groupOrder: 0 },
    { name: "position", label: "Position", type: "text", required: false, defaultVisible: true, defaultWidth: 12, fieldGroup: "business", groupOrder: 1 },
    { name: "status", label: "Status", type: "select", required: false, defaultVisible: true, defaultWidth: 10, fieldGroup: "business", groupOrder: 2 },
    { name: "is_client", label: "Is Client", type: "boolean", required: false, defaultVisible: true, defaultWidth: 8, fieldGroup: "business", groupOrder: 3 },
    { name: "notes", label: "Notes", type: "textarea", required: false, defaultVisible: false, defaultWidth: 20, fieldGroup: "business", groupOrder: 4 },
  ],
  deal: [
    { name: "name", label: "Deal Name", type: "text", required: true, defaultVisible: true, defaultWidth: 25, fieldGroup: "basic", groupOrder: 0 },
    { name: "amount", label: "Amount", type: "number", required: false, defaultVisible: true, defaultWidth: 15, fieldGroup: "basic", groupOrder: 1 },
    { name: "status", label: "Status", type: "select", required: false, defaultVisible: true, defaultWidth: 12, fieldGroup: "basic", groupOrder: 2 },
    { name: "project_type", label: "Project Type", type: "text", required: false, defaultVisible: true, defaultWidth: 15, fieldGroup: "project", groupOrder: 0 },
    { name: "service_package", label: "Service Package", type: "text", required: false, defaultVisible: false, defaultWidth: 15, fieldGroup: "project", groupOrder: 1 },
    { name: "start_date", label: "Start Date", type: "date", required: false, defaultVisible: true, defaultWidth: 12, fieldGroup: "timeline", groupOrder: 0 },
    { name: "expected_delivery_date", label: "Expected Delivery", type: "date", required: false, defaultVisible: true, defaultWidth: 15, fieldGroup: "timeline", groupOrder: 1 },
    { name: "actual_delivery_date", label: "Actual Delivery", type: "date", required: false, defaultVisible: false, defaultWidth: 15, fieldGroup: "timeline", groupOrder: 2 },
    { name: "payment_status", label: "Payment Status", type: "select", required: false, defaultVisible: true, defaultWidth: 12, fieldGroup: "payment", groupOrder: 0 },
    { name: "payment_received_date", label: "Payment Received", type: "date", required: false, defaultVisible: false, defaultWidth: 15, fieldGroup: "payment", groupOrder: 1 },
    { name: "project_scope", label: "Project Scope", type: "textarea", required: false, defaultVisible: false, defaultWidth: 20, fieldGroup: "project", groupOrder: 2 },
    { name: "client_notes", label: "Client Notes", type: "textarea", required: false, defaultVisible: false, defaultWidth: 20, fieldGroup: "project", groupOrder: 3 },
    { name: "internal_notes", label: "Internal Notes", type: "textarea", required: false, defaultVisible: false, defaultWidth: 20, fieldGroup: "project", groupOrder: 4 },
  ],
  task: [
    { name: "title", label: "Task Title", type: "text", required: true, defaultVisible: true, defaultWidth: 30, fieldGroup: "basic", groupOrder: 0 },
    { name: "description", label: "Description", type: "textarea", required: false, defaultVisible: true, defaultWidth: 25, fieldGroup: "basic", groupOrder: 1 },
    { name: "status", label: "Status", type: "select", required: false, defaultVisible: true, defaultWidth: 12, fieldGroup: "assignment", groupOrder: 0 },
    { name: "priority", label: "Priority", type: "select", required: false, defaultVisible: true, defaultWidth: 10, fieldGroup: "assignment", groupOrder: 1 },
    { name: "due_date", label: "Due Date", type: "date", required: false, defaultVisible: true, defaultWidth: 12, fieldGroup: "assignment", groupOrder: 2 },
    { name: "assigned_to", label: "Assigned To", type: "text", required: false, defaultVisible: true, defaultWidth: 15, fieldGroup: "assignment", groupOrder: 3 },
    { name: "related_to_type", label: "Related To Type", type: "select", required: false, defaultVisible: false, defaultWidth: 15, fieldGroup: "relations", groupOrder: 0 },
  ],
};

export function getSystemFieldsForModule(module: string): SystemField[] {
  return SYSTEM_FIELDS[module] || [];
}

export function getFieldGroupsForModule(module: string): FieldGroup[] {
  return FIELD_GROUPS[module] || [];
}

export function getDefaultSystemFieldConfig(module: string, fieldName: string) {
  const systemField = getSystemFieldsForModule(module).find(f => f.name === fieldName);
  if (!systemField) return null;

  return {
    field_name: fieldName,
    is_visible: systemField.defaultVisible,
    is_required: systemField.required,
    field_order: systemField.groupOrder,
    width_percentage: systemField.defaultWidth,
    field_group: systemField.fieldGroup,
    group_order: systemField.groupOrder,
  };
}
