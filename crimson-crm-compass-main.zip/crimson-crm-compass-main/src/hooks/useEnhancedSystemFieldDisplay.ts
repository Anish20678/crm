
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export interface SystemFieldDisplay {
  fieldName: string;
  label: string;
  type: string;
  required: boolean;
  visible: boolean;
  group: string;
  order: number;
}

export function useEnhancedSystemFieldDisplay(module: string) {
  const { user } = useAuth();
  const [visibleFields, setVisibleFields] = useState<SystemFieldDisplay[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadSystemFieldConfigs = async () => {
      if (!user) return;

      try {
        // For the lead module (now fully customizable), we return an empty array
        if (module === "lead") {
          setVisibleFields([]);
          setIsLoading(false);
          return;
        }

        // For other modules, load system field configurations
        const { data, error } = await supabase
          .from("system_field_configs")
          .select("*")
          .eq("user_id", user.id)
          .eq("module", module)
          .eq("is_visible", true)
          .order("field_order");

        if (error && error.code !== 'PGRST116') { // PGRST116 is "no rows found"
          throw error;
        }

        // Map the configurations to the expected format
        const systemFields: SystemFieldDisplay[] = (data || []).map(config => ({
          fieldName: config.field_name,
          label: config.field_name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
          type: 'text', // Default type, can be enhanced later
          required: config.is_required,
          visible: config.is_visible,
          group: config.field_group || 'basic',
          order: config.field_order || 0,
        }));

        setVisibleFields(systemFields);
      } catch (error) {
        console.error("Error loading system field configs:", error);
        // For modules with errors or no system fields configured, return empty array
        setVisibleFields([]);
      } finally {
        setIsLoading(false);
      }
    };

    loadSystemFieldConfigs();
  }, [user, module]);

  return {
    visibleFields,
    isLoading,
  };
}
