
import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "./use-toast";

export interface Lead {
  id: string;
  user_id: string;
  created_at: string;
  updated_at: string;
  // Custom fields will be added dynamically through custom_field_values
}

export function useLeadsData() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Query for leads
  const { data: leads = [], isLoading, error } = useQuery({
    queryKey: ["leads", user?.id],
    queryFn: async () => {
      if (!user) return [];

      const { data, error } = await supabase
        .from("leads")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as Lead[];
    },
    enabled: !!user,
  });

  // Create lead mutation
  const createLeadMutation = useMutation({
    mutationFn: async (leadData: Partial<Lead>) => {
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from("leads")
        .insert({
          user_id: user.id,
          ...leadData,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["leads"] });
      toast({
        title: "Lead created",
        description: "New lead has been created successfully.",
      });
    },
    onError: (error) => {
      console.error("Error creating lead:", error);
      toast({
        title: "Error creating lead",
        description: "Failed to create lead. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update lead mutation
  const updateLeadMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Lead> }) => {
      const { data: updatedData, error } = await supabase
        .from("leads")
        .update(data)
        .eq("id", id)
        .eq("user_id", user?.id)
        .select()
        .single();

      if (error) throw error;
      return updatedData;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["leads"] });
      toast({
        title: "Lead updated",
        description: "Lead has been updated successfully.",
      });
    },
    onError: (error) => {
      console.error("Error updating lead:", error);
      toast({
        title: "Error updating lead",
        description: "Failed to update lead. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Delete lead mutation
  const deleteLeadMutation = useMutation({
    mutationFn: async (leadId: string) => {
      const { error } = await supabase
        .from("leads")
        .delete()
        .eq("id", leadId)
        .eq("user_id", user?.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["leads"] });
      toast({
        title: "Lead deleted",
        description: "Lead has been deleted successfully.",
      });
    },
    onError: (error) => {
      console.error("Error deleting lead:", error);
      toast({
        title: "Error deleting lead",
        description: "Failed to delete lead. Please try again.",
        variant: "destructive",
      });
    },
  });

  return {
    leads,
    isLoading,
    error,
    createLead: createLeadMutation.mutate,
    updateLead: updateLeadMutation.mutate,
    deleteLead: deleteLeadMutation.mutate,
    isCreating: createLeadMutation.isPending,
    isUpdating: updateLeadMutation.isPending,
    isDeleting: deleteLeadMutation.isPending,
  };
}
