
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

export interface FieldValidationRule {
  id: string;
  user_id: string;
  module: string;
  field_name: string;
  rule_type: 'required_if' | 'min_length' | 'max_length' | 'regex' | 'custom';
  rule_config: Record<string, any>;
  error_message?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export const useFieldValidationRules = (module: string) => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: validationRules = [], isLoading } = useQuery({
    queryKey: ["field-validation-rules", module, user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from("field_validation_rules")
        .select("*")
        .eq("module", module)
        .eq("user_id", user.id)
        .eq("is_active", true)
        .order("field_name");

      if (error) throw error;
      return data as FieldValidationRule[];
    },
    enabled: !!user,
  });

  const createValidationRule = useMutation({
    mutationFn: async (rule: Omit<FieldValidationRule, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from("field_validation_rules")
        .insert({
          ...rule,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["field-validation-rules", module] });
      toast({
        title: "Validation rule created",
        description: "Field validation rule has been created successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error creating validation rule",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateValidationRule = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<FieldValidationRule> & { id: string }) => {
      const { data, error } = await supabase
        .from("field_validation_rules")
        .update(updates)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["field-validation-rules", module] });
      toast({
        title: "Validation rule updated",
        description: "Field validation rule has been updated successfully.",
      });
    },
  });

  const deleteValidationRule = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("field_validation_rules")
        .delete()
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["field-validation-rules", module] });
      toast({
        title: "Validation rule deleted",
        description: "Field validation rule has been deleted successfully.",
      });
    },
  });

  return {
    validationRules,
    isLoading,
    createValidationRule,
    updateValidationRule,
    deleteValidationRule,
  };
};
