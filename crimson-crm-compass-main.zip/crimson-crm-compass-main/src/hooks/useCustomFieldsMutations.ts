
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import type { CustomField, CustomFieldType } from "@/lib/types/customFields";

type UpsertCustomFieldArgs = {
  id?: string;
  module: string;
  name: string;
  label: string;
  field_type: CustomFieldType;
  options?: string[];
  required: boolean;
  visible: boolean;
  order_index: number;
  field_group?: string;
};

export function useCustomFieldsMutations(module: string) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Add or update a field
  const upsertField = useMutation({
    mutationFn: async (field: UpsertCustomFieldArgs) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");
      
      const fieldData: any = {
        user_id: user.id,
        module: field.module,
        name: field.name,
        label: field.label,
        field_type: field.field_type,
        options: field.options ? JSON.stringify(field.options) : null,
        required: field.required,
        visible: field.visible,
        order_index: field.order_index,
        field_group: field.field_group || 'custom',
      };
      
      if (field.id) fieldData.id = field.id;

      const { data, error } = await supabase
        .from("custom_fields")
        .upsert([fieldData])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      // Invalidate multiple related queries for better sync
      queryClient.invalidateQueries({ queryKey: ["custom-fields"] });
      queryClient.invalidateQueries({ queryKey: ["custom-field-values"] });
      queryClient.invalidateQueries({ queryKey: ["system-field-configs"] });
      
      toast({ title: "Saved!", description: "Field updated successfully." });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error?.message || String(error), variant: "destructive" });
    },
  });

  // Delete a field
  const deleteField = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("custom_fields")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["custom-fields"] });
      queryClient.invalidateQueries({ queryKey: ["custom-field-values"] });
      toast({ title: "Field deleted" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error?.message || String(error), variant: "destructive" });
    },
  });

  // Reorder fields with better error handling and sync
  const reorderFields = async (fieldOrder: { id: string; order_index: number; field_group?: string; visible?: boolean; required?: boolean }[]) => {
    try {
      for (const field of fieldOrder) {
        const updateData: any = { order_index: field.order_index };
        
        if (field.field_group !== undefined) {
          updateData.field_group = field.field_group;
        }
        if (field.visible !== undefined) {
          updateData.visible = field.visible;
        }
        if (field.required !== undefined) {
          updateData.required = field.required;
        }
        
        await supabase.from("custom_fields")
          .update(updateData)
          .eq("id", field.id);
      }
      
      // Invalidate queries for better sync
      queryClient.invalidateQueries({ queryKey: ["custom-fields", module] });
      queryClient.invalidateQueries({ queryKey: ["custom-field-values", module] });
      
    } catch (error) {
      console.error("Reorder error:", error);
      toast({
        title: "Error",
        description: "Failed to update field order",
        variant: "destructive",
      });
    }
  };

  return {
    upsertField: upsertField.mutate,
    upsertFieldMutation: upsertField,
    deleteField: deleteField.mutate,
    deleteFieldMutation: deleteField,
    reorderFields,
  };
}
