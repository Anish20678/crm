
import { useMemo } from "react";
import { useSystemFieldDisplay } from "./useSystemFieldDisplay";
import { useCustomFieldsData } from "./useCustomFieldsData";
import { useFieldGroups } from "./useFieldGroups";

export interface FormFieldGroup {
  id: string;
  label: string;
  description?: string;
  expanded: boolean;
  systemFields: any[];
  customFields: any[];
  order: number;
}

export function useFormFieldConfig(module: string) {
  const { visibleFields, isLoading: systemLoading } = useSystemFieldDisplay(module);
  const { customFields, isLoading: customLoading } = useCustomFieldsData(module);
  const { fieldGroups, isLoading: groupsLoading } = useFieldGroups(module);

  const groupedFormFields = useMemo(() => {
    if (systemLoading || customLoading || groupsLoading) return [];

    // Create a map of groups
    const groupMap = new Map<string, FormFieldGroup>();
    
    // Initialize with database groups
    fieldGroups.forEach(group => {
      groupMap.set(group.id, {
        id: group.id,
        label: group.label,
        description: group.description,
        expanded: group.default_expanded,
        systemFields: [],
        customFields: [],
        order: group.group_order,
      });
    });

    // Add default groups if not present
    const defaultGroups = {
      lead: [
        { id: 'basic', label: 'Basic Information', order: 0 },
        { id: 'custom', label: 'Custom Fields', order: 1 }
      ],
      contact: [
        { id: 'basic', label: 'Basic Information', order: 0 },
        { id: 'business', label: 'Business Details', order: 1 },
        { id: 'custom', label: 'Custom Fields', order: 2 }
      ],
      deal: [
        { id: 'basic', label: 'Deal Information', order: 0 },
        { id: 'project', label: 'Project Details', order: 1 },
        { id: 'timeline', label: 'Timeline & Delivery', order: 2 },
        { id: 'payment', label: 'Payment Information', order: 3 },
        { id: 'custom', label: 'Custom Fields', order: 4 }
      ],
      task: [
        { id: 'basic', label: 'Task Information', order: 0 },
        { id: 'assignment', label: 'Assignment & Priority', order: 1 },
        { id: 'relations', label: 'Related Items', order: 2 },
        { id: 'custom', label: 'Custom Fields', order: 3 }
      ]
    };

    const moduleDefaults = defaultGroups[module as keyof typeof defaultGroups] || [];
    moduleDefaults.forEach(defaultGroup => {
      if (!groupMap.has(defaultGroup.id)) {
        groupMap.set(defaultGroup.id, {
          id: defaultGroup.id,
          label: defaultGroup.label,
          expanded: true,
          systemFields: [],
          customFields: [],
          order: defaultGroup.order,
        });
      }
    });

    // Assign system fields to groups
    visibleFields.forEach(field => {
      const groupId = field.group || 'basic';
      const group = groupMap.get(groupId);
      if (group) {
        group.systemFields.push(field);
      }
    });

    // Assign custom fields to groups
    customFields.forEach(field => {
      const groupId = field.field_group || 'custom';
      const group = groupMap.get(groupId);
      if (group) {
        group.customFields.push(field);
      }
    });

    // Convert to array and sort by order
    return Array.from(groupMap.values())
      .filter(group => group.systemFields.length > 0 || group.customFields.length > 0)
      .sort((a, b) => a.order - b.order);
  }, [visibleFields, customFields, fieldGroups, systemLoading, customLoading, groupsLoading]);

  return {
    groupedFormFields,
    isLoading: systemLoading || customLoading || groupsLoading,
  };
}
