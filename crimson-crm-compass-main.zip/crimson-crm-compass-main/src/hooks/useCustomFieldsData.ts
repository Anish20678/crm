
/**
 * Read-focused custom fields data hook
 * Splits from mutations for better composability.
 */
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { CustomField, CustomFieldType } from "@/lib/types/customFields";
import { useState } from "react";
import { normalizeOptions } from "@/lib/customFieldUtils";

export function useCustomFieldsData(module: string) {
  const [fieldsError, setFieldsError] = useState<Error | null>(null);

  const {
    data: customFields = [],
    isLoading,
    error,
    refetch,
  } = useQuery({
    queryKey: ["custom-fields", module],
    queryFn: async (): Promise<CustomField[]> => {
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");
      const { data, error } = await supabase
        .from("custom_fields")
        .select("*")
        .eq("user_id", user.id)
        .eq("module", module)
        .order("order_index", { ascending: true });
      if (error) throw error;
      // Normalize options for select fields
      return (data || []).map((field: any) => ({
        ...field,
        field_type: field.field_type as CustomFieldType,
        options: normalizeOptions(field.options),
      }));
    },
    meta: {
      onError: (err: any) => {
        setFieldsError(err);
      },
    },
  });

  return {
    customFields,
    isLoading,
    error: error || fieldsError,
    refetch,
  };
}
