import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface FieldGroup {
  id: string;
  user_id: string;
  module: string;
  label: string;
  description?: string;
  default_expanded: boolean;
  group_order: number;
  is_system: boolean;
  created_at: string;
  updated_at: string;
}

export function useFieldGroups(module: string) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get field groups for a module
  const {
    data: fieldGroups = [],
    isLoading,
    error,
  } = useQuery({
    queryKey: ["field-groups", module],
    queryFn: async (): Promise<FieldGroup[]> => {
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase
        .from("field_groups")
        .select("*")
        .eq("user_id", user.id)
        .eq("module", module)
        .order("group_order", { ascending: true });

      if (error) throw error;
      
      // Filter out any system groups that shouldn't exist
      const validGroups = (data || []).filter(group => {
        // Keep custom groups and valid system groups
        if (!group.is_system) return true;
        
        // Define valid system groups per module
        const validSystemGroups = {
          lead: ['basic', 'custom'],
          contact: ['basic', 'business', 'custom'],
          deal: ['basic', 'project', 'timeline', 'payment', 'custom'],
          task: ['basic', 'assignment', 'relations', 'custom']
        };
        
        const moduleGroups = validSystemGroups[module as keyof typeof validSystemGroups] || [];
        return moduleGroups.includes(group.id);
      });
      
      return validGroups;
    },
    enabled: !!module,
  });

  // Upsert field group
  const upsertGroup = useMutation({
    mutationFn: async (group: Partial<FieldGroup> & { id: string; label: string }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Check if this is a system group that we should create
      const systemGroups = {
        lead: ['basic', 'custom'],
        contact: ['basic', 'business', 'custom'],
        deal: ['basic', 'project', 'timeline', 'payment', 'custom'],
        task: ['basic', 'assignment', 'relations', 'custom']
      };
      
      const moduleSystemGroups = systemGroups[module as keyof typeof systemGroups] || [];
      const isSystemGroup = moduleSystemGroups.includes(group.id);

      const groupData = {
        id: group.id,
        user_id: user.id,
        module,
        label: group.label,
        description: group.description || null,
        default_expanded: group.default_expanded ?? true,
        group_order: group.group_order ?? 0,
        is_system: group.is_system ?? isSystemGroup,
      };

      const { data, error } = await supabase
        .from("field_groups")
        .upsert([groupData], { onConflict: "user_id,module,id" })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["field-groups", module] });
      toast({ title: "Group saved", description: "Field group updated successfully." });
    },
    onError: (error: any) => {
      console.error("Group upsert error:", error);
      toast({ 
        title: "Error", 
        description: error?.message || "Failed to save group", 
        variant: "destructive" 
      });
    },
  });

  // Delete field group
  const deleteGroup = useMutation({
    mutationFn: async (groupId: string) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase
        .from("field_groups")
        .delete()
        .eq("id", groupId)
        .eq("module", module)
        .eq("user_id", user.id)
        .eq("is_system", false); // Only allow deletion of custom groups

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["field-groups", module] });
      toast({ title: "Group deleted", description: "Field group deleted successfully." });
    },
    onError: (error: any) => {
      console.error("Group delete error:", error);
      toast({ 
        title: "Error", 
        description: error?.message || "Failed to delete group", 
        variant: "destructive" 
      });
    },
  });

  // Update group order
  const updateGroupOrder = useMutation({
    mutationFn: async (groupUpdates: { id: string; group_order: number }[]) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const updatePromises = groupUpdates.map(async (update) => {
        const { error } = await supabase
          .from("field_groups")
          .update({ group_order: update.group_order })
          .eq("id", update.id)
          .eq("user_id", user.id)
          .eq("module", module);

        if (error) throw error;
      });

      await Promise.all(updatePromises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["field-groups", module] });
      toast({ title: "Group order updated", description: "Field group order saved successfully." });
    },
    onError: (error: any) => {
      console.error("Group order update error:", error);
      toast({ 
        title: "Error", 
        description: error?.message || "Failed to update group order", 
        variant: "destructive" 
      });
    },
  });

  return {
    fieldGroups,
    isLoading,
    error,
    upsertGroup: upsertGroup.mutate,
    deleteGroup: deleteGroup.mutate,
    updateGroupOrder: updateGroupOrder.mutate,
    isUpdating: upsertGroup.isPending || deleteGroup.isPending || updateGroupOrder.isPending,
  };
}
