
import { useCallback } from "react";
import { UseFormReturn } from "react-hook-form";
import { useSystemFieldDisplay } from "./useSystemFieldDisplay";
import { useCustomFieldsData } from "./useCustomFieldsData";

export function useFormValidation(module: string, form: UseFormReturn<any>) {
  const { visibleFields } = useSystemFieldDisplay(module);
  const { customFields } = useCustomFieldsData(module);

  const validateSystemFields = useCallback(() => {
    const errors: Record<string, string> = {};
    
    visibleFields
      .filter(field => field.required)
      .forEach(field => {
        const value = form.getValues(field.fieldName);
        if (!value || (typeof value === 'string' && value.trim() === '')) {
          errors[field.fieldName] = `${field.label} is required`;
        }
      });
    
    return errors;
  }, [visibleFields, form]);

  const validateCustomFields = useCallback((customFieldValues: Record<string, string>) => {
    const errors: Record<string, string> = {};
    
    customFields
      .filter(field => field.required)
      .forEach(field => {
        const value = customFieldValues[field.id];
        if (!value || value.trim() === '') {
          errors[field.id] = `${field.label} is required`;
        }
      });
    
    return errors;
  }, [customFields]);

  const validateAllFields = useCallback((customFieldValues: Record<string, string>) => {
    const systemErrors = validateSystemFields();
    const customErrors = validateCustomFields(customFieldValues);
    
    // Set system field errors in form
    Object.entries(systemErrors).forEach(([fieldName, message]) => {
      form.setError(fieldName, { message });
    });
    
    return {
      systemErrors,
      customErrors,
      hasErrors: Object.keys(systemErrors).length > 0 || Object.keys(customErrors).length > 0,
    };
  }, [validateSystemFields, validateCustomFields, form]);

  return {
    validateSystemFields,
    validateCustomFields,
    validateAllFields,
  };
}
