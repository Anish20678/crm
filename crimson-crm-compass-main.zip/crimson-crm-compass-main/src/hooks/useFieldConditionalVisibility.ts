
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

export interface FieldConditionalVisibility {
  id: string;
  user_id: string;
  module: string;
  field_name: string;
  condition_type: 'field_value' | 'field_empty' | 'field_not_empty' | 'custom';
  condition_config: Record<string, any>;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export const useFieldConditionalVisibility = (module: string) => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: visibilityConditions = [], isLoading } = useQuery({
    queryKey: ["field-conditional-visibility", module, user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from("field_conditional_visibility")
        .select("*")
        .eq("module", module)
        .eq("user_id", user.id)
        .eq("is_active", true)
        .order("field_name");

      if (error) throw error;
      return data as FieldConditionalVisibility[];
    },
    enabled: !!user,
  });

  const createVisibilityCondition = useMutation({
    mutationFn: async (condition: Omit<FieldConditionalVisibility, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from("field_conditional_visibility")
        .insert({
          ...condition,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["field-conditional-visibility", module] });
      toast({
        title: "Visibility condition created",
        description: "Field visibility condition has been created successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error creating visibility condition",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateVisibilityCondition = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<FieldConditionalVisibility> & { id: string }) => {
      const { data, error } = await supabase
        .from("field_conditional_visibility")
        .update(updates)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["field-conditional-visibility", module] });
    },
  });

  const deleteVisibilityCondition = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("field_conditional_visibility")
        .delete()
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["field-conditional-visibility", module] });
      toast({
        title: "Visibility condition deleted",
        description: "Field visibility condition has been deleted successfully.",
      });
    },
  });

  return {
    visibilityConditions,
    isLoading,
    createVisibilityCondition,
    updateVisibilityCondition,
    deleteVisibilityCondition,
  };
};
