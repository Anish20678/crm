import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { EmailTemplate, Contact, CommunicationLog } from "@/lib/types";

export function useEmailComposer() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    to: "",
    subject: "",
    body: "",
    templateId: "",
    sendLater: false,
    scheduledAt: "",
    contactId: null as string | null,
  });

  // Fetch email templates
  const { data: templates = [] } = useQuery({
    queryKey: ["email-templates"],
    queryFn: async (): Promise<EmailTemplate[]> => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from("email_templates")
        .select("*")
        .eq("user_id", user.id)
        .eq("is_active", true)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data || [];
    },
  });

  // Fetch contacts
  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts"],
    queryFn: async (): Promise<Contact[]> => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from("contacts")
        .select("*")
        .eq("user_id", user.id)
        .order("first_name", { ascending: true });

      if (error) throw error;
      
      return (data || []).map(contact => ({
        ...contact,
        phone_numbers: Array.isArray(contact.phone_numbers) 
          ? (contact.phone_numbers as string[])
          : typeof contact.phone_numbers === 'string' 
            ? [contact.phone_numbers] 
            : [],
        proposal_files: Array.isArray(contact.proposal_files) 
          ? (contact.proposal_files as string[])
          : contact.proposal_files === null 
            ? null 
            : []
      }));
    },
  });

  // Use the new send-http-email endpoint
  const sendEmailMutation = useMutation({
    mutationFn: async ({ to, subject, body }: { to: string; subject: string; body: string }) => {
      // Call the new Supabase Edge Function
      const { data, error } = await supabase.functions.invoke("send-http-email", {
        body: { to, subject, body },
      });

      if (error) {
        throw new Error(error.message);
      }
      return data;
    },
  });

  const logCommunicationMutation = useMutation({
    mutationFn: async (log: Omit<CommunicationLog, 'id' | 'user_id' | 'created_at' | 'updated_at' | 'metadata'>) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { error } = await supabase.from('communication_logs').insert({
        ...log,
        user_id: user.id,
      });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['communication-logs'] });
    },
    onError: (error) => {
      toast({
        title: "Failed to log email",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleTemplateSelect = (templateId: string) => {
    const template = templates.find(t => t.id === templateId);
    if (template) {
      setFormData(prev => ({
        ...prev,
        templateId,
        subject: template.subject,
        body: template.body,
      }));
    }
  };

  const handleContactSelect = (contactId: string) => {
    const contact = contacts.find(c => c.id === contactId);
    if (contact) {
      setFormData(prev => ({
        ...prev,
        to: contact.email || "",
        contactId: contact.id,
      }));
    }
  };

  const handleSend = () => {
    if (!formData.to || !formData.subject || !formData.body) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    let contactIdToLog = formData.contactId;
    if (!contactIdToLog) {
      const contact = contacts.find(c => c.email === formData.to);
      if (contact) {
        contactIdToLog = contact.id;
      }
    }

    sendEmailMutation.mutate({
      to: formData.to,
      subject: formData.subject,
      body: formData.body,
    }, {
      onSuccess: (data) => {
        toast({
          title: "Email Sent!",
          description: "Your email has been sent successfully.",
        });
        if (contactIdToLog) {
          logCommunicationMutation.mutate({
            contact_id: contactIdToLog,
            communication_type: 'email',
            direction: 'outbound',
            subject: formData.subject,
            content: formData.body,
            status: 'sent',
            external_id: data?.messageId,
          });
        }
      },
      onError: (error) => {
        toast({
          title: "Failed to send email",
          description: error.message,
          variant: "destructive",
        });
      }
    });
  };

  return {
    formData,
    setFormData,
    templates,
    contacts,
    handleTemplateSelect,
    handleContactSelect,
    handleSend,
    sendEmailMutation,
  };
}
