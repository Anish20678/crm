
import { useMemo } from "react";
import { useSystemFieldConfigs } from "./useSystemFieldConfigs";
import { getSystemFieldsForModule } from "@/lib/systemFields";

export interface DisplayField {
  id: string;
  label: string;
  visible: boolean;
  width: number;
  fieldName: string;
  type: string;
  required: boolean;
  group: string;
}

export function useSystemFieldDisplay(module: string) {
  const { systemFieldConfigs, isLoading, getVisibleFieldsInOrder } = useSystemFieldConfigs(module);
  const systemFields = getSystemFieldsForModule(module);

  const displayFields = useMemo((): DisplayField[] => {
    // For lead module, return empty array since it has no system fields
    if (module === "lead") {
      return [];
    }

    return systemFields.map(field => {
      const userConfig = systemFieldConfigs.find(config => config.field_name === field.name);
      
      return {
        id: field.name,
        label: field.label,
        visible: userConfig?.is_visible ?? field.defaultVisible,
        width: userConfig?.width_percentage ?? field.defaultWidth,
        fieldName: field.name,
        type: field.type,
        required: field.required,
        group: userConfig?.field_group ?? field.fieldGroup,
      };
    });
  }, [systemFields, systemFieldConfigs, module]);

  const visibleFields = useMemo(() => {
    return displayFields.filter(field => field.visible);
  }, [displayFields]);

  const getFieldConfig = (fieldName: string) => {
    return displayFields.find(field => field.fieldName === fieldName);
  };

  return {
    displayFields,
    visibleFields,
    isLoading,
    getFieldConfig,
    getVisibleFieldsInOrder,
  };
}
