
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { getSystemFieldsForModule } from "@/lib/systemFields";

interface ModuleFieldCounts {
  systemFields: number;
  customFields: number;
  totalFields: number;
}

export function useModuleFieldCounts(module: string) {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["module-field-counts", module, user?.id],
    queryFn: async (): Promise<ModuleFieldCounts> => {
      if (!user) {
        return { systemFields: 0, customFields: 0, totalFields: 0 };
      }

      // Get system fields count (will be 0 for lead module)
      const systemFields = getSystemFieldsForModule(module);
      const systemFieldsCount = systemFields.length;

      // Get custom fields count
      const { data: customFields, error } = await supabase
        .from("custom_fields")
        .select("id")
        .eq("user_id", user.id)
        .eq("module", module);

      if (error) {
        console.error("Error fetching custom fields count:", error);
        return { systemFields: systemFieldsCount, customFields: 0, totalFields: systemFieldsCount };
      }

      const customFieldsCount = customFields?.length || 0;

      return {
        systemFields: systemFieldsCount,
        customFields: customFieldsCount,
        totalFields: systemFieldsCount + customFieldsCount,
      };
    },
    enabled: !!user,
  });
}
