
import { useState } from "react";
import { useCustomFieldsMutations } from "./useCustomFieldsMutations";
import { useCustomFieldsData } from "./useCustomFieldsData";
import { useToast } from "./use-toast";
import { generateOrderIndex } from "@/lib/orderIndexUtils";
import type { CustomFieldType } from "@/lib/types/customFields";

interface FieldCreationOptions {
  label: string;
  required?: boolean;
  placeholder?: string;
  description?: string;
  defaultValue?: string;
  validationRules?: {
    min?: number;
    max?: number;
    pattern?: string;
    minLength?: number;
    maxLength?: number;
  };
  selectOptions?: string[];
  fieldProperties?: Record<string, any>;
}

export function useAdvancedFieldCreation(module: string) {
  const { upsertField } = useCustomFieldsMutations(module);
  const { customFields, refetch } = useCustomFieldsData(module);
  const { toast } = useToast();
  const [isCreating, setIsCreating] = useState(false);

  const createAdvancedField = async (
    fieldType: CustomFieldType,
    groupId: string,
    options: FieldCreationOptions
  ) => {
    setIsCreating(true);
    
    try {
      console.log(`Creating advanced ${fieldType} field in group: ${groupId}`);
      
      // Generate unique field name
      const timestamp = Date.now().toString().slice(-6);
      const sanitizedLabel = options.label.toLowerCase().replace(/[^a-z0-9]/g, '_');
      const fieldName = `custom_${sanitizedLabel}_${timestamp}`;
      
      // Generate proper order index
      const groupFields = customFields.filter(f => f.field_group === groupId);
      const orderIndex = generateOrderIndex(groupFields);
      
      // Prepare field configuration
      const fieldConfig: any = {
        module,
        name: fieldName,
        label: options.label,
        field_type: fieldType,
        required: options.required || false,
        visible: true,
        order_index: orderIndex,
        field_group: groupId,
        placeholder: options.placeholder,
        description: options.description,
        default_value: options.defaultValue,
      };

      // Handle field-type specific configurations
      switch (fieldType) {
        case 'select':
          fieldConfig.options = options.selectOptions || ['Option 1', 'Option 2', 'Option 3'];
          break;
        case 'number':
        case 'currency':
          if (options.validationRules) {
            fieldConfig.validation_rules = {
              min: options.validationRules.min,
              max: options.validationRules.max,
            };
          }
          break;
        case 'text':
        case 'textarea':
          if (options.validationRules) {
            fieldConfig.validation_rules = {
              minLength: options.validationRules.minLength,
              maxLength: options.validationRules.maxLength,
              pattern: options.validationRules.pattern,
            };
          }
          break;
      }

      // Add any additional field properties
      if (options.fieldProperties) {
        fieldConfig.field_properties = options.fieldProperties;
      }

      console.log('Creating advanced field with config:', fieldConfig);
      await upsertField(fieldConfig);
      
      // Refetch to ensure sync
      setTimeout(() => {
        refetch();
      }, 500);
      
      toast({
        title: "Advanced field created",
        description: `${options.label} has been added to the ${groupId} group with advanced configuration.`,
      });
      
      return fieldName;
    } catch (error) {
      console.error("Failed to create advanced field:", error);
      toast({
        title: "Error creating field",
        description: "Failed to create advanced field. Please try again.",
        variant: "destructive",
      });
      return null;
    } finally {
      setIsCreating(false);
    }
  };

  const createFieldWithValidation = async (
    fieldType: CustomFieldType,
    groupId: string,
    label: string,
    validationRules: FieldCreationOptions['validationRules']
  ) => {
    return createAdvancedField(fieldType, groupId, {
      label,
      validationRules,
    });
  };

  const createSelectFieldWithOptions = async (
    groupId: string,
    label: string,
    options: string[]
  ) => {
    return createAdvancedField('select', groupId, {
      label,
      selectOptions: options,
    });
  };

  const duplicateField = async (fieldId: string, newGroupId?: string) => {
    const existingField = customFields.find(f => f.id === fieldId);
    if (!existingField) {
      toast({
        title: "Field not found",
        description: "Cannot duplicate field that doesn't exist.",
        variant: "destructive",
      });
      return null;
    }

    return createAdvancedField(existingField.field_type as CustomFieldType, newGroupId || existingField.field_group, {
      label: `${existingField.label} (Copy)`,
      required: existingField.required,
      placeholder: existingField.placeholder,
      description: existingField.description,
      defaultValue: existingField.default_value,
      selectOptions: existingField.options,
    });
  };

  return {
    createAdvancedField,
    createFieldWithValidation,
    createSelectFieldWithOptions,
    duplicateField,
    isCreating,
  };
}
