
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import type { CustomField, CustomFieldValue } from "@/lib/types/customFields";

export function useCustomFieldValues(module: string, recordId: string | null | undefined) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get all field definitions for this module
  const fieldsQuery = useQuery({
    queryKey: ["custom-fields", module],
    queryFn: async (): Promise<CustomField[]> => {
      // Assume user is authenticated, as enforced by RLS
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");
      const { data, error } = await supabase
        .from("custom_fields")
        .select("*")
        .eq("user_id", user.id)
        .eq("module", module)
        .order("order_index", { ascending: true });
      if (error) throw error;
      return (data || []).map((f: any) => ({ ...f, options: Array.isArray(f.options) ? f.options : (typeof f.options === "string" ? JSON.parse(f.options) : undefined) }));
    },
    enabled: !!module,
  });

  // Get values for this record (if editing or if record exists)
  const valuesQuery = useQuery({
    queryKey: ["custom-field-values", module, recordId],
    queryFn: async (): Promise<CustomFieldValue[]> => {
      if (!recordId) return [];
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");
      const { data, error } = await supabase
        .from("custom_field_values")
        .select("*")
        .eq("user_id", user.id)
        .eq("module", module)
        .eq("record_id", recordId);
      if (error) throw error;
      return data || [];
    },
    enabled: !!module && !!recordId,
  });

  // Upsert (create/update) field values for this record
  const upsertValueMutation = useMutation({
    mutationFn: async (values: { field_id: string, value: string }[]) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");
      const recordValues = values.map(v => ({
        user_id: user.id,
        module,
        record_id: recordId,
        field_id: v.field_id,
        value: v.value
      }));
      // upsert (by user, module, record_id, field_id)
      const { data, error } = await supabase
        .from("custom_field_values")
        .upsert(recordValues, { onConflict: "user_id,module,record_id,field_id" });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["custom-field-values", module, recordId] });
    },
    onError: (error: any) => {
      toast({ title: "Error saving custom field", description: error?.message || String(error), variant: "destructive" });
    }
  });

  return {
    customFields: fieldsQuery.data || [],
    customFieldValues: valuesQuery.data || [],
    fieldsLoading: fieldsQuery.isLoading,
    valuesLoading: valuesQuery.isLoading,
    upsertValues: upsertValueMutation.mutateAsync,
    error: fieldsQuery.error || valuesQuery.error,
  };
}
