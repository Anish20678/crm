
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { DashboardMetrics, AIInsight, SalesMetric } from "@/lib/types";

export function useDashboardMetrics() {
  return useQuery({
    queryKey: ["dashboard-metrics"],
    queryFn: async (): Promise<DashboardMetrics> => {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      // Fetch all data in parallel
      const [contactsRes, dealsRes, tasksRes] = await Promise.all([
        supabase
          .from("contacts")
          .select("*")
          .eq("user_id", user.id),
        supabase
          .from("deals")
          .select("*, contacts!inner(*)")
          .eq("contacts.user_id", user.id),
        supabase
          .from("tasks")
          .select("*")
          .eq("user_id", user.id)
      ]);

      if (contactsRes.error) throw contactsRes.error;
      if (dealsRes.error) throw dealsRes.error;
      if (tasksRes.error) throw tasksRes.error;

      const contacts = contactsRes.data || [];
      const deals = dealsRes.data || [];
      const tasks = tasksRes.data || [];

      // Calculate metrics
      const totalContacts = contacts.length;
      const totalDeals = deals.length;
      const activeDeals = deals.filter(deal => 
        deal.status && !['closed_won', 'closed_lost', 'cancelled'].includes(deal.status.toLowerCase())
      ).length;
      
      const totalRevenue = deals
        .filter(deal => deal.status?.toLowerCase() === 'closed_won')
        .reduce((sum, deal) => sum + (deal.amount || 0), 0);
      
      const conversionRate = totalContacts > 0 
        ? (deals.filter(d => d.status?.toLowerCase() === 'closed_won').length / totalContacts) * 100 
        : 0;
      
      const avgDealSize = totalDeals > 0 
        ? totalRevenue / totalDeals 
        : 0;

      const now = new Date();
      const overdueTasks = tasks.filter(task => 
        task.due_date && 
        new Date(task.due_date) < now && 
        task.status !== 'completed'
      ).length;

      const upcomingFollowUps = contacts.filter(contact => 
        contact.follow_up_date && 
        new Date(contact.follow_up_date) >= now &&
        new Date(contact.follow_up_date) <= new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000)
      ).length;

      return {
        totalContacts,
        totalDeals,
        totalRevenue,
        activeDeals,
        conversionRate,
        avgDealSize,
        overdueTasks,
        upcomingFollowUps,
      };
    },
  });
}

export function useAIInsights() {
  return useQuery({
    queryKey: ["ai-insights"],
    queryFn: async (): Promise<AIInsight[]> => {
      // For now, return mock AI insights
      // In a real implementation, this would call an AI service
      const mockInsights: AIInsight[] = [
        {
          id: "1",
          type: "opportunity",
          title: "High-Value Lead Detected",
          description: "Contact 'Ahmed Al-Rashid' from Tech Solutions LLC shows strong engagement patterns. Consider prioritizing follow-up.",
          priority: "high",
          actionable: true,
          confidence: 0.85,
          createdAt: new Date().toISOString(),
        },
        {
          id: "2",
          type: "trend",
          title: "Deal Velocity Increasing",
          description: "Your average deal closure time has improved by 23% this month compared to last month.",
          priority: "medium",
          actionable: false,
          confidence: 0.92,
          createdAt: new Date().toISOString(),
        },
        {
          id: "3",
          type: "recommendation",
          title: "Schedule Follow-ups",
          description: "You have 5 contacts with follow-up dates this week. Consider scheduling these to maintain momentum.",
          priority: "medium",
          actionable: true,
          confidence: 0.78,
          createdAt: new Date().toISOString(),
        },
        {
          id: "4",
          type: "risk",
          title: "Deal at Risk",
          description: "Deal 'Website Redesign Project' hasn't been updated in 2 weeks and is approaching its expected close date.",
          priority: "high",
          actionable: true,
          confidence: 0.71,
          createdAt: new Date().toISOString(),
        },
      ];

      return mockInsights;
    },
  });
}

export function useSalesAnalytics() {
  return useQuery({
    queryKey: ["sales-analytics"],
    queryFn: async (): Promise<SalesMetric[]> => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      // Get deals data for the last 6 months
      const sixMonthsAgo = new Date();
      sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

      const { data: deals, error } = await supabase
        .from("deals")
        .select("*, contacts!inner(*)")
        .eq("contacts.user_id", user.id)
        .gte("created_at", sixMonthsAgo.toISOString());

      if (error) throw error;

      // Group deals by month
      const monthlyData: { [key: string]: SalesMetric } = {};
      
      deals?.forEach(deal => {
        const date = new Date(deal.created_at || '');
        const monthKey = date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
        
        if (!monthlyData[monthKey]) {
          monthlyData[monthKey] = {
            period: monthKey,
            revenue: 0,
            deals: 0,
            contacts: 0,
            conversionRate: 0,
          };
        }
        
        monthlyData[monthKey].deals++;
        if (deal.status === 'closed_won') {
          monthlyData[monthKey].revenue += deal.amount || 0;
        }
      });

      // Convert to array and sort by date
      return Object.values(monthlyData).sort((a, b) => 
        new Date(a.period).getTime() - new Date(b.period).getTime()
      );
    },
  });
}
