
// Legacy file for backwards compatibility. Replaces by useCustomFieldsData/useCustomFieldsMutations.

import { useCustomFieldsData } from "./useCustomFieldsData";
import { useCustomFieldsMutations } from "./useCustomFieldsMutations";

export function useCustomFields(module: string) {
  const data = useCustomFieldsData(module);
  const mutations = useCustomFieldsMutations(module);
  return {
    ...data,
    ...mutations,
  };
}
