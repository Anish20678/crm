
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface SystemFieldConfig {
  id: string;
  user_id: string;
  module: string;
  field_name: string;
  is_visible: boolean;
  is_required: boolean;
  field_order: number;
  width_percentage: number;
  field_group: string;
  group_order: number;
  created_at: string;
  updated_at: string;
}

type UpsertSystemFieldConfigArgs = {
  module: string;
  field_name: string;
  is_visible?: boolean;
  is_required?: boolean;
  field_order?: number;
  width_percentage?: number;
  field_group?: string;
  group_order?: number;
};

export function useSystemFieldConfigs(module: string) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get system field configurations for a module
  const {
    data: systemFieldConfigs = [],
    isLoading,
    error,
  } = useQuery({
    queryKey: ["system-field-configs", module],
    queryFn: async (): Promise<SystemFieldConfig[]> => {
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase
        .from("system_field_configs")
        .select("*")
        .eq("user_id", user.id)
        .eq("module", module)
        .order("group_order", { ascending: true })
        .order("field_order", { ascending: true });

      if (error) throw error;
      return data || [];
    },
    enabled: !!module,
  });

  // Upsert system field configuration
  const upsertConfig = useMutation({
    mutationFn: async (config: UpsertSystemFieldConfigArgs) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const configData = {
        user_id: user.id,
        module: config.module,
        field_name: config.field_name,
        is_visible: config.is_visible ?? true,
        is_required: config.is_required ?? false,
        field_order: config.field_order ?? 0,
        width_percentage: config.width_percentage ?? 100,
        field_group: config.field_group ?? 'basic',
        group_order: config.group_order ?? 0,
      };

      const { data, error } = await supabase
        .from("system_field_configs")
        .upsert([configData], { onConflict: "user_id,module,field_name" })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["system-field-configs", module] });
      toast({ title: "Configuration saved", description: "System field settings updated successfully." });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error?.message || "Failed to save configuration", 
        variant: "destructive" 
      });
    },
  });

  // Bulk update field order
  const updateFieldOrder = useMutation({
    mutationFn: async (fieldUpdates: { field_name: string; field_order: number }[]) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const updates = fieldUpdates.map(update => ({
        user_id: user.id,
        module,
        field_name: update.field_name,
        field_order: update.field_order,
      }));

      const { error } = await supabase
        .from("system_field_configs")
        .upsert(updates, { onConflict: "user_id,module,field_name" });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["system-field-configs", module] });
      toast({ title: "Field order updated", description: "System field order saved successfully." });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error?.message || "Failed to update field order", 
        variant: "destructive" 
      });
    },
  });

  // Get visible fields in order
  const getVisibleFieldsInOrder = () => {
    return systemFieldConfigs
      .filter(config => config.is_visible)
      .sort((a, b) => {
        // First sort by group_order, then by field_order
        if (a.group_order !== b.group_order) {
          return a.group_order - b.group_order;
        }
        return a.field_order - b.field_order;
      });
  };

  // Bulk update fields by group
  const updateFieldsByGroup = useMutation({
    mutationFn: async (groupUpdates: { field_name: string; field_group: string; group_order: number }[]) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const updates = groupUpdates.map(update => ({
        user_id: user.id,
        module,
        field_name: update.field_name,
        field_group: update.field_group,
        group_order: update.group_order,
      }));

      const { error } = await supabase
        .from("system_field_configs")
        .upsert(updates, { onConflict: "user_id,module,field_name" });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["system-field-configs", module] });
      toast({ title: "Field groups updated", description: "Field group assignments saved successfully." });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error?.message || "Failed to update field groups", 
        variant: "destructive" 
      });
    },
  });

  return {
    systemFieldConfigs,
    isLoading,
    error,
    upsertConfig: upsertConfig.mutate,
    updateFieldOrder: updateFieldOrder.mutate,
    updateFieldsByGroup: updateFieldsByGroup.mutate,
    isUpdating: upsertConfig.isPending || updateFieldOrder.isPending || updateFieldsByGroup.isPending,
    getVisibleFieldsInOrder,
  };
}
