
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "./use-toast";

interface FlexibleFieldGroup {
  id: string;
  label: string;
  description?: string;
  default_expanded: boolean;
  group_order: number;
  is_system: boolean;
  user_id: string;
  module: string;
}

interface GroupTemplate {
  id: string;
  label: string;
  description?: string;
  fields?: Array<{
    label: string;
    field_type: string;
    required?: boolean;
  }>;
}

export function useFlexibleGroupManagement(module: string) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [fieldGroups, setFieldGroups] = useState<FlexibleFieldGroup[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isCreating, setIsCreating] = useState(false);

  // Load field groups
  const loadFieldGroups = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from("field_groups")
        .select("*")
        .eq("user_id", user.id)
        .eq("module", module)
        .order("group_order");

      if (error) throw error;

      setFieldGroups(data || []);
    } catch (error) {
      console.error("Error loading field groups:", error);
      toast({
        title: "Error loading field groups",
        description: "Failed to load field groups. Please refresh the page.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadFieldGroups();
  }, [user, module]);

  // Get available templates based on module
  const getAvailableTemplates = (): GroupTemplate[] => {
    const templates: Record<string, GroupTemplate[]> = {
      lead: [
        {
          id: "contact_info",
          label: "Contact Information",
          description: "Essential contact details for leads",
          fields: [
            { label: "First Name", field_type: "text", required: true },
            { label: "Last Name", field_type: "text" },
            { label: "Email", field_type: "email" },
            { label: "Phone", field_type: "phone" },
          ],
        },
        {
          id: "business_profile",
          label: "Business Profile",
          description: "Company and business information",
          fields: [
            { label: "Company", field_type: "text" },
            { label: "Position", field_type: "text" },
            { label: "Industry", field_type: "select" },
            { label: "Company Size", field_type: "select" },
          ],
        },
        {
          id: "lead_qualification",
          label: "Lead Qualification",
          description: "Lead scoring and qualification fields",
          fields: [
            { label: "Lead Source", field_type: "select" },
            { label: "Lead Score", field_type: "number" },
            { label: "Budget Range", field_type: "select" },
            { label: "Timeline", field_type: "select" },
          ],
        },
        {
          id: "communication_prefs",
          label: "Communication Preferences",
          description: "How the lead prefers to be contacted",
          fields: [
            { label: "Preferred Contact Method", field_type: "select" },
            { label: "Best Time to Call", field_type: "select" },
            { label: "Time Zone", field_type: "select" },
          ],
        },
      ],
      contact: [
        {
          id: "personal_info",
          label: "Personal Information",
          description: "Basic personal details",
          fields: [
            { label: "First Name", field_type: "text", required: true },
            { label: "Last Name", field_type: "text" },
            { label: "Email", field_type: "email" },
            { label: "Phone", field_type: "phone" },
          ],
        },
        {
          id: "professional_info",
          label: "Professional Information",
          description: "Work and business details",
          fields: [
            { label: "Company", field_type: "text" },
            { label: "Job Title", field_type: "text" },
            { label: "Department", field_type: "text" },
          ],
        },
      ],
      deal: [
        {
          id: "deal_basics",
          label: "Deal Basics",
          description: "Core deal information",
          fields: [
            { label: "Deal Name", field_type: "text", required: true },
            { label: "Deal Value", field_type: "currency" },
            { label: "Close Date", field_type: "date" },
            { label: "Probability", field_type: "number" },
          ],
        },
        {
          id: "project_details",
          label: "Project Details",
          description: "Project specifications",
          fields: [
            { label: "Project Type", field_type: "select" },
            { label: "Project Scope", field_type: "textarea" },
            { label: "Requirements", field_type: "textarea" },
          ],
        },
      ],
      task: [
        {
          id: "task_details",
          label: "Task Details",
          description: "Core task information",
          fields: [
            { label: "Task Title", field_type: "text", required: true },
            { label: "Description", field_type: "textarea" },
            { label: "Due Date", field_type: "date" },
            { label: "Priority", field_type: "select" },
          ],
        },
        {
          id: "assignment_tracking",
          label: "Assignment & Tracking",
          description: "Task assignment and progress",
          fields: [
            { label: "Assigned To", field_type: "text" },
            { label: "Status", field_type: "select" },
            { label: "Progress", field_type: "number" },
          ],
        },
      ],
    };

    return templates[module] || [];
  };

  // Create group from template
  const createGroupFromTemplate = async (templateId: string): Promise<string | null> => {
    if (!user) return null;

    const template = getAvailableTemplates().find(t => t.id === templateId);
    if (!template) return null;

    setIsCreating(true);

    try {
      // Calculate next order
      const nextOrder = fieldGroups.length;
      
      // Create the group
      const { data: groupData, error: groupError } = await supabase
        .from("field_groups")
        .insert({
          id: templateId,
          user_id: user.id,
          module,
          label: template.label,
          description: template.description,
          default_expanded: true,
          group_order: nextOrder,
          is_system: false,
        })
        .select()
        .single();

      if (groupError) throw groupError;

      // If template has suggested fields, we could create them here
      // For now, we'll just create the group and let users add fields manually

      await loadFieldGroups();

      toast({
        title: "Group created",
        description: `${template.label} group has been created successfully.`,
      });

      return groupData.id;
    } catch (error) {
      console.error("Error creating group from template:", error);
      toast({
        title: "Error creating group",
        description: "Failed to create group from template. Please try again.",
        variant: "destructive",
      });
      return null;
    } finally {
      setIsCreating(false);
    }
  };

  // Create custom group
  const createCustomGroup = async (groupData: {
    id: string;
    label: string;
    description?: string;
    defaultExpanded: boolean;
  }): Promise<string | null> => {
    if (!user) return null;

    setIsCreating(true);

    try {
      const nextOrder = fieldGroups.length;
      
      const { data, error } = await supabase
        .from("field_groups")
        .insert({
          id: groupData.id,
          user_id: user.id,
          module,
          label: groupData.label,
          description: groupData.description,
          default_expanded: groupData.defaultExpanded,
          group_order: nextOrder,
          is_system: false,
        })
        .select()
        .single();

      if (error) throw error;

      await loadFieldGroups();

      toast({
        title: "Group created",
        description: `${groupData.label} group has been created successfully.`,
      });

      return data.id;
    } catch (error) {
      console.error("Error creating custom group:", error);
      toast({
        title: "Error creating group",
        description: "Failed to create custom group. Please try again.",
        variant: "destructive",
      });
      return null;
    } finally {
      setIsCreating(false);
    }
  };

  return {
    fieldGroups,
    isLoading,
    isCreating,
    getAvailableTemplates,
    createGroupFromTemplate,
    createCustomGroup,
    refetch: loadFieldGroups,
  };
}
