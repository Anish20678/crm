
import { useState } from "react";
import { useCustomFieldsMutations } from "./useCustomFieldsMutations";
import { useCustomFieldsData } from "./useCustomFieldsData";
import { useToast } from "./use-toast";
import { generateOrderIndex } from "@/lib/orderIndexUtils";
import type { CustomFieldType } from "@/lib/types/customFields";

export function useFieldCreation(module: string) {
  const { upsertField } = useCustomFieldsMutations(module);
  const { customFields, refetch } = useCustomFieldsData(module);
  const { toast } = useToast();
  const [isCreating, setIsCreating] = useState(false);

  const createField = async (
    fieldType: CustomFieldType,
    options?: {
      label?: string;
      group?: string;
      required?: boolean;
      placeholder?: string;
      description?: string;
    }
  ) => {
    setIsCreating(true);
    
    try {
      // Generate field name and label
      const timestamp = Date.now().toString().slice(-6);
      const fieldName = `custom_${fieldType}_${timestamp}`;
      const fieldLabel = options?.label || `New ${fieldType.charAt(0).toUpperCase() + fieldType.slice(1)} Field`;
      
      // Use specified group or default to 'custom'
      const fieldGroup = options?.group || 'custom';
      
      // Generate proper order index using existing fields in the same group
      const groupFields = customFields.filter(f => f.field_group === fieldGroup);
      const orderIndex = generateOrderIndex(groupFields);
      
      const fieldData = {
        module,
        name: fieldName,
        label: fieldLabel,
        field_type: fieldType,
        required: options?.required || false,
        visible: true,
        order_index: orderIndex,
        field_group: fieldGroup,
        options: fieldType === 'select' ? ['Option 1', 'Option 2', 'Option 3'] : undefined,
        placeholder: options?.placeholder,
        description: options?.description,
      };

      console.log('Creating field with data:', fieldData);
      await upsertField(fieldData);
      
      // Refetch to ensure sync
      setTimeout(() => {
        refetch();
      }, 500);
      
      toast({
        title: "Field created",
        description: `${fieldLabel} has been added to the ${fieldGroup} group.`,
      });
      
      return fieldName;
    } catch (error) {
      console.error("Failed to create field:", error);
      toast({
        title: "Error",
        description: "Failed to create field. Please try again.",
        variant: "destructive",
      });
      return null;
    } finally {
      setIsCreating(false);
    }
  };

  const createFieldInGroup = async (
    fieldType: CustomFieldType,
    groupId: string,
    label?: string
  ) => {
    console.log(`Creating ${fieldType} field in group: ${groupId}`);
    
    return createField(fieldType, {
      label: label || `New ${fieldType.charAt(0).toUpperCase() + fieldType.slice(1)} Field`,
      group: groupId,
      required: false,
    });
  };

  return {
    createField,
    createFieldInGroup,
    isCreating,
  };
}
