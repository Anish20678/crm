
import { useState } from "react";
import { useFieldGroups } from "./useFieldGroups";
import { useToast } from "./use-toast";
import { getFieldGroupsForModule } from "@/lib/systemFields";

export function useEnhancedGroupManagement(module: string) {
  const { fieldGroups, upsertGroup, deleteGroup } = useFieldGroups(module);
  const { toast } = useToast();
  const [isCreating, setIsCreating] = useState(false);

  const createCustomGroup = async (groupData: {
    id?: string;
    label: string;
    description?: string;
    defaultExpanded?: boolean;
  }) => {
    setIsCreating(true);
    
    try {
      const groupId = groupData.id || `custom_${Date.now()}`;
      
      // Check if group ID already exists
      const existingGroup = fieldGroups.find(g => g.id === groupId);
      if (existingGroup) {
        toast({
          title: "Group ID already exists",
          description: "Please choose a different group name.",
          variant: "destructive",
        });
        return false;
      }

      console.log(`Creating custom group: ${groupId}`);
      
      await upsertGroup({
        id: groupId,
        label: groupData.label,
        description: groupData.description,
        default_expanded: groupData.defaultExpanded ?? true,
        group_order: fieldGroups.length,
        is_system: false,
      });
      
      toast({
        title: "Group created",
        description: `${groupData.label} group has been created successfully.`,
      });
      
      return groupId;
    } catch (error) {
      console.error("Failed to create group:", error);
      toast({
        title: "Error creating group",
        description: "Failed to create group. Please try again.",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsCreating(false);
    }
  };

  const updateGroupProperties = async (groupId: string, updates: {
    label?: string;
    description?: string;
    defaultExpanded?: boolean;
  }) => {
    try {
      const existingGroup = fieldGroups.find(g => g.id === groupId);
      if (!existingGroup) {
        toast({
          title: "Group not found",
          description: "The group you're trying to update doesn't exist.",
          variant: "destructive",
        });
        return false;
      }

      await upsertGroup({
        id: groupId,
        label: updates.label || existingGroup.label,
        description: updates.description !== undefined ? updates.description : existingGroup.description,
        default_expanded: updates.defaultExpanded !== undefined ? updates.defaultExpanded : existingGroup.default_expanded,
        group_order: existingGroup.group_order,
        is_system: existingGroup.is_system,
      });
      
      toast({
        title: "Group updated",
        description: `${updates.label || existingGroup.label} has been updated.`,
      });
      
      return true;
    } catch (error) {
      console.error("Failed to update group:", error);
      toast({
        title: "Error updating group",
        description: "Failed to update group. Please try again.",
        variant: "destructive",
      });
      return false;
    }
  };

  const deleteCustomGroup = async (groupId: string) => {
    try {
      const systemGroups = getFieldGroupsForModule(module);
      const isSystemGroup = systemGroups.some(g => g.id === groupId);
      
      if (isSystemGroup) {
        toast({
          title: "Cannot delete system group",
          description: "System groups cannot be deleted.",
          variant: "destructive",
        });
        return false;
      }

      const group = fieldGroups.find(g => g.id === groupId);
      if (!group) {
        toast({
          title: "Group not found",
          description: "The group you're trying to delete doesn't exist.",
          variant: "destructive",
        });
        return false;
      }

      await deleteGroup(groupId);
      
      toast({
        title: "Group deleted",
        description: `${group.label} has been deleted.`,
      });
      
      return true;
    } catch (error) {
      console.error("Failed to delete group:", error);
      toast({
        title: "Error deleting group",
        description: "Failed to delete group. Please try again.",
        variant: "destructive",
      });
      return false;
    }
  };

  const canDeleteGroup = (groupId: string) => {
    const systemGroups = getFieldGroupsForModule(module);
    return !systemGroups.some(g => g.id === groupId);
  };

  const canEditGroup = (groupId: string) => {
    // Allow editing of all groups, but with different permissions
    return true;
  };

  return {
    createCustomGroup,
    updateGroupProperties,
    deleteCustomGroup,
    canDeleteGroup,
    canEditGroup,
    isCreating,
    fieldGroups,
  };
}
