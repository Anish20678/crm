
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

export interface FieldTemplate {
  id: string;
  user_id: string;
  template_name: string;
  template_type: 'field_group' | 'complete_module' | 'field_set';
  module: string;
  template_config: Record<string, any>;
  description?: string;
  is_system_template: boolean;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export const useFieldTemplates = (module: string) => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: templates = [], isLoading } = useQuery({
    queryKey: ["field-templates", module, user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from("field_templates")
        .select("*")
        .eq("module", module)
        .eq("is_active", true)
        .or(`user_id.eq.${user.id},is_system_template.eq.true`)
        .order("is_system_template", { ascending: false })
        .order("template_name");

      if (error) throw error;
      return data as FieldTemplate[];
    },
    enabled: !!user,
  });

  const createTemplate = useMutation({
    mutationFn: async (template: Omit<FieldTemplate, 'id' | 'user_id' | 'created_at' | 'updated_at' | 'is_system_template'>) => {
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from("field_templates")
        .insert({
          ...template,
          user_id: user.id,
          is_system_template: false,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["field-templates", module] });
      toast({
        title: "Template created",
        description: "Field template has been created successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error creating template",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateTemplate = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<FieldTemplate> & { id: string }) => {
      const { data, error } = await supabase
        .from("field_templates")
        .update(updates)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["field-templates", module] });
      toast({
        title: "Template updated",
        description: "Field template has been updated successfully.",
      });
    },
  });

  const deleteTemplate = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("field_templates")
        .delete()
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["field-templates", module] });
      toast({
        title: "Template deleted",
        description: "Field template has been deleted successfully.",
      });
    },
  });

  const applyTemplate = useMutation({
    mutationFn: async (templateId: string) => {
      if (!user) throw new Error("User not authenticated");

      // Create a bulk operation record
      const { data, error } = await supabase
        .from("field_bulk_operations")
        .insert({
          user_id: user.id,
          operation_type: "template_apply",
          module,
          affected_fields: [],
          operation_config: { template_id: templateId },
          status: "completed",
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast({
        title: "Template applied",
        description: "Field template has been applied successfully.",
      });
      // Invalidate related queries
      queryClient.invalidateQueries({ queryKey: ["system-field-configs"] });
      queryClient.invalidateQueries({ queryKey: ["field-groups"] });
    },
  });

  return {
    templates,
    isLoading,
    createTemplate,
    updateTemplate,
    deleteTemplate,
    applyTemplate,
  };
};
