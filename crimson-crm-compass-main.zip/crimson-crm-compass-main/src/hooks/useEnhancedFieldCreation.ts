
import { useState } from "react";
import { useCustomFieldsMutations } from "./useCustomFieldsMutations";
import { useCustomFieldsData } from "./useCustomFieldsData";
import { useToast } from "./use-toast";
import { generateOrderIndex } from "@/lib/orderIndexUtils";
import type { CustomFieldType } from "@/lib/types/customFields";

export function useEnhancedFieldCreation(module: string) {
  const { upsertField } = useCustomFieldsMutations(module);
  const { customFields, refetch } = useCustomFieldsData(module);
  const { toast } = useToast();
  const [isCreating, setIsCreating] = useState(false);

  const createFieldWithType = async (
    fieldType: CustomFieldType,
    groupId: string,
    options?: {
      label?: string;
      required?: boolean;
      placeholder?: string;
      description?: string;
    }
  ) => {
    setIsCreating(true);
    
    try {
      console.log(`Creating ${fieldType} field in group: ${groupId}`);
      
      // Generate field name and label
      const timestamp = Date.now().toString().slice(-6);
      const fieldName = `custom_${fieldType}_${timestamp}`;
      const fieldLabel = options?.label || `New ${fieldType.charAt(0).toUpperCase() + fieldType.slice(1)} Field`;
      
      // Generate proper order index using existing fields in the group
      const groupFields = customFields.filter(f => f.field_group === groupId);
      const orderIndex = generateOrderIndex(groupFields);
      
      const fieldData = {
        module,
        name: fieldName,
        label: fieldLabel,
        field_type: fieldType,
        required: options?.required || false,
        visible: true,
        order_index: orderIndex,
        field_group: groupId,
        options: fieldType === 'select' ? ['Option 1', 'Option 2', 'Option 3'] : undefined,
        placeholder: options?.placeholder,
        description: options?.description,
      };

      console.log('Creating field with data:', fieldData);
      await upsertField(fieldData);
      
      // Refetch to ensure sync
      setTimeout(() => {
        refetch();
      }, 500);
      
      toast({
        title: "Field created successfully",
        description: `${fieldLabel} has been added to the ${groupId} group.`,
      });
      
      return fieldName;
    } catch (error) {
      console.error("Failed to create field:", error);
      toast({
        title: "Error creating field",
        description: "Failed to create field. Please try again.",
        variant: "destructive",
      });
      return null;
    } finally {
      setIsCreating(false);
    }
  };

  const createQuickTextField = (groupId: string, label?: string) => {
    return createFieldWithType('text', groupId, { label });
  };

  const createQuickNumberField = (groupId: string, label?: string) => {
    return createFieldWithType('number', groupId, { label });
  };

  const createQuickEmailField = (groupId: string, label?: string) => {
    return createFieldWithType('email', groupId, { label });
  };

  const createQuickPhoneField = (groupId: string, label?: string) => {
    return createFieldWithType('phone', groupId, { label });
  };

  const createQuickSelectField = (groupId: string, label?: string) => {
    return createFieldWithType('select', groupId, { label });
  };

  const createQuickDateField = (groupId: string, label?: string) => {
    return createFieldWithType('date', groupId, { label });
  };

  const createQuickBooleanField = (groupId: string, label?: string) => {
    return createFieldWithType('boolean', groupId, { label });
  };

  const createQuickTextareaField = (groupId: string, label?: string) => {
    return createFieldWithType('textarea', groupId, { label });
  };

  return {
    createFieldWithType,
    createQuickTextField,
    createQuickNumberField,
    createQuickEmailField,
    createQuickPhoneField,
    createQuickSelectField,
    createQuickDateField,
    createQuickBooleanField,
    createQuickTextareaField,
    isCreating,
  };
}
