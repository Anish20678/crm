
import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Settings, Save, Mail, Clock, Shield, Link } from "lucide-react";
import { EmailSettings as EmailSettingsType } from "@/lib/types";

export function EmailSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch email settings
  const { data: settings, isLoading } = useQuery({
    queryKey: ["email-settings"],
    queryFn: async (): Promise<EmailSettingsType | null> => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from('email_settings')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
  });

  const [formData, setFormData] = useState<Partial<EmailSettingsType>>({});

  // Update form when settings load
  useEffect(() => {
    if (settings) {
      setFormData(settings);
    }
  }, [settings]);

  const saveSettingsMutation = useMutation({
    mutationFn: async (data: Partial<EmailSettingsType>) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const settingsData = {
        ...data,
        user_id: user.id,
      };

      if (settings?.id) {
        // Update existing settings
        const { data: result, error } = await supabase
          .from('email_settings')
          .update(settingsData)
          .eq('id', settings.id)
          .select()
          .single();
        if (error) throw error;
        return result;
      } else {
        // Create new settings
        const { data: result, error } = await supabase
          .from('email_settings')
          .insert(settingsData)
          .select()
          .single();
        if (error) throw error;
        return result;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["email-settings"] });
      toast({
        title: "Settings saved",
        description: "Email settings have been updated successfully",
      });
    },
    onError: (error) => {
      console.error("Save error:", error);
      toast({
        title: "Error",
        description: "Failed to save email settings",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    saveSettingsMutation.mutate(formData);
  };

  const updateFormData = (key: keyof EmailSettingsType, value: any) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  if (isLoading) {
    return <div className="flex justify-center p-8">Loading settings...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold">Email Settings</h2>
        <p className="text-muted-foreground">Configure your email sending preferences</p>
      </div>

      <div className="grid gap-6">
        {/* Sender Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5" />
              Sender Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="from_name">From Name</Label>
                <Input
                  id="from_name"
                  value={formData.from_name || ""}
                  onChange={(e) => updateFormData("from_name", e.target.value)}
                  placeholder="Your Company"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="from_email">From Email</Label>
                <Input
                  id="from_email"
                  type="email"
                  value={formData.from_email || ""}
                  onChange={(e) => updateFormData("from_email", e.target.value)}
                  placeholder="noreply@yourcompany.com"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="reply_to_email">Reply-To Email</Label>
              <Input
                id="reply_to_email"
                type="email"
                value={formData.reply_to_email || ""}
                onChange={(e) => updateFormData("reply_to_email", e.target.value)}
                placeholder="support@yourcompany.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signature">Email Signature</Label>
              <Textarea
                id="signature"
                value={formData.signature || ""}
                onChange={(e) => updateFormData("signature", e.target.value)}
                placeholder="Best regards,&#10;Your Company Team"
                rows={4}
              />
            </div>
          </CardContent>
        </Card>

        {/* Tracking Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Tracking & Analytics
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Track Email Opens</Label>
                <p className="text-sm text-muted-foreground">
                  Track when recipients open your emails
                </p>
              </div>
              <Switch
                checked={formData.track_opens || false}
                onCheckedChange={(checked) => updateFormData("track_opens", checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label>Track Link Clicks</Label>
                <p className="text-sm text-muted-foreground">
                  Track when recipients click links in your emails
                </p>
              </div>
              <Switch
                checked={formData.track_clicks || false}
                onCheckedChange={(checked) => updateFormData("track_clicks", checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label>Bounce Handling</Label>
                <p className="text-sm text-muted-foreground">
                  Automatically handle bounced emails
                </p>
              </div>
              <Switch
                checked={formData.bounce_handling || false}
                onCheckedChange={(checked) => updateFormData("bounce_handling", checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label>Include Unsubscribe Link</Label>
                <p className="text-sm text-muted-foreground">
                  Add unsubscribe link to all emails
                </p>
              </div>
              <Switch
                checked={formData.unsubscribe_link || false}
                onCheckedChange={(checked) => updateFormData("unsubscribe_link", checked)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Delivery Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Delivery Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="daily_email_limit">Daily Email Limit</Label>
                <Input
                  id="daily_email_limit"
                  type="number"
                  value={formData.daily_email_limit || 1000}
                  onChange={(e) => updateFormData("daily_email_limit", parseInt(e.target.value))}
                  min="1"
                  max="10000"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="time_zone">Time Zone</Label>
                <Select
                  value={formData.time_zone || "UTC"}
                  onValueChange={(value) => updateFormData("time_zone", value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="UTC">UTC</SelectItem>
                    <SelectItem value="America/New_York">Eastern Time</SelectItem>
                    <SelectItem value="America/Chicago">Central Time</SelectItem>
                    <SelectItem value="America/Denver">Mountain Time</SelectItem>
                    <SelectItem value="America/Los_Angeles">Pacific Time</SelectItem>
                    <SelectItem value="Europe/London">London</SelectItem>
                    <SelectItem value="Europe/Paris">Paris</SelectItem>
                    <SelectItem value="Asia/Tokyo">Tokyo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="sending_frequency">Sending Frequency</Label>
              <Select
                value={formData.sending_frequency || "normal"}
                onValueChange={(value) => updateFormData("sending_frequency", value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="slow">Slow (Safer for deliverability)</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="fast">Fast (Higher volume)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Auto Responder */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Link className="h-5 w-5" />
              Auto Responder
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Enable Auto Responder</Label>
                <p className="text-sm text-muted-foreground">
                  Automatically respond to incoming emails
                </p>
              </div>
              <Switch
                checked={formData.enable_auto_responder || false}
                onCheckedChange={(checked) => updateFormData("enable_auto_responder", checked)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button 
            onClick={handleSave} 
            disabled={saveSettingsMutation.isPending}
            className="flex items-center gap-2"
          >
            <Save className="h-4 w-4" />
            {saveSettingsMutation.isPending ? "Saving..." : "Save Settings"}
          </Button>
        </div>
      </div>
    </div>
  );
}
