
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { Mail, Search, Filter, ArrowUpRight, ArrowDownLeft } from "lucide-react";
import { CommunicationLog, Contact } from "@/lib/types";
import { format } from "date-fns";

interface ExtendedCommunicationLog extends CommunicationLog {
  contact?: Pick<Contact, 'id' | 'first_name' | 'last_name' | 'email'>;
}

export function EmailHistory() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [directionFilter, setDirectionFilter] = useState("all");

  const { data: emailLogs = [], isLoading } = useQuery({
    queryKey: ["email-history"],
    queryFn: async (): Promise<ExtendedCommunicationLog[]> => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from("communication_logs")
        .select(`
          *,
          contacts (
            id,
            first_name,
            last_name,
            email
          )
        `)
        .eq("user_id", user.id)
        .eq("communication_type", "email")
        .order("created_at", { ascending: false });

      if (error) throw error;
      
      return (data || []).map(log => ({
        ...log,
        communication_type: log.communication_type as CommunicationLog['communication_type'],
        direction: log.direction as CommunicationLog['direction'],
        status: log.status as CommunicationLog['status'],
        contact: log.contacts ? {
          id: log.contacts.id,
          first_name: log.contacts.first_name,
          last_name: log.contacts.last_name,
          email: log.contacts.email,
        } : undefined
      }));
    },
  });

  // Filter emails based on search and filters
  const filteredEmails = emailLogs.filter(email => {
    const matchesSearch = searchTerm === "" || 
      email.subject?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      email.contact?.first_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      email.contact?.last_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      email.contact?.email?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || email.status === statusFilter;
    const matchesDirection = directionFilter === "all" || email.direction === directionFilter;
    
    return matchesSearch && matchesStatus && matchesDirection;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'sent': return "bg-green-100 text-green-800";
      case 'delivered': return "bg-blue-100 text-blue-800";
      case 'read': return "bg-purple-100 text-purple-800";
      case 'failed': return "bg-red-100 text-red-800";
      case 'pending': return "bg-yellow-100 text-yellow-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  if (isLoading) {
    return <div className="flex justify-center p-8">Loading email history...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold">Email History</h2>
        <p className="text-muted-foreground">View all sent and received emails</p>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search emails..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="sent">Sent</SelectItem>
                <SelectItem value="delivered">Delivered</SelectItem>
                <SelectItem value="read">Read</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>
            <Select value={directionFilter} onValueChange={setDirectionFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by direction" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Directions</SelectItem>
                <SelectItem value="outbound">Sent</SelectItem>
                <SelectItem value="inbound">Received</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Email List */}
      <div className="space-y-4">
        {filteredEmails.map((email) => (
          <Card key={email.id}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    {email.direction === "outbound" ? (
                      <ArrowUpRight className="h-4 w-4 text-blue-600" />
                    ) : (
                      <ArrowDownLeft className="h-4 w-4 text-green-600" />
                    )}
                    <h3 className="font-medium">{email.subject || "No Subject"}</h3>
                    <Badge className={getStatusColor(email.status)}>
                      {email.status}
                    </Badge>
                  </div>
                  
                  <div className="text-sm text-muted-foreground mb-2">
                    {email.direction === "outbound" ? "To: " : "From: "}
                    {email.contact ? (
                      `${email.contact.first_name} ${email.contact.last_name} (${email.contact.email})`
                    ) : (
                      "Unknown Contact"
                    )}
                  </div>
                  
                  {email.content && (
                    <p className="text-sm text-gray-700 line-clamp-2 mb-2">
                      {email.content}
                    </p>
                  )}
                  
                  <div className="text-xs text-muted-foreground">
                    {format(new Date(email.created_at), "MMM d, yyyy 'at' h:mm a")}
                  </div>
                </div>
                
                <div className="flex items-center gap-2 ml-4">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredEmails.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Mail className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No emails found</h3>
            <p className="text-muted-foreground">
              {searchTerm || statusFilter !== "all" || directionFilter !== "all"
                ? "Try adjusting your filters to see more results"
                : "Start sending emails to see your communication history here"
              }
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
