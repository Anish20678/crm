
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

interface EmailSchedulerProps {
  formData: {
    sendLater: boolean;
    scheduledAt: string;
  };
  onFormChange: (data: Partial<EmailSchedulerProps['formData']>) => void;
}

export function EmailScheduler({ formData, onFormChange }: EmailSchedulerProps) {
  return (
    <>
      <div className="flex items-center space-x-2">
        <Switch
          checked={formData.sendLater}
          onCheckedChange={(checked) => onFormChange({ sendLater: checked })}
        />
        <Label>Schedule for later</Label>
      </div>

      {formData.sendLater && (
        <div className="space-y-2">
          <Label htmlFor="scheduledAt">Schedule Date & Time</Label>
          <Input
            id="scheduledAt"
            type="datetime-local"
            value={formData.scheduledAt}
            onChange={(e) => onFormChange({ scheduledAt: e.target.value })}
          />
        </div>
      )}
    </>
  );
}
