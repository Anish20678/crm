
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface EmailFormFieldsProps {
  formData: {
    to: string;
    subject: string;
    body: string;
  };
  onFormChange: (data: Partial<EmailFormFieldsProps['formData']>) => void;
}

export function EmailFormFields({ formData, onFormChange }: EmailFormFieldsProps) {
  return (
    <>
      <div className="space-y-2">
        <Label htmlFor="to">To *</Label>
        <Input
          id="to"
          type="email"
          placeholder="recipient@example.com"
          value={formData.to}
          onChange={(e) => onFormChange({ to: e.target.value })}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="subject">Subject *</Label>
        <Input
          id="subject"
          placeholder="Email subject"
          value={formData.subject}
          onChange={(e) => onFormChange({ subject: e.target.value })}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="body">Message *</Label>
        <Textarea
          id="body"
          placeholder="Write your email message here..."
          value={formData.body}
          onChange={(e) => onFormChange({ body: e.target.value })}
          rows={12}
        />
      </div>
    </>
  );
}
