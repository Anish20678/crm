
import { Button } from "@/components/ui/button";
import { Send, Save } from "lucide-react";

interface EmailActionsProps {
  onSend: () => void;
  isSending: boolean;
}

export function EmailActions({ onSend, isSending }: EmailActionsProps) {
  return (
    <div className="flex gap-2">
      <Button 
        onClick={onSend} 
        disabled={isSending}
        className="flex items-center gap-2"
      >
        <Send className="h-4 w-4" />
        {isSending ? "Sending..." : "Send Email"}
      </Button>
      <Button variant="outline" className="flex items-center gap-2">
        <Save className="h-4 w-4" />
        Save as Draft
      </Button>
    </div>
  );
}
