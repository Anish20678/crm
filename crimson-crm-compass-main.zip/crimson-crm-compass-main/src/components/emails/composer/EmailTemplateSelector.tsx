
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { FileText } from "lucide-react";
import { EmailTemplate } from "@/lib/types";

interface EmailTemplateSelectorProps {
  templates: EmailTemplate[];
  templateId: string;
  onTemplateSelect: (templateId: string) => void;
}

export function EmailTemplateSelector({ templates, templateId, onTemplateSelect }: EmailTemplateSelectorProps) {
  return (
    <div className="space-y-2">
      <Label htmlFor="template">Use Template (Optional)</Label>
      <Select value={templateId} onValueChange={onTemplateSelect}>
        <SelectTrigger>
          <SelectValue placeholder="Select a template" />
        </SelectTrigger>
        <SelectContent>
          {templates.map((template) => (
            <SelectItem key={template.id} value={template.id}>
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                {template.name}
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
