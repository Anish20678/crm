
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Users } from "lucide-react";
import { Contact } from "@/lib/types";

interface EmailContactSelectorProps {
  contacts: Contact[];
  onContactSelect: (contactId: string) => void;
}

export function EmailContactSelector({ contacts, onContactSelect }: EmailContactSelectorProps) {
  return (
    <div className="space-y-2">
      <Label htmlFor="contact">Select Contact</Label>
      <Select onValueChange={onContactSelect}>
        <SelectTrigger>
          <SelectValue placeholder="Select a contact" />
        </SelectTrigger>
        <SelectContent>
          {contacts.map((contact) => (
            <SelectItem key={contact.id} value={contact.id}>
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                {contact.first_name} {contact.last_name} - {contact.email}
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
