
import { Button } from "@/components/ui/button";
import { Dialog, DialogTrigger } from "@/components/ui/dialog";
import { Plus } from "lucide-react";
import { useEmailTemplates } from "@/hooks/useEmailTemplates";
import { EmailTemplateCard } from "./template/EmailTemplateCard";
import { EmailTemplateForm } from "./template/EmailTemplateForm";
import { EmailTemplatePreview } from "./template/EmailTemplatePreview";
import { EmailTemplateEmptyState } from "./template/EmailTemplateEmptyState";

export function EmailTemplateManager() {
  const {
    templates,
    isLoading,
    newTemplate,
    setNewTemplate,
    isCreateDialogOpen,
    setIsCreateDialogOpen,
    editingTemplate,
    previewTemplate,
    setPreviewTemplate,
    createTemplateMutation,
    updateTemplateMutation,
    deleteTemplateMutation,
    resetForm,
    handleCreateTemplate,
    handleEditTemplate,
    handleDeleteTemplate,
    handleDuplicateTemplate,
  } = useEmailTemplates();

  if (isLoading) {
    return <div className="flex justify-center p-8">Loading templates...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-semibold">Email Templates</h2>
          <p className="text-muted-foreground">Create and manage reusable email templates</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2" onClick={resetForm}>
              <Plus className="h-4 w-4" />
              New Template
            </Button>
          </DialogTrigger>
        </Dialog>
      </div>

      {templates.length === 0 ? (
        <EmailTemplateEmptyState onCreateTemplate={() => setIsCreateDialogOpen(true)} />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {templates.map((template) => (
            <EmailTemplateCard
              key={template.id}
              template={template}
              onEdit={handleEditTemplate}
              onDelete={handleDeleteTemplate}
              onDuplicate={handleDuplicateTemplate}
              onPreview={setPreviewTemplate}
              isDeleting={deleteTemplateMutation.isPending}
              isDuplicating={createTemplateMutation.isPending}
            />
          ))}
        </div>
      )}

      <EmailTemplateForm
        isOpen={isCreateDialogOpen}
        onOpenChange={setIsCreateDialogOpen}
        template={newTemplate}
        onTemplateChange={setNewTemplate}
        onSubmit={handleCreateTemplate}
        onCancel={resetForm}
        isEditing={!!editingTemplate}
        isLoading={createTemplateMutation.isPending || updateTemplateMutation.isPending}
      />

      <EmailTemplatePreview
        template={previewTemplate}
        isOpen={!!previewTemplate}
        onClose={() => setPreviewTemplate(null)}
        onEdit={handleEditTemplate}
      />
    </div>
  );
}
