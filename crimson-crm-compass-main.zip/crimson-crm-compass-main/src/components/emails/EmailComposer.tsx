
import { useEmailComposer } from "@/hooks/useEmailComposer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail } from "lucide-react";
import { EmailTemplateSelector } from "./composer/EmailTemplateSelector";
import { EmailContactSelector } from "./composer/EmailContactSelector";
import { EmailFormFields } from "./composer/EmailFormFields";
import { EmailScheduler } from "./composer/EmailScheduler";
import { EmailActions } from "./composer/EmailActions";

export function EmailComposer() {
  const {
    formData,
    setFormData,
    templates,
    contacts,
    handleTemplateSelect,
    handleContactSelect,
    handleSend,
    sendEmailMutation
  } = useEmailComposer();

  const handleFormChange = (data: Partial<typeof formData>) => {
    setFormData(prev => ({ ...prev, ...data }));
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Compose Email
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <EmailTemplateSelector 
              templates={templates}
              templateId={formData.templateId}
              onTemplateSelect={handleTemplateSelect}
            />
            <EmailContactSelector 
              contacts={contacts}
              onContactSelect={handleContactSelect}
            />
          </div>

          <EmailFormFields 
            formData={formData}
            onFormChange={handleFormChange}
          />
          
          <EmailScheduler 
            formData={formData}
            onFormChange={handleFormChange}
          />

          <EmailActions 
            onSend={handleSend}
            isSending={sendEmailMutation.isPending}
          />

          <div className="mt-2 text-xs text-muted-foreground">
            {/* TODO: To enable email sending, please request integration with your preferred email service */}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
