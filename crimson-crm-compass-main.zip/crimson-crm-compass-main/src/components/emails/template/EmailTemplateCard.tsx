
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit, Trash2, Copy, Eye } from "lucide-react";
import { EmailTemplate } from "@/lib/types";
import { format } from "date-fns";

interface EmailTemplateCardProps {
  template: EmailTemplate;
  onEdit: (template: EmailTemplate) => void;
  onDelete: (templateId: string) => void;
  onDuplicate: (template: EmailTemplate) => void;
  onPreview: (template: EmailTemplate) => void;
  isDeleting: boolean;
  isDuplicating: boolean;
}

export function EmailTemplateCard({
  template,
  onEdit,
  onDelete,
  onDuplicate,
  onPreview,
  isDeleting,
  isDuplicating,
}: EmailTemplateCardProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">{template.name}</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              {template.subject}
            </p>
          </div>
          <div className="flex items-center gap-1">
            <Badge variant={template.is_active ? "default" : "secondary"}>
              {template.is_active ? "Active" : "Inactive"}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="text-sm text-muted-foreground">
            <Badge variant="outline">{template.template_type}</Badge>
          </div>
          
          <p className="text-sm line-clamp-3">
            {template.body}
          </p>

          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">
              Created {template.created_at ? format(new Date(template.created_at), "MMM d, yyyy") : "Unknown"}
            </span>
            <div className="flex gap-1">
              <Button 
                size="sm" 
                variant="outline" 
                className="h-8 w-8 p-0"
                onClick={() => onPreview(template)}
              >
                <Eye className="h-4 w-4" />
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                className="h-8 w-8 p-0"
                onClick={() => onEdit(template)}
              >
                <Edit className="h-4 w-4" />
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                className="h-8 w-8 p-0"
                onClick={() => onDuplicate(template)}
                disabled={isDuplicating}
              >
                <Copy className="h-4 w-4" />
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                onClick={() => onDelete(template.id)}
                disabled={isDeleting}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
