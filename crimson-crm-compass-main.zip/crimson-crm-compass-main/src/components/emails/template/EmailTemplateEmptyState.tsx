
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Plus } from "lucide-react";

interface EmailTemplateEmptyStateProps {
  onCreateTemplate: () => void;
}

export function EmailTemplateEmptyState({ onCreateTemplate }: EmailTemplateEmptyStateProps) {
  return (
    <Card>
      <CardContent className="text-center py-12">
        <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
        <h3 className="text-lg font-medium mb-2">No email templates yet</h3>
        <p className="text-muted-foreground mb-4">Create your first email template to get started</p>
        <Button onClick={onCreateTemplate}>
          <Plus className="h-4 w-4 mr-2" />
          Create Template
        </Button>
      </CardContent>
    </Card>
  );
}
