
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Edit } from "lucide-react";
import { EmailTemplate } from "@/lib/types";

interface EmailTemplatePreviewProps {
  template: EmailTemplate | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (template: EmailTemplate) => void;
}

export function EmailTemplatePreview({
  template,
  isOpen,
  onClose,
  onEdit,
}: EmailTemplatePreviewProps) {
  if (!template) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{template.name}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Subject:</Label>
            <p className="font-medium">{template.subject}</p>
          </div>
          <div>
            <Label>Body:</Label>
            <div className="bg-gray-50 p-4 rounded-lg whitespace-pre-wrap text-sm">
              {template.body}
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button onClick={() => onEdit(template)}>
              <Edit className="h-4 w-4 mr-2" />
              Edit Template
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
