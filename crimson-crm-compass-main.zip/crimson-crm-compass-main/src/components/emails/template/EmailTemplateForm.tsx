
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

interface EmailTemplateFormProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  template: {
    name: string;
    subject: string;
    body: string;
    template_type: string;
    is_active: boolean;
  };
  onTemplateChange: (template: any) => void;
  onSubmit: () => void;
  onCancel: () => void;
  isEditing: boolean;
  isLoading: boolean;
}

export function EmailTemplateForm({
  isOpen,
  onOpenChange,
  template,
  onTemplateChange,
  onSubmit,
  onCancel,
  isEditing,
  isLoading,
}: EmailTemplateFormProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Edit Template" : "Create Email Template"}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="template-name">Template Name *</Label>
              <Input
                id="template-name"
                placeholder="Template name"
                value={template.name}
                onChange={(e) => onTemplateChange({...template, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="template-type">Type</Label>
              <Select 
                value={template.template_type} 
                onValueChange={(value) => onTemplateChange({...template, template_type: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="welcome">Welcome</SelectItem>
                  <SelectItem value="follow_up">Follow-up</SelectItem>
                  <SelectItem value="proposal">Proposal</SelectItem>
                  <SelectItem value="newsletter">Newsletter</SelectItem>
                  <SelectItem value="general">General</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="template-subject">Subject Line *</Label>
            <Input
              id="template-subject"
              placeholder="Email subject"
              value={template.subject}
              onChange={(e) => onTemplateChange({...template, subject: e.target.value})}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="template-body">Email Body *</Label>
            <Textarea
              id="template-body"
              placeholder="Write your email template here... Use {{variable}} for personalization"
              value={template.body}
              onChange={(e) => onTemplateChange({...template, body: e.target.value})}
              rows={8}
            />
            <p className="text-xs text-muted-foreground">
              Available variables: {`{{firstName}}, {{lastName}}, {{company}}, {{email}}`}
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              checked={template.is_active}
              onCheckedChange={(checked) => onTemplateChange({...template, is_active: checked})}
            />
            <Label>Active template</Label>
          </div>

          <div className="flex gap-2">
            <Button 
              onClick={onSubmit} 
              disabled={isLoading}
            >
              {isLoading
                ? "Saving..." 
                : isEditing ? "Update Template" : "Create Template"
              }
            </Button>
            <Button variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
