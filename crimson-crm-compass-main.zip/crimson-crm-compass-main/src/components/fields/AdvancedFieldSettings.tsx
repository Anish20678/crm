import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Settings, 
  Eye, 
  Shield, 
  File, 
  Layers,
  Plus,
  Trash2,
  Edit
} from "lucide-react";
import { useFieldValidationRules, FieldValidationRule } from "@/hooks/useFieldValidationRules";
import { useFieldConditionalVisibility, FieldConditionalVisibility } from "@/hooks/useFieldConditionalVisibility";
import { useFieldTemplates, FieldTemplate } from "@/hooks/useFieldTemplates";

interface AdvancedFieldSettingsProps {
  module: string;
}

export function AdvancedFieldSettings({ module }: AdvancedFieldSettingsProps) {
  const [activeTab, setActiveTab] = useState("validation");
  
  const { 
    validationRules, 
    createValidationRule, 
    updateValidationRule, 
    deleteValidationRule 
  } = useFieldValidationRules(module);
  
  const { 
    visibilityConditions, 
    createVisibilityCondition, 
    updateVisibilityCondition, 
    deleteVisibilityCondition 
  } = useFieldConditionalVisibility(module);
  
  const { 
    templates, 
    createTemplate, 
    updateTemplate, 
    deleteTemplate, 
    applyTemplate 
  } = useFieldTemplates(module);

  // Validation Rules Tab
  const ValidationRulesTab = () => {
    const [newRule, setNewRule] = useState({
      field_name: "",
      rule_type: "required_if" as const,
      rule_config: {},
      error_message: "",
    });

    const handleCreateRule = () => {
      createValidationRule.mutate({
        module,
        ...newRule,
        is_active: true,
      });
      setNewRule({
        field_name: "",
        rule_type: "required_if",
        rule_config: {},
        error_message: "",
      });
    };

    return (
      <div className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Validation Rule
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="field_name">Field Name</Label>
                <Input
                  id="field_name"
                  value={newRule.field_name}
                  onChange={(e) => setNewRule({ ...newRule, field_name: e.target.value })}
                  placeholder="e.g., email"
                />
              </div>
              <div>
                <Label htmlFor="rule_type">Rule Type</Label>
                <Select
                  value={newRule.rule_type}
                  onValueChange={(value: any) => setNewRule({ ...newRule, rule_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="required_if">Required If</SelectItem>
                    <SelectItem value="min_length">Min Length</SelectItem>
                    <SelectItem value="max_length">Max Length</SelectItem>
                    <SelectItem value="regex">Regex Pattern</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="error_message">Error Message</Label>
              <Input
                id="error_message"
                value={newRule.error_message}
                onChange={(e) => setNewRule({ ...newRule, error_message: e.target.value })}
                placeholder="Custom error message"
              />
            </div>
            <Button onClick={handleCreateRule} className="w-full">
              Create Validation Rule
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-2">
          {validationRules.map((rule) => (
            <Card key={rule.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">{rule.field_name}</div>
                    <div className="text-sm text-muted-foreground">
                      <Badge variant="outline">{rule.rule_type}</Badge>
                      {rule.error_message && (
                        <span className="ml-2">{rule.error_message}</span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={rule.is_active}
                      onCheckedChange={(checked) =>
                        updateValidationRule.mutate({ id: rule.id, is_active: checked })
                      }
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteValidationRule.mutate(rule.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  };

  // Conditional Visibility Tab
  const ConditionalVisibilityTab = () => {
    const [newCondition, setNewCondition] = useState({
      field_name: "",
      condition_type: "field_value" as const,
      condition_config: {},
    });

    const handleCreateCondition = () => {
      createVisibilityCondition.mutate({
        module,
        ...newCondition,
        is_active: true,
      });
      setNewCondition({
        field_name: "",
        condition_type: "field_value",
        condition_config: {},
      });
    };

    return (
      <div className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Visibility Condition
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="field_name">Field Name</Label>
                <Input
                  id="field_name"
                  value={newCondition.field_name}
                  onChange={(e) => setNewCondition({ ...newCondition, field_name: e.target.value })}
                  placeholder="e.g., business_type"
                />
              </div>
              <div>
                <Label htmlFor="condition_type">Condition Type</Label>
                <Select
                  value={newCondition.condition_type}
                  onValueChange={(value: any) => setNewCondition({ ...newCondition, condition_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="field_value">Field Value</SelectItem>
                    <SelectItem value="field_empty">Field Empty</SelectItem>
                    <SelectItem value="field_not_empty">Field Not Empty</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button onClick={handleCreateCondition} className="w-full">
              Create Visibility Condition
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-2">
          {visibilityConditions.map((condition) => (
            <Card key={condition.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">{condition.field_name}</div>
                    <div className="text-sm text-muted-foreground">
                      <Badge variant="outline">{condition.condition_type}</Badge>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={condition.is_active}
                      onCheckedChange={(checked) =>
                        updateVisibilityCondition.mutate({ id: condition.id, is_active: checked })
                      }
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteVisibilityCondition.mutate(condition.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  };

  // Templates Tab
  const TemplatesTab = () => {
    const [newTemplate, setNewTemplate] = useState({
      template_name: "",
      template_type: "field_group" as const,
      description: "",
      template_config: {},
    });

    const handleCreateTemplate = () => {
      createTemplate.mutate({
        module,
        ...newTemplate,
        is_active: true,
      });
      setNewTemplate({
        template_name: "",
        template_type: "field_group",
        description: "",
        template_config: {},
      });
    };

    return (
      <div className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Create Template
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="template_name">Template Name</Label>
                <Input
                  id="template_name"
                  value={newTemplate.template_name}
                  onChange={(e) => setNewTemplate({ ...newTemplate, template_name: e.target.value })}
                  placeholder="e.g., Sales Lead Setup"
                />
              </div>
              <div>
                <Label htmlFor="template_type">Template Type</Label>
                <Select
                  value={newTemplate.template_type}
                  onValueChange={(value: any) => setNewTemplate({ ...newTemplate, template_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="field_group">Field Group</SelectItem>
                    <SelectItem value="complete_module">Complete Module</SelectItem>
                    <SelectItem value="field_set">Field Set</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={newTemplate.description}
                onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })}
                placeholder="Template description"
              />
            </div>
            <Button onClick={handleCreateTemplate} className="w-full">
              Create Template
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-2">
          {templates.map((template) => (
            <Card key={template.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium flex items-center gap-2">
                      {template.template_name}
                      {template.is_system_template && (
                        <Badge variant="secondary">System</Badge>
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      <Badge variant="outline">{template.template_type}</Badge>
                      {template.description && (
                        <span className="ml-2">{template.description}</span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => applyTemplate.mutate(template.id)}
                    >
                      Apply
                    </Button>
                    {!template.is_system_template && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteTemplate.mutate(template.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Advanced Field Settings
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="validation" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Validation
            </TabsTrigger>
            <TabsTrigger value="visibility" className="flex items-center gap-2">
              <Eye className="h-4 w-4" />
              Visibility
            </TabsTrigger>
            <TabsTrigger value="templates" className="flex items-center gap-2">
              <File className="h-4 w-4" />
              Templates
            </TabsTrigger>
          </TabsList>

          <TabsContent value="validation" className="mt-4">
            <ValidationRulesTab />
          </TabsContent>

          <TabsContent value="visibility" className="mt-4">
            <ConditionalVisibilityTab />
          </TabsContent>

          <TabsContent value="templates" className="mt-4">
            <TemplatesTab />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
