
import React from "react";
import { UseFormReturn } from "react-hook-form";
import { FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useSystemFieldDisplay, DisplayField } from "@/hooks/useSystemFieldDisplay";
import { useCustomFieldValues } from "@/hooks/useCustomFieldValues";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, ChevronRight } from "lucide-react";

interface DynamicFormBuilderProps {
  module: string;
  form: UseFormReturn<any>;
  recordId?: string;
  customFieldValues?: Record<string, string>;
  onCustomFieldChange?: (fieldId: string, value: string) => void;
  customFieldErrors?: Record<string, string>;
}

export function DynamicFormBuilder({ 
  module, 
  form, 
  recordId,
  customFieldValues = {},
  onCustomFieldChange,
  customFieldErrors = {}
}: DynamicFormBuilderProps) {
  const { visibleFields, getFieldConfig } = useSystemFieldDisplay(module);
  const { customFields } = useCustomFieldValues(module, recordId);
  const [expandedGroups, setExpandedGroups] = React.useState<Set<string>>(new Set(["basic"]));

  // Group fields by their group
  const groupedFields = React.useMemo(() => {
    const groups: Record<string, { systemFields: DisplayField[], customFields: any[] }> = {};
    
    // Group system fields
    visibleFields.forEach(field => {
      const group = field.group || "basic";
      if (!groups[group]) {
        groups[group] = { systemFields: [], customFields: [] };
      }
      groups[group].systemFields.push(field);
    });

    // Group custom fields
    customFields.forEach(field => {
      const group = field.field_group || "custom";
      if (!groups[group]) {
        groups[group] = { systemFields: [], customFields: [] };
      }
      groups[group].customFields.push(field);
    });

    return groups;
  }, [visibleFields, customFields]);

  const toggleGroup = (groupId: string) => {
    setExpandedGroups(prev => {
      const newSet = new Set(prev);
      if (newSet.has(groupId)) {
        newSet.delete(groupId);
      } else {
        newSet.add(groupId);
      }
      return newSet;
    });
  };

  const renderSystemField = (field: DisplayField) => {
    const fieldConfig = getFieldConfig(field.fieldName);
    if (!fieldConfig?.visible) return null;

    switch (field.type) {
      case "text":
      case "email":
      case "phone":
        return (
          <FormField
            key={field.fieldName}
            control={form.control}
            name={field.fieldName}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>{field.label} {field.required && "*"}</FormLabel>
                <FormControl>
                  <Input 
                    type={field.type === "email" ? "email" : field.type === "phone" ? "tel" : "text"}
                    {...formField} 
                    value={formField.value || ""} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        );

      case "textarea":
        return (
          <FormField
            key={field.fieldName}
            control={form.control}
            name={field.fieldName}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>{field.label} {field.required && "*"}</FormLabel>
                <FormControl>
                  <Textarea {...formField} value={formField.value || ""} rows={3} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        );

      case "boolean":
        return (
          <FormField
            key={field.fieldName}
            control={form.control}
            name={field.fieldName}
            render={({ field: formField }) => (
              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                <div className="space-y-0.5">
                  <FormLabel className="text-base">{field.label}</FormLabel>
                </div>
                <FormControl>
                  <Switch
                    checked={formField.value || false}
                    onCheckedChange={formField.onChange}
                  />
                </FormControl>
              </FormItem>
            )}
          />
        );

      case "date":
        return (
          <FormField
            key={field.fieldName}
            control={form.control}
            name={field.fieldName}
            render={({ field: formField }) => (
              <FormItem className="flex flex-col">
                <FormLabel>{field.label} {field.required && "*"}</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full text-left font-normal",
                          !formField.value && "text-muted-foreground"
                        )}
                      >
                        {formField.value ? (
                          format(new Date(formField.value), "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={formField.value ? new Date(formField.value) : undefined}
                      onSelect={(date) => formField.onChange(date?.toISOString())}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
        );

      case "select":
        const selectOptions = getSelectOptions(field.fieldName, module);
        return (
          <FormField
            key={field.fieldName}
            control={form.control}
            name={field.fieldName}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>{field.label} {field.required && "*"}</FormLabel>
                <Select onValueChange={formField.onChange} defaultValue={formField.value || ""}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder={`Select ${field.label}`} />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {selectOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        );

      default:
        return null;
    }
  };

  const renderCustomField = (field: any) => {
    const value = customFieldValues[field.id] || "";
    const error = customFieldErrors[field.id];

    switch (field.field_type) {
      case "text":
      case "email":
      case "phone":
        return (
          <div key={field.id}>
            <FormLabel>{field.label} {field.required && "*"}</FormLabel>
            <Input
              type={field.field_type === "email" ? "email" : field.field_type === "phone" ? "tel" : "text"}
              value={value}
              onChange={(e) => onCustomFieldChange?.(field.id, e.target.value)}
              className={error ? "border-red-500" : ""}
            />
            {error && <p className="text-sm text-red-500 mt-1">{error}</p>}
          </div>
        );

      case "textarea":
        return (
          <div key={field.id}>
            <FormLabel>{field.label} {field.required && "*"}</FormLabel>
            <Textarea
              value={value}
              onChange={(e) => onCustomFieldChange?.(field.id, e.target.value)}
              rows={3}
              className={error ? "border-red-500" : ""}
            />
            {error && <p className="text-sm text-red-500 mt-1">{error}</p>}
          </div>
        );

      case "boolean":
        return (
          <div key={field.id} className="flex flex-row items-center justify-between rounded-lg border p-4">
            <div className="space-y-0.5">
              <FormLabel className="text-base">{field.label}</FormLabel>
            </div>
            <Switch
              checked={value === "true"}
              onCheckedChange={(checked) => onCustomFieldChange?.(field.id, checked.toString())}
            />
          </div>
        );

      case "select":
        const options = field.options || [];
        return (
          <div key={field.id}>
            <FormLabel>{field.label} {field.required && "*"}</FormLabel>
            <Select value={value} onValueChange={(newValue) => onCustomFieldChange?.(field.id, newValue)}>
              <SelectTrigger className={error ? "border-red-500" : ""}>
                <SelectValue placeholder={`Select ${field.label}`} />
              </SelectTrigger>
              <SelectContent>
                {options.map((option: any) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {error && <p className="text-sm text-red-500 mt-1">{error}</p>}
          </div>
        );

      default:
        return null;
    }
  };

  const getGroupLabel = (groupId: string) => {
    const groupLabels: Record<string, string> = {
      basic: "Basic Information",
      business: "Business Details",
      tracking: "Lead Tracking",
      dates: "Important Dates",
      notes: "Notes & Communication",
      custom: "Custom Fields",
      assignment: "Assignment & Priority",
      relations: "Related Items",
      project: "Project Details",
      timeline: "Timeline & Delivery",
      payment: "Payment Information",
      status: "Status & Notes",
    };
    return groupLabels[groupId] || groupId.charAt(0).toUpperCase() + groupId.slice(1);
  };

  return (
    <div className="space-y-6">
      {Object.entries(groupedFields).map(([groupId, { systemFields, customFields }]) => {
        const hasFields = systemFields.length > 0 || customFields.length > 0;
        if (!hasFields) return null;

        const isExpanded = expandedGroups.has(groupId);

        return (
          <Collapsible key={groupId} open={isExpanded} onOpenChange={() => toggleGroup(groupId)}>
            <CollapsibleTrigger asChild>
              <Card className="cursor-pointer hover:bg-muted/50 transition-colors">
                <CardHeader className="py-3">
                  <div className="flex items-center gap-2">
                    {isExpanded ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                    <CardTitle className="text-lg">{getGroupLabel(groupId)}</CardTitle>
                    <span className="text-sm text-muted-foreground">
                      ({systemFields.length + customFields.length} fields)
                    </span>
                  </div>
                </CardHeader>
              </Card>
            </CollapsibleTrigger>
            
            <CollapsibleContent className="mt-2">
              <Card>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {systemFields.map(renderSystemField)}
                    {customFields.map(renderCustomField)}
                  </div>
                </CardContent>
              </Card>
            </CollapsibleContent>
          </Collapsible>
        );
      })}
    </div>
  );
}

// Helper function to get select options for system fields
function getSelectOptions(fieldName: string, module: string) {
  const options: Record<string, { value: string; label: string }[]> = {
    status: [
      { value: "active", label: "Active" },
      { value: "inactive", label: "Inactive" },
      { value: "pending", label: "Pending" },
    ],
    emirates: [
      { value: "Abu Dhabi", label: "Abu Dhabi" },
      { value: "Dubai", label: "Dubai" },
      { value: "Sharjah", label: "Sharjah" },
      { value: "Ajman", label: "Ajman" },
      { value: "Umm Al Quwain", label: "Umm Al Quwain" },
      { value: "Ras Al Khaimah", label: "Ras Al Khaimah" },
      { value: "Fujairah", label: "Fujairah" },
    ],
    lead_source: [
      { value: "Meta Ads", label: "Meta Ads" },
      { value: "Google Ads", label: "Google Ads" },
      { value: "Referral", label: "Referral" },
      { value: "Direct", label: "Direct" },
      { value: "Other", label: "Other" },
    ],
    preferred_contact_method: [
      { value: "WhatsApp", label: "WhatsApp" },
      { value: "Call", label: "Call" },
      { value: "Email", label: "Email" },
      { value: "SMS", label: "SMS" },
    ],
    priority: [
      { value: "low", label: "Low" },
      { value: "medium", label: "Medium" },
      { value: "high", label: "High" },
    ],
    payment_status: [
      { value: "pending", label: "Pending" },
      { value: "partial", label: "Partial" },
      { value: "completed", label: "Completed" },
      { value: "overdue", label: "Overdue" },
    ],
  };

  return options[fieldName] || [];
}
