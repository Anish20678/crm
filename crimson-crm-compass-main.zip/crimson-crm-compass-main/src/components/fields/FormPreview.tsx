
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, ChevronRight } from "lucide-react";

interface FormPreviewProps {
  module: string;
  systemFields: any[];
  customFields: any[];
  fieldGroups: any[];
  selectedGroup?: string | null;
}

export function FormPreview({ 
  module, 
  systemFields, 
  customFields, 
  fieldGroups,
  selectedGroup 
}: FormPreviewProps) {
  const [expandedGroups, setExpandedGroups] = React.useState<Set<string>>(
    new Set(fieldGroups.filter(g => g.default_expanded).map(g => g.id))
  );

  // Group fields by their group
  const groupedFields = React.useMemo(() => {
    const groups: Record<string, { systemFields: any[], customFields: any[] }> = {};
    
    // Group system fields
    systemFields.forEach(field => {
      const group = field.group || "basic";
      if (!groups[group]) {
        groups[group] = { systemFields: [], customFields: [] };
      }
      groups[group].systemFields.push(field);
    });

    // Group custom fields
    customFields.forEach(field => {
      const group = field.field_group || "custom";
      if (!groups[group]) {
        groups[group] = { systemFields: [], customFields: [] };
      }
      groups[group].customFields.push(field);
    });

    return groups;
  }, [systemFields, customFields]);

  const toggleGroup = (groupId: string) => {
    setExpandedGroups(prev => {
      const newSet = new Set(prev);
      if (newSet.has(groupId)) {
        newSet.delete(groupId);
      } else {
        newSet.add(groupId);
      }
      return newSet;
    });
  };

  const renderField = (field: any, isCustom = false) => {
    const fieldType = isCustom ? field.field_type : field.type;
    
    switch (fieldType) {
      case "text":
      case "email":
      case "phone":
        return (
          <div key={field.id || field.fieldName} className="space-y-2">
            <Label className="flex items-center gap-2">
              {field.label}
              {field.required && <span className="text-red-500">*</span>}
              {isCustom && <Badge variant="outline" className="text-xs">Custom</Badge>}
            </Label>
            <Input placeholder={`Enter ${field.label.toLowerCase()}`} disabled />
          </div>
        );

      case "textarea":
        return (
          <div key={field.id || field.fieldName} className="space-y-2">
            <Label className="flex items-center gap-2">
              {field.label}
              {field.required && <span className="text-red-500">*</span>}
              {isCustom && <Badge variant="outline" className="text-xs">Custom</Badge>}
            </Label>
            <Textarea placeholder={`Enter ${field.label.toLowerCase()}`} disabled rows={3} />
          </div>
        );

      case "boolean":
        return (
          <div key={field.id || field.fieldName} className="flex items-center justify-between p-3 border rounded-lg">
            <Label className="flex items-center gap-2">
              {field.label}
              {isCustom && <Badge variant="outline" className="text-xs">Custom</Badge>}
            </Label>
            <Switch disabled />
          </div>
        );

      case "select":
        return (
          <div key={field.id || field.fieldName} className="space-y-2">
            <Label className="flex items-center gap-2">
              {field.label}
              {field.required && <span className="text-red-500">*</span>}
              {isCustom && <Badge variant="outline" className="text-xs">Custom</Badge>}
            </Label>
            <Select disabled>
              <SelectTrigger>
                <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="placeholder">Option 1</SelectItem>
              </SelectContent>
            </Select>
          </div>
        );

      case "date":
        return (
          <div key={field.id || field.fieldName} className="space-y-2">
            <Label className="flex items-center gap-2">
              {field.label}
              {field.required && <span className="text-red-500">*</span>}
              {isCustom && <Badge variant="outline" className="text-xs">Custom</Badge>}
            </Label>
            <Input type="date" disabled />
          </div>
        );

      case "number":
      case "currency":
        return (
          <div key={field.id || field.fieldName} className="space-y-2">
            <Label className="flex items-center gap-2">
              {field.label}
              {field.required && <span className="text-red-500">*</span>}
              {isCustom && <Badge variant="outline" className="text-xs">Custom</Badge>}
            </Label>
            <Input type="number" placeholder={`Enter ${field.label.toLowerCase()}`} disabled />
          </div>
        );

      default:
        return (
          <div key={field.id || field.fieldName} className="space-y-2">
            <Label className="flex items-center gap-2">
              {field.label}
              {field.required && <span className="text-red-500">*</span>}
              {isCustom && <Badge variant="outline" className="text-xs">Custom</Badge>}
            </Label>
            <Input placeholder={`Enter ${field.label.toLowerCase()}`} disabled />
          </div>
        );
    }
  };

  if (selectedGroup) {
    // Show only the selected group
    const groupData = groupedFields[selectedGroup];
    if (!groupData) {
      return (
        <div className="text-center py-8 text-muted-foreground">
          No fields in selected group
        </div>
      );
    }

    const groupInfo = fieldGroups.find(g => g.id === selectedGroup);
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {groupInfo?.label || selectedGroup}
            {groupInfo?.is_system && (
              <Badge variant="secondary">System</Badge>
            )}
          </CardTitle>
          {groupInfo?.description && (
            <p className="text-sm text-muted-foreground">{groupInfo.description}</p>
          )}
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-4">
            {groupData.systemFields.map(field => renderField(field))}
            {groupData.customFields.map(field => renderField(field, true))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Show all groups
  return (
    <div className="space-y-4">
      {fieldGroups.map((group) => {
        const groupFields = groupedFields[group.id];
        if (!groupFields || (groupFields.systemFields.length === 0 && groupFields.customFields.length === 0)) {
          return null;
        }

        const isExpanded = expandedGroups.has(group.id);
        const totalFields = groupFields.systemFields.length + groupFields.customFields.length;

        return (
          <Collapsible
            key={group.id}
            open={isExpanded}
            onOpenChange={() => toggleGroup(group.id)}
          >
            <CollapsibleTrigger asChild>
              <Card className="cursor-pointer hover:bg-muted/50 transition-colors">
                <CardHeader className="py-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {isExpanded ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )}
                      <CardTitle className="text-base">{group.label}</CardTitle>
                      {group.is_system && (
                        <Badge variant="secondary" className="text-xs">System</Badge>
                      )}
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {totalFields} fields
                    </Badge>
                  </div>
                  {group.description && (
                    <p className="text-sm text-muted-foreground pl-6">{group.description}</p>
                  )}
                </CardHeader>
              </Card>
            </CollapsibleTrigger>
            
            <CollapsibleContent className="mt-2">
              <Card>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {groupFields.systemFields.map(field => renderField(field))}
                    {groupFields.customFields.map(field => renderField(field, true))}
                  </div>
                </CardContent>
              </Card>
            </CollapsibleContent>
          </Collapsible>
        );
      })}
    </div>
  );
}
