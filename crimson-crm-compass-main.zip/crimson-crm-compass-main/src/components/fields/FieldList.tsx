
import React, { useMemo } from "react";
import type { CustomField } from "@/lib/types/customFields";
import { FieldItem } from "./FieldItem";

type Props = {
  fields: CustomField[];
  onDelete: (field: CustomField) => void;
  onPreview?: (field: CustomField) => void;
};

export const FieldList = React.memo(function FieldList({
  fields,
  onDelete,
  onPreview,
}: Props) {
  // If the field list is large, memoize for perf
  const rendered = useMemo(
    () =>
      fields.map(field => (
        <FieldItem
          key={field.id}
          field={field}
          onDelete={onDelete}
          onPreview={onPreview}
        />
      )),
    [fields, onDelete, onPreview]
  );

  if (!fields.length) {
    return <div className="text-muted-foreground">No custom fields yet!</div>;
  }
  return <div className="space-y-1">{rendered}</div>;
});
