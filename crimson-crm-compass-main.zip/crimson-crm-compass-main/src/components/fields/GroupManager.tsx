import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Edit, Trash2, GripVertical } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface FieldGroup {
  id: string;
  label: string;
  description?: string;
  defaultExpanded?: boolean;
  order: number;
}

interface GroupManagerProps {
  module: string;
  groups: FieldGroup[];
  onGroupUpdate: (groups: FieldGroup[]) => void;
}

export function GroupManager({ module, groups, onGroupUpdate }: GroupManagerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingGroup, setEditingGroup] = useState<FieldGroup | null>(null);
  const [formData, setFormData] = useState({
    label: "",
    description: "",
    defaultExpanded: true,
  });
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingGroup) {
      // Update existing group
      const updatedGroups = groups.map(group =>
        group.id === editingGroup.id
          ? { ...group, ...formData }
          : group
      );
      onGroupUpdate(updatedGroups);
      toast({ title: "Group updated", description: "Field group updated successfully." });
    } else {
      // Create new group
      const newGroup: FieldGroup = {
        id: `custom_${Date.now()}`,
        ...formData,
        order: groups.length,
      };
      onGroupUpdate([...groups, newGroup]);
      toast({ title: "Group created", description: "New field group created successfully." });
    }

    resetForm();
  };

  const resetForm = () => {
    setFormData({ label: "", description: "", defaultExpanded: true });
    setEditingGroup(null);
    setIsDialogOpen(false);
  };

  const handleEdit = (group: FieldGroup) => {
    setEditingGroup(group);
    setFormData({
      label: group.label,
      description: group.description || "",
      defaultExpanded: group.defaultExpanded || false,
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (groupId: string) => {
    if (window.confirm("Are you sure you want to delete this group? Fields in this group will be moved to the default group.")) {
      const updatedGroups = groups.filter(group => group.id !== groupId);
      onGroupUpdate(updatedGroups);
      toast({ title: "Group deleted", description: "Field group deleted successfully." });
    }
  };

  const moveGroup = (fromIndex: number, toIndex: number) => {
    const newGroups = [...groups];
    const [moved] = newGroups.splice(fromIndex, 1);
    newGroups.splice(toIndex, 0, moved);
    
    // Update order values
    const updatedGroups = newGroups.map((group, index) => ({
      ...group,
      order: index,
    }));
    
    onGroupUpdate(updatedGroups);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Field Groups</CardTitle>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" onClick={() => setEditingGroup(null)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Group
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {editingGroup ? "Edit Field Group" : "Create Field Group"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="label">Group Name *</Label>
                  <Input
                    id="label"
                    value={formData.label}
                    onChange={(e) => setFormData(prev => ({ ...prev, label: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    rows={3}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="defaultExpanded"
                    checked={formData.defaultExpanded}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, defaultExpanded: checked }))}
                  />
                  <Label htmlFor="defaultExpanded">Expanded by default</Label>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    Cancel
                  </Button>
                  <Button type="submit">
                    {editingGroup ? "Update" : "Create"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {groups.map((group, index) => (
            <div
              key={group.id}
              className="flex items-center gap-3 p-3 border rounded-lg bg-card"
              draggable
              onDragStart={(e) => e.dataTransfer.setData("text/plain", index.toString())}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const fromIndex = parseInt(e.dataTransfer.getData("text/plain"));
                moveGroup(fromIndex, index);
              }}
            >
              <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
              <div className="flex-1">
                <div className="font-medium">{group.label}</div>
                {group.description && (
                  <div className="text-sm text-muted-foreground">{group.description}</div>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleEdit(group)}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                {!group.id.startsWith("basic") && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(group.id)}
                    className="text-red-600"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
