import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useSystemFieldConfigs } from "@/hooks/useSystemFieldConfigs";
import { getSystemFieldsForModule, getDefaultSystemFieldConfig, getFieldGroupsForModule } from "@/lib/systemFields";
import { GripVertical, Eye, EyeOff, ChevronDown, ChevronRight, Info } from "lucide-react";

interface SystemFieldsManagerProps {
  module: string;
}

export function SystemFieldsManager({ module }: SystemFieldsManagerProps) {
  const { systemFieldConfigs, upsertConfig, updateFieldOrder, isUpdating } = useSystemFieldConfigs(module);
  const systemFields = getSystemFieldsForModule(module);
  const fieldGroups = getFieldGroupsForModule(module);
  const [draggedItem, setDraggedItem] = useState<string | null>(null);
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(
    new Set(fieldGroups.filter(g => g.defaultExpanded).map(g => g.id))
  );

  // Special handling for lead module - show informational message
  if (module === "lead" && systemFields.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Info className="h-5 w-5 text-blue-600" />
            Leads Module - Fully Customizable
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <div className="flex flex-col items-center gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <Info className="h-8 w-8 text-blue-600" />
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold text-lg">No System Fields</h3>
                <p className="text-muted-foreground max-w-md">
                  The leads module has been redesigned to be fully customizable. 
                  All fields are now managed through custom fields and field groups.
                </p>
              </div>
              <div className="flex gap-2 mt-4">
                <div className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                  ✓ Fully Flexible
                </div>
                <div className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                  ✓ Custom Groups
                </div>
                <div className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm">
                  ✓ No Restrictions
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // If no system fields are available for other modules
  if (!systemFields.length) {
    return (
      <Card>
        <CardContent className="py-6">
          <p className="text-muted-foreground text-center">
            No system fields available for {module} module.
          </p>
        </CardContent>
      </Card>
    );
  }

  // Merge system fields with user configurations and group them
  const fieldsWithConfig = systemFields.map(field => {
    const userConfig = systemFieldConfigs.find(config => config.field_name === field.name);
    const defaultConfig = getDefaultSystemFieldConfig(module, field.name);
    
    return {
      ...field,
      config: userConfig || {
        ...defaultConfig,
        id: '',
        user_id: '',
        module,
        created_at: '',
        updated_at: '',
      },
    };
  });

  // Group fields by their field_group
  const groupedFields = fieldGroups.reduce((acc, group) => {
    acc[group.id] = fieldsWithConfig
      .filter(field => field.fieldGroup === group.id)
      .sort((a, b) => (a.config?.field_order || 0) - (b.config?.field_order || 0));
    return acc;
  }, {} as Record<string, typeof fieldsWithConfig>);

  const handleVisibilityChange = (fieldName: string, isVisible: boolean) => {
    upsertConfig({
      module,
      field_name: fieldName,
      is_visible: isVisible,
    });
  };

  const handleWidthChange = (fieldName: string, width: number) => {
    if (width < 5 || width > 100) return;
    upsertConfig({
      module,
      field_name: fieldName,
      width_percentage: width,
    });
  };

  const handleDragStart = (fieldName: string) => {
    setDraggedItem(fieldName);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (targetFieldName: string) => {
    if (!draggedItem || draggedItem === targetFieldName) return;

    // Find the group of the target field
    const targetField = fieldsWithConfig.find(f => f.name === targetFieldName);
    if (!targetField) return;

    const targetGroup = targetField.fieldGroup;
    const groupFields = groupedFields[targetGroup];
    
    const currentOrder = groupFields.map(f => f.name);
    const draggedIndex = currentOrder.indexOf(draggedItem);
    const targetIndex = currentOrder.indexOf(targetFieldName);

    const newOrder = [...currentOrder];
    newOrder.splice(draggedIndex, 1);
    newOrder.splice(targetIndex, 0, draggedItem);

    const fieldUpdates = newOrder.map((fieldName, index) => ({
      field_name: fieldName,
      field_order: index,
    }));

    updateFieldOrder(fieldUpdates);
    setDraggedItem(null);
  };

  const toggleGroup = (groupId: string) => {
    setExpandedGroups(prev => {
      const newSet = new Set(prev);
      if (newSet.has(groupId)) {
        newSet.delete(groupId);
      } else {
        newSet.add(groupId);
      }
      return newSet;
    });
  };

  const getVisibleFieldsCount = () => {
    return fieldsWithConfig.filter(f => f.config?.is_visible).length;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          System Fields for {module.charAt(0).toUpperCase() + module.slice(1)}
          <span className="text-sm font-normal text-muted-foreground">
            ({getVisibleFieldsCount()} visible)
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {fieldGroups.map((group) => {
          const groupFields = groupedFields[group.id] || [];
          const visibleCount = groupFields.filter(f => f.config?.is_visible).length;
          const isExpanded = expandedGroups.has(group.id);

          return (
            <Collapsible
              key={group.id}
              open={isExpanded}
              onOpenChange={() => toggleGroup(group.id)}
            >
              <CollapsibleTrigger asChild>
                <Card className="cursor-pointer hover:bg-muted/50 transition-colors">
                  <CardHeader className="py-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {isExpanded ? (
                          <ChevronDown className="h-4 w-4" />
                        ) : (
                          <ChevronRight className="h-4 w-4" />
                        )}
                        <div>
                          <h4 className="font-medium">{group.label}</h4>
                          {group.description && (
                            <p className="text-xs text-muted-foreground">{group.description}</p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-3 text-sm text-muted-foreground">
                        <span>{visibleCount}/{groupFields.length} visible</span>
                      </div>
                    </div>
                  </CardHeader>
                </Card>
              </CollapsibleTrigger>
              
              <CollapsibleContent className="mt-2">
                <div className="space-y-2 pl-6">
                  {groupFields.map((field) => (
                    <div
                      key={field.name}
                      className="flex items-center gap-3 p-3 border rounded-lg bg-card"
                      draggable
                      onDragStart={() => handleDragStart(field.name)}
                      onDragOver={handleDragOver}
                      onDrop={() => handleDrop(field.name)}
                    >
                      <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
                      
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <Switch
                          checked={field.config?.is_visible ?? field.defaultVisible}
                          onCheckedChange={(checked) => handleVisibilityChange(field.name, checked)}
                          disabled={isUpdating}
                        />
                        {field.config?.is_visible ? (
                          <Eye className="h-4 w-4 text-green-600" />
                        ) : (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        )}
                        <div className="min-w-0 flex-1">
                          <div className="font-medium truncate">{field.label}</div>
                          <div className="text-xs text-muted-foreground">
                            {field.name} • {field.type}
                            {field.required && <span className="text-red-500 ml-1">*required</span>}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Label htmlFor={`width-${field.name}`} className="text-xs text-muted-foreground">
                          Width:
                        </Label>
                        <Input
                          id={`width-${field.name}`}
                          type="number"
                          min="5"
                          max="100"
                          value={field.config?.width_percentage || field.defaultWidth}
                          onChange={(e) => handleWidthChange(field.name, parseInt(e.target.value))}
                          className="w-16 h-8 text-xs"
                          disabled={isUpdating}
                        />
                        <span className="text-xs text-muted-foreground">%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CollapsibleContent>
            </Collapsible>
          );
        })}

        <div className="pt-3 border-t">
          <div className="text-xs text-muted-foreground">
            <p>• Expand/collapse groups to organize fields</p>
            <p>• Drag fields to reorder them within groups</p>
            <p>• Toggle visibility with the switch</p>
            <p>• Adjust column width percentage (5-100%)</p>
            <p>• Required fields cannot be hidden</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
