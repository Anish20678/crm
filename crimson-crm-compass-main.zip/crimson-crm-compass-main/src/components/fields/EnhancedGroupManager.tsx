
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Edit, Trash2, GripVertical } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useFieldGroups, FieldGroup } from "@/hooks/useFieldGroups";

interface EnhancedGroupManagerProps {
  module: string;
}

export function EnhancedGroupManager({ module }: EnhancedGroupManagerProps) {
  const { fieldGroups, upsertGroup, deleteGroup, updateGroupOrder, isUpdating } = useFieldGroups(module);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingGroup, setEditingGroup] = useState<FieldGroup | null>(null);
  const [formData, setFormData] = useState({
    id: "",
    label: "",
    description: "",
    default_expanded: true,
  });
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingGroup) {
      // Update existing group
      upsertGroup({
        ...editingGroup,
        ...formData,
      });
    } else {
      // Create new group
      const newGroupId = `custom_${Date.now()}`;
      upsertGroup({
        id: newGroupId,
        label: formData.label,
        description: formData.description,
        default_expanded: formData.default_expanded,
        group_order: fieldGroups.length,
        is_system: false,
      });
    }

    resetForm();
  };

  const resetForm = () => {
    setFormData({ id: "", label: "", description: "", default_expanded: true });
    setEditingGroup(null);
    setIsDialogOpen(false);
  };

  const handleEdit = (group: FieldGroup) => {
    setEditingGroup(group);
    setFormData({
      id: group.id,
      label: group.label,
      description: group.description || "",
      default_expanded: group.default_expanded,
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (group: FieldGroup) => {
    if (group.is_system) {
      toast({
        title: "Cannot delete system group",
        description: "System groups cannot be deleted.",
        variant: "destructive",
      });
      return;
    }

    if (window.confirm(`Are you sure you want to delete "${group.label}"? Fields in this group will be moved to the default group.`)) {
      deleteGroup(group.id);
    }
  };

  const moveGroup = (fromIndex: number, toIndex: number) => {
    const newGroups = [...fieldGroups];
    const [moved] = newGroups.splice(fromIndex, 1);
    newGroups.splice(toIndex, 0, moved);
    
    // Update order values
    const updatedGroups = newGroups.map((group, index) => ({
      id: group.id,
      group_order: index,
    }));
    
    updateGroupOrder(updatedGroups);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Field Groups</CardTitle>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" onClick={() => setEditingGroup(null)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Group
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {editingGroup ? "Edit Field Group" : "Create Field Group"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="label">Group Name *</Label>
                  <Input
                    id="label"
                    value={formData.label}
                    onChange={(e) => setFormData(prev => ({ ...prev, label: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    rows={3}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="default_expanded"
                    checked={formData.default_expanded}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, default_expanded: checked }))}
                  />
                  <Label htmlFor="default_expanded">Expanded by default</Label>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isUpdating}>
                    {editingGroup ? "Update" : "Create"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {fieldGroups.map((group, index) => (
            <div
              key={group.id}
              className="flex items-center gap-3 p-3 border rounded-lg bg-card"
              draggable={!group.is_system}
              onDragStart={(e) => e.dataTransfer.setData("text/plain", index.toString())}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const fromIndex = parseInt(e.dataTransfer.getData("text/plain"));
                moveGroup(fromIndex, index);
              }}
            >
              {!group.is_system && (
                <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
              )}
              <div className="flex-1">
                <div className="font-medium flex items-center gap-2">
                  {group.label}
                  {group.is_system && (
                    <span className="text-xs bg-muted px-2 py-1 rounded">System</span>
                  )}
                </div>
                {group.description && (
                  <div className="text-sm text-muted-foreground">{group.description}</div>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleEdit(group)}
                  disabled={isUpdating}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                {!group.is_system && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(group)}
                    className="text-red-600"
                    disabled={isUpdating}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
