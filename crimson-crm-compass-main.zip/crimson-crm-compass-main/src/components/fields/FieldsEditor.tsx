
import React, { useCallback } from "react";
import { useCustomFieldsData } from "@/hooks/useCustomFieldsData";
import { useCustomFieldsMutations } from "@/hooks/useCustomFieldsMutations";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { FieldForm } from "./FieldForm";
import { FieldList } from "./FieldList";
import { useToast } from "@/hooks/use-toast";

/**
 * Top-level editor for custom fields of any module.
 */
type Props = {
  module: string; // E.g., "lead", "deal", ...
};

export function FieldsEditor({ module }: Props) {
  const { customFields, isLoading, error } = useCustomFieldsData(module);
  const { upsertField, deleteField } = useCustomFieldsMutations(module);
  const { toast } = useToast();

  // Add field handler
  const handleAddField = useCallback(
    (field) => {
      upsertField({
        ...field,
        module,
        order_index: customFields.length,
      });
    },
    [upsertField, module, customFields.length]
  );

  // Delete handler (with prompt)
  const handleDelete = useCallback(
    (field) => {
      if (window.confirm(`Delete field "${field.label}"? This cannot be undone.`)) {
        deleteField(field.id);
      }
    },
    [deleteField]
  );

  return (
    <div className="p-4 max-w-2xl">
      <h2 className="text-lg font-semibold mb-4">Custom Fields for {module.charAt(0).toUpperCase() + module.slice(1)}</h2>
      {error && (
        <div className="mb-4 px-3 py-2 rounded bg-red-100 text-red-600 border border-red-200">
          <b>Error loading fields:</b>{" "}
          {typeof error === "string" ? error : error?.message ?? String(error)}
        </div>
      )}

      <Card className="mb-6 border bg-muted/40">
        <CardHeader className="font-semibold mb-3">Add Field</CardHeader>
        <CardContent>
          <FieldForm
            onAdd={handleAddField}
            existingNames={customFields.map(f => f.name)}
          />
        </CardContent>
      </Card>

      <div className="mb-2 font-semibold">Existing Fields</div>
      {isLoading ? (
        <div>Loading fields...</div>
      ) : (
        <FieldList fields={customFields} onDelete={handleDelete} />
      )}
    </div>
  );
}
