
import React, { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { UnifiedFieldManager } from "./UnifiedFieldManager";
import { FieldsEditor } from "./FieldsEditor";
import { Settings, Plus, FolderOpen, Sparkles } from "lucide-react";

interface EnhancedFieldsEditorProps {
  module: string;
}

export function EnhancedFieldsEditor({ module }: EnhancedFieldsEditorProps) {
  const [activeTab, setActiveTab] = useState("unified");

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Field Management</h2>
          <p className="text-muted-foreground">
            Manage and preview fields for the {module} module
          </p>
        </div>
        <Badge variant="outline" className="bg-gradient-to-r from-blue-50 to-purple-50">
          <Sparkles className="h-3 w-3 mr-1" />
          Enhanced Editor
        </Badge>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="unified" className="flex items-center gap-2">
            <Sparkles className="h-4 w-4" />
            Unified Manager
          </TabsTrigger>
          <TabsTrigger value="legacy" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Legacy Editor
          </TabsTrigger>
        </TabsList>

        <TabsContent value="unified" className="mt-6">
          <UnifiedFieldManager module={module} />
        </TabsContent>

        <TabsContent value="legacy" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <h3 className="font-semibold flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  System Fields
                </h3>
              </CardHeader>
              <CardContent>
                {/* Legacy system fields content would go here */}
                <p className="text-sm text-muted-foreground">
                  Legacy system field management
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h3 className="font-semibold flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  Custom Fields
                </h3>
              </CardHeader>
              <CardContent>
                <FieldsEditor module={module} />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h3 className="font-semibold flex items-center gap-2">
                  <FolderOpen className="h-4 w-4" />
                  Field Groups
                </h3>
              </CardHeader>
              <CardContent>
                {/* Legacy group management would go here */}
                <p className="text-sm text-muted-foreground">
                  Legacy group management
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
