
import React from "react";
import { EnhancedGroupManager } from "./EnhancedGroupManager";

interface GroupManagementPanelProps {
  module: string;
  onGroupSelect: (groupId: string | null) => void;
}

export function GroupManagementPanel({ module, onGroupSelect }: GroupManagementPanelProps) {
  return (
    <div className="space-y-4">
      <EnhancedGroupManager module={module} />
      
      <div className="text-xs text-muted-foreground bg-muted/50 p-3 rounded-lg">
        <p className="font-medium mb-1">Group Management Tips:</p>
        <ul className="space-y-1">
          <li>• System groups cannot be deleted but can be customized</li>
          <li>• Drag groups to reorder them</li>
          <li>• Custom groups can be created for specific workflows</li>
          <li>• Group visibility affects form organization</li>
        </ul>
      </div>
    </div>
  );
}
