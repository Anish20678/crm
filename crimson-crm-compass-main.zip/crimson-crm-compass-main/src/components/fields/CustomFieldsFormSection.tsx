
import React from "react";
import type { CustomField } from "@/lib/types/customFields";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select";
import { FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";

interface CustomFieldsFormSectionProps {
  fields: CustomField[];
  values: Record<string, string>;
  onChange: (fieldId: string, value: string) => void;
  errors?: Record<string, string>;
}

/**
 * Generic renderer for custom fields in forms
 */
export function CustomFieldsFormSection({ fields, values, onChange, errors = {} }: CustomFieldsFormSectionProps) {
  if (!fields?.length) return null;

  return (
    <section className="mt-8 bg-white rounded shadow p-6">
      <h3 className="font-semibold text-lg mb-4">Additional Custom Fields</h3>
      <div className="grid gap-6">
        {fields.map(field => (
          <FormItem key={field.id}>
            <FormLabel>
              {field.label} {field.required && <span className="text-destructive">*</span>}
            </FormLabel>
            <FormControl>
              {(() => {
                switch (field.field_type) {
                  case "text":
                    return (
                      <Input
                        value={values[field.id] ?? ""}
                        onChange={e => onChange(field.id, e.target.value)}
                        placeholder={field.label}
                      />
                    );
                  case "number":
                    return (
                      <Input
                        type="number"
                        value={values[field.id] ?? ""}
                        onChange={e => onChange(field.id, e.target.value)}
                        placeholder={field.label}
                        step="any"
                      />
                    );
                  case "textarea":
                    return (
                      <Textarea
                        value={values[field.id] ?? ""}
                        onChange={e => onChange(field.id, e.target.value)}
                        placeholder={field.label}
                        className="resize-vertical"
                      />
                    );
                  case "date":
                    return (
                      <Input
                        type="date"
                        value={values[field.id] ?? ""}
                        onChange={e => onChange(field.id, e.target.value)}
                        placeholder={field.label}
                      />
                    );
                  case "boolean":
                    return (
                      <Checkbox
                        checked={values[field.id] === "true"}
                        onCheckedChange={val => onChange(field.id, val ? "true" : "false")}
                        id={field.id}
                      />
                    );
                  case "select":
                    return (
                      <Select
                        value={values[field.id] ?? ""}
                        onValueChange={val => onChange(field.id, val)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder={`Select ${field.label}`} />
                        </SelectTrigger>
                        <SelectContent>
                          {(field.options || []).map((opt, i) => (
                            <SelectItem key={i} value={opt}>{opt}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    );
                  case "url":
                    return (
                      <Input
                        type="url"
                        value={values[field.id] ?? ""}
                        onChange={e => onChange(field.id, e.target.value)}
                        placeholder={field.label}
                        pattern="https?://.*"
                        autoComplete="url"
                      />
                    );
                  case "phone":
                    return (
                      <Input
                        type="tel"
                        value={values[field.id] ?? ""}
                        onChange={e => onChange(field.id, e.target.value)}
                        placeholder={field.label}
                        autoComplete="tel"
                      />
                    );
                  case "currency":
                    return (
                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        value={values[field.id] ?? ""}
                        onChange={e => onChange(field.id, e.target.value)}
                        placeholder={field.label}
                        inputMode="decimal"
                        prefix="$"
                      />
                    );
                  default:
                    return <Input value={values[field.id] ?? ""} onChange={e => onChange(field.id, e.target.value)} />;
                }
              })()}
            </FormControl>
            {errors[field.id] && (
              <FormMessage>{errors[field.id]}</FormMessage>
            )}
          </FormItem>
        ))}
      </div>
    </section>
  );
}
