
import React, { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { normalizeOptions, isValidFieldName } from "@/lib/customFieldUtils";
import { FIELD_TYPE_OPTIONS } from "@/lib/fieldTypeConfig";
import type { CustomFieldType } from "@/lib/types/customFields";

type Props = {
  onAdd: (field: {
    label: string;
    name: string;
    field_type: CustomFieldType;
    options?: string[];
    required: boolean;
    visible: boolean;
  }) => void;
  existingNames: string[];
  loading?: boolean;
};

export function FieldForm({ onAdd, existingNames, loading }: Props) {
  const [input, setInput] = useState({
    label: "",
    name: "",
    field_type: "text" as CustomFieldType,
    options: "",
    required: false,
    visible: true,
  });

  const [error, setError] = useState<string | null>(null);

  // Real-time validation
  const validName = useMemo(
    () =>
      input.name &&
      isValidFieldName(input.name, existingNames) &&
      input.name.length > 0,
    [input.name, existingNames]
  );

  function handleAdd() {
    if (!input.label.trim()) {
      setError("Label is required.");
      return;
    }
    if (!validName) {
      setError("Name must be unique, non-empty, and only letters, numbers or underscores.");
      return;
    }
    if (
      input.field_type === "select" &&
      (!input.options.trim() || normalizeOptions(input.options)?.length === 0)
    ) {
      setError("Options required for select type.");
      return;
    }
    onAdd({
      label: input.label.trim(),
      name: input.name.trim(),
      field_type: input.field_type,
      required: input.required,
      visible: input.visible,
      options:
        input.field_type === "select"
          ? normalizeOptions(input.options)
          : undefined,
    });
    setInput({
      label: "",
      name: "",
      field_type: "text",
      options: "",
      required: false,
      visible: true,
    });
    setError(null);
  }

  return (
    <div className="flex flex-wrap gap-2" aria-label="Add custom field">
      <Input
        placeholder="Label (e.g. Budget Amount)"
        value={input.label}
        onChange={e => setInput(i => ({ ...i, label: e.target.value }))}
        className="flex-1 min-w-[120px]"
        aria-label="Field Label"
      />
      <Input
        placeholder="Name (e.g. budget_amount)"
        value={input.name}
        onChange={e => {
          const cleaned = e.target.value
            .replace(/[^a-zA-Z0-9_]/g, "_")
            .toLowerCase();
          setInput(i => ({ ...i, name: cleaned }));
        }}
        className={`flex-1 min-w-[120px] ${
          input.name && !validName ? "border-destructive" : ""
        }`}
        aria-label="Field Name"
      />
      <select
        className="border rounded px-2 py-1 bg-background z-30 relative"
        value={input.field_type}
        onChange={e =>
          setInput(i => ({
            ...i,
            field_type: e.target.value as CustomFieldType,
          }))
        }
        style={{ minWidth: 100 }}
        aria-label="Field Type"
      >
        {FIELD_TYPE_OPTIONS.map(opt => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
      {input.field_type === "select" && (
        <Input
          placeholder="Options (comma separated: A, B, C)"
          value={input.options}
          onChange={e => setInput(i => ({ ...i, options: e.target.value }))}
          className="flex-1 min-w-[180px]"
          aria-label="Select Options"
        />
      )}
      <div className="flex items-center pl-2">
        <Checkbox
          checked={input.required}
          onCheckedChange={val =>
            setInput(i => ({ ...i, required: !!val }))
          }
          aria-label="Required"
        />
        <span className="ml-2 text-sm">Required</span>
      </div>
      <div className="flex items-center pl-2">
        <Checkbox
          checked={input.visible}
          onCheckedChange={val =>
            setInput(i => ({ ...i, visible: !!val }))
          }
          aria-label="Visible"
        />
        <span className="ml-2 text-sm">Visible</span>
      </div>
      <Button
        onClick={handleAdd}
        className="ml-2"
        type="button"
        disabled={!input.label || !validName || loading}
        aria-label="Add Field"
      >
        Add
      </Button>
      <div className="w-full min-h-[18px] text-xs mt-1 text-destructive">
        {error}
      </div>
      <div className="pt-1 text-xs text-muted-foreground w-full">
        Name must be unique and only contain letters, numbers or underscores.
      </div>
    </div>
  );
}
