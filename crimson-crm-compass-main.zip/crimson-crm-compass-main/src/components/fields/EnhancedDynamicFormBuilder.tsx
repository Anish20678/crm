
import React, { useState } from "react";
import { UseFormReturn } from "react-hook-form";
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { CalendarIcon, ChevronDown, ChevronRight } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useFormFieldConfig } from "@/hooks/useFormFieldConfig";

interface EnhancedDynamicFormBuilderProps {
  module: string;
  form: UseFormReturn<any>;
  recordId?: string;
  customFieldValues?: Record<string, string>;
  onCustomFieldChange?: (fieldId: string, value: string) => void;
  customFieldErrors?: Record<string, string>;
}

export function EnhancedDynamicFormBuilder({ 
  module, 
  form, 
  recordId,
  customFieldValues = {},
  onCustomFieldChange,
  customFieldErrors = {}
}: EnhancedDynamicFormBuilderProps) {
  const { groupedFormFields, isLoading } = useFormFieldConfig(module);
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set(["basic"]));

  const toggleGroup = (groupId: string) => {
    setExpandedGroups(prev => {
      const newSet = new Set(prev);
      if (newSet.has(groupId)) {
        newSet.delete(groupId);
      } else {
        newSet.add(groupId);
      }
      return newSet;
    });
  };

  const renderSystemField = (field: any) => {
    switch (field.type) {
      case "text":
      case "email":
      case "phone":
        return (
          <FormField
            key={field.fieldName}
            control={form.control}
            name={field.fieldName}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>{field.label} {field.required && "*"}</FormLabel>
                <FormControl>
                  <Input 
                    type={field.type === "email" ? "email" : field.type === "phone" ? "tel" : "text"}
                    {...formField} 
                    value={formField.value || ""} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        );

      case "textarea":
        return (
          <FormField
            key={field.fieldName}
            control={form.control}
            name={field.fieldName}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>{field.label} {field.required && "*"}</FormLabel>
                <FormControl>
                  <Textarea {...formField} value={formField.value || ""} rows={3} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        );

      case "boolean":
        return (
          <FormField
            key={field.fieldName}
            control={form.control}
            name={field.fieldName}
            render={({ field: formField }) => (
              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                <div className="space-y-0.5">
                  <FormLabel className="text-base">{field.label}</FormLabel>
                </div>
                <FormControl>
                  <Switch
                    checked={formField.value || false}
                    onCheckedChange={formField.onChange}
                  />
                </FormControl>
              </FormItem>
            )}
          />
        );

      case "date":
        return (
          <FormField
            key={field.fieldName}
            control={form.control}
            name={field.fieldName}
            render={({ field: formField }) => (
              <FormItem className="flex flex-col">
                <FormLabel>{field.label} {field.required && "*"}</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full text-left font-normal",
                          !formField.value && "text-muted-foreground"
                        )}
                      >
                        {formField.value ? (
                          format(new Date(formField.value), "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={formField.value ? new Date(formField.value) : undefined}
                      onSelect={(date) => formField.onChange(date?.toISOString())}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
        );

      case "select":
        const selectOptions = getSelectOptions(field.fieldName, module);
        return (
          <FormField
            key={field.fieldName}
            control={form.control}
            name={field.fieldName}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>{field.label} {field.required && "*"}</FormLabel>
                <Select onValueChange={formField.onChange} defaultValue={formField.value || ""}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder={`Select ${field.label}`} />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {selectOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        );

      default:
        return null;
    }
  };

  const renderCustomField = (field: any) => {
    const value = customFieldValues[field.id] || "";
    const error = customFieldErrors[field.id];

    switch (field.field_type) {
      case "text":
      case "email":
      case "phone":
        return (
          <div key={field.id}>
            <FormLabel>{field.label} {field.required && "*"}</FormLabel>
            <Input
              type={field.field_type === "email" ? "email" : field.field_type === "phone" ? "tel" : "text"}
              value={value}
              onChange={(e) => onCustomFieldChange?.(field.id, e.target.value)}
              className={error ? "border-red-500" : ""}
            />
            {error && <p className="text-sm text-red-500 mt-1">{error}</p>}
          </div>
        );

      case "textarea":
        return (
          <div key={field.id}>
            <FormLabel>{field.label} {field.required && "*"}</FormLabel>
            <Textarea
              value={value}
              onChange={(e) => onCustomFieldChange?.(field.id, e.target.value)}
              rows={3}
              className={error ? "border-red-500" : ""}
            />
            {error && <p className="text-sm text-red-500 mt-1">{error}</p>}
          </div>
        );

      case "boolean":
        return (
          <div key={field.id} className="flex flex-row items-center justify-between rounded-lg border p-4">
            <div className="space-y-0.5">
              <FormLabel className="text-base">{field.label}</FormLabel>
            </div>
            <Switch
              checked={value === "true"}
              onCheckedChange={(checked) => onCustomFieldChange?.(field.id, checked.toString())}
            />
          </div>
        );

      case "select":
        const options = field.options || [];
        return (
          <div key={field.id}>
            <FormLabel>{field.label} {field.required && "*"}</FormLabel>
            <Select value={value} onValueChange={(newValue) => onCustomFieldChange?.(field.id, newValue)}>
              <SelectTrigger className={error ? "border-red-500" : ""}>
                <SelectValue placeholder={`Select ${field.label}`} />
              </SelectTrigger>
              <SelectContent>
                {options.map((option: any) => (
                  <SelectItem key={option.value || option} value={option.value || option}>
                    {option.label || option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {error && <p className="text-sm text-red-500 mt-1">{error}</p>}
          </div>
        );

      default:
        return null;
    }
  };

  if (isLoading) {
    return <div className="text-center py-8">Loading form configuration...</div>;
  }

  return (
    <div className="space-y-6">
      {groupedFormFields.map((group) => {
        const hasFields = group.systemFields.length > 0 || group.customFields.length > 0;
        if (!hasFields) return null;

        const isExpanded = expandedGroups.has(group.id);

        return (
          <Collapsible key={group.id} open={isExpanded} onOpenChange={() => toggleGroup(group.id)}>
            <CollapsibleTrigger asChild>
              <Card className="cursor-pointer hover:bg-muted/50 transition-colors">
                <CardHeader className="py-3">
                  <div className="flex items-center gap-2">
                    {isExpanded ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                    <CardTitle className="text-lg">{group.label}</CardTitle>
                    <span className="text-sm text-muted-foreground">
                      ({group.systemFields.length + group.customFields.length} fields)
                    </span>
                  </div>
                  {group.description && (
                    <p className="text-sm text-muted-foreground">{group.description}</p>
                  )}
                </CardHeader>
              </Card>
            </CollapsibleTrigger>
            
            <CollapsibleContent className="mt-2">
              <Card>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {group.systemFields.map(renderSystemField)}
                    {group.customFields.map(renderCustomField)}
                  </div>
                </CardContent>
              </Card>
            </CollapsibleContent>
          </Collapsible>
        );
      })}
    </div>
  );
}

// Helper function to get select options for system fields
function getSelectOptions(fieldName: string, module: string) {
  const options: Record<string, { value: string; label: string }[]> = {
    status: [
      { value: "active", label: "Active" },
      { value: "inactive", label: "Inactive" },
      { value: "pending", label: "Pending" },
    ],
    emirates: [
      { value: "Abu Dhabi", label: "Abu Dhabi" },
      { value: "Dubai", label: "Dubai" },
      { value: "Sharjah", label: "Sharjah" },
      { value: "Ajman", label: "Ajman" },
      { value: "Umm Al Quwain", label: "Umm Al Quwain" },
      { value: "Ras Al Khaimah", label: "Ras Al Khaimah" },
      { value: "Fujairah", label: "Fujairah" },
    ],
    lead_source: [
      { value: "Meta Ads", label: "Meta Ads" },
      { value: "Google Ads", label: "Google Ads" },
      { value: "Referral", label: "Referral" },
      { value: "Direct", label: "Direct" },
      { value: "Other", label: "Other" },
    ],
    preferred_contact_method: [
      { value: "WhatsApp", label: "WhatsApp" },
      { value: "Call", label: "Call" },
      { value: "Email", label: "Email" },
      { value: "SMS", label: "SMS" },
    ],
    priority: [
      { value: "low", label: "Low" },
      { value: "medium", label: "Medium" },
      { value: "high", label: "High" },
    ],
    payment_status: [
      { value: "pending", label: "Pending" },
      { value: "partial", label: "Partial" },
      { value: "completed", label: "Completed" },
      { value: "overdue", label: "Overdue" },
    ],
  };

  return options[fieldName] || [];
}
