
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Eye } from "lucide-react";
import { useSystemFieldDisplay } from "@/hooks/useSystemFieldDisplay";
import { useCustomFieldsData } from "@/hooks/useCustomFieldsData";
import { useFieldGroups } from "@/hooks/useFieldGroups";
import { FormPreview } from "./FormPreview";
import { ListPreview } from "./ListPreview";

interface LivePreviewPanelProps {
  module: string;
  previewMode: "form" | "list";
  selectedGroup?: string | null;
}

export function LivePreviewPanel({ 
  module, 
  previewMode, 
  selectedGroup 
}: LivePreviewPanelProps) {
  const { visibleFields, isLoading: fieldsLoading } = useSystemFieldDisplay(module);
  const { customFields, isLoading: customLoading } = useCustomFieldsData(module);
  const { fieldGroups } = useFieldGroups(module);

  if (fieldsLoading || customLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">Loading preview...</div>
      </div>
    );
  }

  // Filter fields by selected group if any
  const filteredSystemFields = selectedGroup 
    ? visibleFields.filter(field => field.group === selectedGroup)
    : visibleFields;
    
  const filteredCustomFields = selectedGroup
    ? customFields.filter(field => field.field_group === selectedGroup)
    : customFields.filter(field => field.visible);

  const totalVisibleFields = filteredSystemFields.length + filteredCustomFields.length;

  return (
    <div className="h-full">
      {/* Preview Header */}
      <div className="p-4 border-b bg-muted/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Eye className="h-4 w-4" />
            <span className="font-medium">
              {previewMode === "form" ? "Form Preview" : "List Preview"}
            </span>
            {selectedGroup && (
              <Badge variant="outline">
                {fieldGroups.find(g => g.id === selectedGroup)?.label || selectedGroup}
              </Badge>
            )}
          </div>
          <div className="text-sm text-muted-foreground">
            {totalVisibleFields} visible fields
          </div>
        </div>
        
        {totalVisibleFields === 0 && (
          <div className="flex items-center gap-2 mt-2 text-amber-600">
            <AlertCircle className="h-4 w-4" />
            <span className="text-sm">No visible fields to preview</span>
          </div>
        )}
      </div>

      {/* Preview Content */}
      <ScrollArea className="h-[calc(100%-80px)]">
        <div className="p-4">
          {previewMode === "form" ? (
            <FormPreview
              module={module}
              systemFields={filteredSystemFields}
              customFields={filteredCustomFields}
              fieldGroups={fieldGroups}
              selectedGroup={selectedGroup}
            />
          ) : (
            <ListPreview
              module={module}
              systemFields={filteredSystemFields}
              customFields={filteredCustomFields}
            />
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
