
import React from "react";
import type { CustomField } from "@/lib/types/customFields";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import { FIELD_TYPE_LABELS } from "@/lib/fieldTypeConfig";

type Props = {
  field: CustomField;
  onDelete: (field: CustomField) => void;
  onPreview?: (field: CustomField) => void;
};

export const FieldItem = React.memo(function FieldItem({
  field,
  onDelete,
  onPreview,
}: Props) {
  return (
    <div className="flex items-center gap-3 py-2 px-3 rounded border bg-background shadow-sm" tabIndex={0} aria-label={`Field ${field.label}`}>
      <div className="flex-1 truncate">
        <span className="font-medium">{field.label}</span>
        <span className="ml-2 text-xs text-muted-foreground">
          ({FIELD_TYPE_LABELS[field.field_type] ?? field.field_type})
        </span>
      </div>
      {field.field_type === "select" && field.options && (
        <div className="text-xs text-muted-foreground whitespace-nowrap">
          Options: {(Array.isArray(field.options) ? field.options : []).join(", ")}
        </div>
      )}
      <span className="text-xs">{field.required ? "● Required" : ""}</span>
      <span className="text-xs">{field.visible ? "● Visible" : ""}</span>
      {onPreview && (
        <Button variant="ghost" size="icon" onClick={() => onPreview(field)} aria-label={`Preview ${field.label}`}>
          {/* Placeholder for preview icon if needed */}
          <span>👁️</span>
        </Button>
      )}
      <Button variant="ghost" size="icon" onClick={() => onDelete(field)} aria-label={`Delete ${field.label}`}>
        <Trash2 className="h-4 w-4 text-red-600" />
      </Button>
    </div>
  );
});
