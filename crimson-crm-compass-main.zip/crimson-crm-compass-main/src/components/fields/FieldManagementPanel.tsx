
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { 
  Search, 
  GripVertical, 
  Eye, 
  EyeOff, 
  Settings, 
  ChevronDown, 
  ChevronRight,
  Plus,
  Filter
} from "lucide-react";
import { useSystemFieldConfigs } from "@/hooks/useSystemFieldConfigs";
import { useFieldGroups } from "@/hooks/useFieldGroups";
import { useCustomFieldsData } from "@/hooks/useCustomFieldsData";
import { getSystemFieldsForModule } from "@/lib/systemFields";

interface FieldManagementPanelProps {
  module: string;
  selectedGroup: string | null;
  onGroupSelect: (groupId: string | null) => void;
}

export function FieldManagementPanel({ 
  module, 
  selectedGroup, 
  onGroupSelect 
}: FieldManagementPanelProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState<"all" | "system" | "custom">("all");
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set(["basic"]));

  const { systemFieldConfigs, upsertConfig, isUpdating } = useSystemFieldConfigs(module);
  const { fieldGroups } = useFieldGroups(module);
  const { customFields } = useCustomFieldsData(module);
  const systemFields = getSystemFieldsForModule(module);

  // Merge system fields with configurations
  const fieldsWithConfig = systemFields.map(field => {
    const userConfig = systemFieldConfigs.find(config => config.field_name === field.name);
    return {
      ...field,
      type: "system" as const,
      config: userConfig || {
        id: '',
        user_id: '',
        module,
        field_name: field.name,
        is_visible: field.defaultVisible,
        is_required: field.required,
        field_order: 0,
        width_percentage: field.defaultWidth,
        field_group: field.fieldGroup,
        group_order: 0,
        created_at: '',
        updated_at: '',
      },
    };
  });

  // Add custom fields to the mix
  const allFields = [
    ...fieldsWithConfig,
    ...customFields.map(field => ({
      ...field,
      type: "custom" as const,
      config: null,
    }))
  ];

  // Filter fields
  const filteredFields = allFields.filter(field => {
    const matchesSearch = field.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         field.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === "all" || field.type === filterType;
    const matchesGroup = !selectedGroup || 
                        (field.type === "system" ? field.config?.field_group === selectedGroup : field.field_group === selectedGroup);
    
    return matchesSearch && matchesType && matchesGroup;
  });

  // Group fields by their group
  const groupedFields = fieldGroups.reduce((acc, group) => {
    const groupFields = filteredFields.filter(field => 
      field.type === "system" 
        ? field.config?.field_group === group.id 
        : field.field_group === group.id
    );
    if (groupFields.length > 0) {
      acc[group.id] = { group, fields: groupFields };
    }
    return acc;
  }, {} as Record<string, { group: any; fields: typeof filteredFields }>);

  const toggleGroup = (groupId: string) => {
    setExpandedGroups(prev => {
      const newSet = new Set(prev);
      if (newSet.has(groupId)) {
        newSet.delete(groupId);
      } else {
        newSet.add(groupId);
      }
      return newSet;
    });
  };

  const handleVisibilityChange = (field: any, isVisible: boolean) => {
    if (field.type === "system") {
      upsertConfig({
        module,
        field_name: field.name,
        is_visible: isVisible,
      });
    }
    // Handle custom fields visibility update here when implemented
  };

  const handleRequiredChange = (field: any, isRequired: boolean) => {
    if (field.type === "system") {
      upsertConfig({
        module,
        field_name: field.name,
        is_required: isRequired,
      });
    }
    // Handle custom fields required update here when implemented
  };

  // Helper function to get a unique key for each field
  const getFieldKey = (field: any) => {
    return field.type === "system" ? field.name : field.id;
  };

  return (
    <div className="space-y-4">
      {/* Search and Filters */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search fields..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
        
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <Select value={filterType} onValueChange={(value: any) => setFilterType(value)}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Fields</SelectItem>
              <SelectItem value="system">System</SelectItem>
              <SelectItem value="custom">Custom</SelectItem>
            </SelectContent>
          </Select>
          
          {selectedGroup && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => onGroupSelect(null)}
            >
              Clear Group Filter
            </Button>
          )}
        </div>
      </div>

      {/* Fields by Group */}
      <ScrollArea className="h-[400px]">
        <div className="space-y-2">
          {Object.entries(groupedFields).map(([groupId, { group, fields }]) => {
            const isExpanded = expandedGroups.has(groupId);
            const visibleCount = fields.filter(f => 
              f.type === "system" ? f.config?.is_visible : f.visible
            ).length;

            return (
              <Collapsible
                key={groupId}
                open={isExpanded}
                onOpenChange={() => toggleGroup(groupId)}
              >
                <CollapsibleTrigger asChild>
                  <Card className="cursor-pointer hover:bg-muted/50 transition-colors">
                    <CardHeader className="py-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {isExpanded ? (
                            <ChevronDown className="h-4 w-4" />
                          ) : (
                            <ChevronRight className="h-4 w-4" />
                          )}
                          <CardTitle className="text-sm">{group.label}</CardTitle>
                          {group.is_system && (
                            <Badge variant="secondary" className="text-xs">System</Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <span>{visibleCount}/{fields.length} visible</span>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>
                </CollapsibleTrigger>
                
                <CollapsibleContent className="mt-2">
                  <div className="space-y-2 pl-6">
                    {fields.map((field) => (
                      <Card key={getFieldKey(field)} className="p-3">
                        <div className="flex items-center gap-3">
                          <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
                          
                          <div className="flex items-center gap-2 min-w-0 flex-1">
                            <Switch
                              checked={field.type === "system" ? field.config?.is_visible : field.visible}
                              onCheckedChange={(checked) => handleVisibilityChange(field, checked)}
                              disabled={isUpdating}
                            />
                            {(field.type === "system" ? field.config?.is_visible : field.visible) ? (
                              <Eye className="h-4 w-4 text-green-600" />
                            ) : (
                              <EyeOff className="h-4 w-4 text-muted-foreground" />
                            )}
                            <div className="min-w-0 flex-1">
                              <div className="font-medium truncate">{field.label}</div>
                              <div className="text-xs text-muted-foreground flex items-center gap-2">
                                <span>{field.name}</span>
                                <Badge variant="outline" className="text-xs">
                                  {field.type}
                                </Badge>
                                {field.type === "system" && field.config?.is_required && (
                                  <Badge variant="destructive" className="text-xs">Required</Badge>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            {field.type === "system" && !field.required && (
                              <div className="flex items-center gap-1">
                                <span className="text-xs text-muted-foreground">Required:</span>
                                <Switch
                                  checked={field.config?.is_required || false}
                                  onCheckedChange={(checked) => handleRequiredChange(field, checked)}
                                  disabled={isUpdating}
                                />
                              </div>
                            )}
                            <Button variant="ghost" size="sm">
                              <Settings className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            );
          })}

          {Object.keys(groupedFields).length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No fields match your current filters
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Add Field Button */}
      <Button className="w-full" variant="outline">
        <Plus className="h-4 w-4 mr-2" />
        Add Custom Field
      </Button>
    </div>
  );
}
