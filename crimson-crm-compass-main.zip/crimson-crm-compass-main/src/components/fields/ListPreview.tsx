
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface ListPreviewProps {
  module: string;
  systemFields: any[];
  customFields: any[];
}

export function ListPreview({ module, systemFields, customFields }: ListPreviewProps) {
  // Combine and sort fields by order
  const allFields = [
    ...systemFields.map(field => ({
      ...field,
      type: "system" as const,
      order: field.fieldOrder || 0,
    })),
    ...customFields.filter(field => field.visible).map(field => ({
      ...field,
      type: "custom" as const,
      order: field.order_index || 999,
    }))
  ].sort((a, b) => a.order - b.order);

  const generateSampleData = () => {
    const samples = [];
    for (let i = 1; i <= 3; i++) {
      const row: Record<string, any> = {};
      allFields.forEach(field => {
        const fieldName = field.fieldName || field.name;
        switch (field.type === "system" ? field.type : field.field_type) {
          case "text":
            row[fieldName] = `Sample ${fieldName} ${i}`;
            break;
          case "email":
            row[fieldName] = `user${i}@example.com`;
            break;
          case "phone":
            row[fieldName] = `+971 50 123 456${i}`;
            break;
          case "boolean":
            row[fieldName] = i % 2 === 0 ? "Yes" : "No";
            break;
          case "date":
            row[fieldName] = new Date(2024, 0, i).toLocaleDateString();
            break;
          case "select":
            row[fieldName] = `Option ${i}`;
            break;
          case "number":
          case "currency":
            row[fieldName] = (i * 1000).toLocaleString();
            break;
          default:
            row[fieldName] = `Value ${i}`;
        }
      });
      samples.push(row);
    }
    return samples;
  };

  const sampleData = generateSampleData();

  if (allFields.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        No visible fields to display in list view
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {module.charAt(0).toUpperCase() + module.slice(1)} List View
          <Badge variant="outline">Preview</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                {allFields.map((field) => (
                  <TableHead 
                    key={field.fieldName || field.name}
                    style={{ 
                      width: field.type === "system" ? `${field.width}%` : "auto" 
                    }}
                  >
                    <div className="flex items-center gap-2">
                      {field.label}
                      {field.type === "custom" && (
                        <Badge variant="outline" className="text-xs">Custom</Badge>
                      )}
                      {field.required && (
                        <span className="text-red-500 text-xs">*</span>
                      )}
                    </div>
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {sampleData.map((row, index) => (
                <TableRow key={index}>
                  {allFields.map((field) => {
                    const fieldName = field.fieldName || field.name;
                    return (
                      <TableCell key={fieldName}>
                        {row[fieldName]}
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        
        <div className="mt-4 text-xs text-muted-foreground">
          <p>This is a preview showing sample data. The actual list will display real records.</p>
          <p>Field width and order will be applied based on your configuration.</p>
        </div>
      </CardContent>
    </Card>
  );
}
