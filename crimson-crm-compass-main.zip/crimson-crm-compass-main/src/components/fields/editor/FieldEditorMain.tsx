import React, { useState, useEffect, useCallback, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Layout, List, RotateCcw, Save, Eye } from "lucide-react";
import { DropResult } from "react-beautiful-dnd";
import { useCustomFieldsData } from "@/hooks/useCustomFieldsData";
import { useCustomFieldsMutations } from "@/hooks/useCustomFieldsMutations";
import { useSystemFieldDisplay } from "@/hooks/useSystemFieldDisplay";
import { useSystemFieldConfigs } from "@/hooks/useSystemFieldConfigs";
import { useEnhancedGroupManagement } from "@/hooks/useEnhancedGroupManagement";
import { useToast } from "@/hooks/use-toast";
import { FieldDragDropArea } from "./FieldDragDropArea";
import { ZohoStyleFormPreview } from "./ZohoStyleFormPreview";
import { useFieldDragDrop } from "./DragDropContext";
import { generateSequentialOrderIndexes } from "@/lib/orderIndexUtils";
import { getFieldGroupsForModule } from "@/lib/systemFields";

interface FieldEditorMainProps {
  module: string;
  selectedField: string | null;
  onFieldSelect: (fieldId: string) => void;
  activeView: "form" | "list";
  onViewChange: (view: "form" | "list") => void;
}

interface FieldItem {
  id: string;
  label: string;
  type: string;
  required: boolean;
  visible: boolean;
  isSystem: boolean;
  group?: string;
  order_index: number;
}

interface FieldGroup {
  id: string;
  label: string;
  fields: FieldItem[];
  expanded: boolean;
  canDelete: boolean;
  isSystem: boolean;
}

export function FieldEditorMain({
  module,
  selectedField,
  onFieldSelect,
  activeView,
  onViewChange
}: FieldEditorMainProps) {
  const { customFields, refetch: refetchCustomFields } = useCustomFieldsData(module);
  const { visibleFields } = useSystemFieldDisplay(module);
  const { reorderFields } = useCustomFieldsMutations(module);
  const { updateFieldsByGroup, systemFieldConfigs } = useSystemFieldConfigs(module);
  const {
    fieldGroups: dbFieldGroups,
    canDeleteGroup,
    canEditGroup,
    updateGroupProperties,
    deleteCustomGroup
  } = useEnhancedGroupManagement(module);
  const { toast } = useToast();
  const { handleDrop } = useFieldDragDrop();

  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});
  const [currentFields, setCurrentFields] = useState<FieldItem[]>([]);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Get default groups for the module
  const getDefaultGroups = useCallback(() => {
    return getFieldGroupsForModule(module);
  }, [module]);

  // Initialize fields with proper group assignment
  const initializeFields = useCallback(() => {
    console.log("Initializing fields for module:", module);
    console.log("System fields:", visibleFields);
    console.log("Custom fields:", customFields);
    console.log("System field configs:", systemFieldConfigs);
    
    const systemFieldItems: FieldItem[] = visibleFields.map((field, index) => {
      const config = systemFieldConfigs.find(c => c.field_name === field.fieldName);
      return {
        id: field.fieldName,
        label: field.label,
        type: field.type,
        required: config?.is_required ?? field.required,
        visible: config?.is_visible ?? field.visible,
        isSystem: true,
        group: config?.field_group ?? field.group,
        order_index: config?.field_order || 1000 + index * 100
      };
    });

    const customFieldItems: FieldItem[] = customFields.map(field => ({
      id: field.id,
      label: field.label,
      type: field.field_type,
      required: field.required,
      visible: field.visible,
      isSystem: false,
      group: field.field_group || 'custom',
      order_index: field.order_index || 5000
    }));

    const allFields = [...systemFieldItems, ...customFieldItems];
    console.log("Initialized fields:", allFields);
    return allFields;
  }, [visibleFields, customFields, systemFieldConfigs]);

  // Initialize expanded state
  const initializeExpandedGroups = useCallback(() => {
    const initialExpanded: Record<string, boolean> = {};
    dbFieldGroups.forEach(group => {
      initialExpanded[group.id] = group.default_expanded;
    });
    const defaultGroups = getDefaultGroups();
    defaultGroups.forEach(group => {
      if (!(group.id in initialExpanded)) {
        initialExpanded[group.id] = group.defaultExpanded ?? true;
      }
    });
    return initialExpanded;
  }, [dbFieldGroups, getDefaultGroups]);

  // Initialize on mount and when data changes
  useEffect(() => {
    const newFields = initializeFields();
    setCurrentFields(newFields);
    const initialExpanded = initializeExpandedGroups();
    setExpandedGroups(initialExpanded);
  }, [initializeFields, initializeExpandedGroups]);

  // Handle field creation callback
  const handleFieldCreated = useCallback((fieldId: string) => {
    console.log("Field created, refreshing data...");
    setTimeout(() => {
      refetchCustomFields();
      onFieldSelect(fieldId);
    }, 500);
  }, [refetchCustomFields, onFieldSelect]);

  // Toggle field visibility
  const toggleFieldVisibility = useCallback((fieldId: string) => {
    setCurrentFields(fields => fields.map(field => 
      field.id === fieldId ? { ...field, visible: !field.visible } : field
    ));
    setHasUnsavedChanges(true);
  }, []);

  // Toggle group expanded
  const toggleGroupExpanded = useCallback((groupId: string) => {
    setExpandedGroups(prev => ({
      ...prev,
      [groupId]: !prev[groupId]
    }));
  }, []);

  // Handle edit group name
  const handleEditGroupName = useCallback(async (groupId: string, newName: string) => {
    const success = await updateGroupProperties(groupId, { label: newName });
    if (success) {
      toast({
        title: "Group updated",
        description: "Group name has been updated successfully."
      });
    }
  }, [updateGroupProperties, toast]);

  // Handle delete group
  const handleDeleteGroup = useCallback(async (groupId: string) => {
    if (!canDeleteGroup(groupId)) {
      toast({
        title: "Cannot delete system group",
        description: "System groups cannot be deleted.",
        variant: "destructive"
      });
      return;
    }
    
    if (window.confirm("Are you sure you want to delete this field group? Fields will be moved to 'Custom Fields'.")) {
      setCurrentFields(fields => fields.map(field => 
        field.group === groupId ? { ...field, group: 'custom' } : field
      ));
      await deleteCustomGroup(groupId);
      setHasUnsavedChanges(true);
    }
  }, [canDeleteGroup, deleteCustomGroup, toast]);

  // Handle create group
  const handleCreateGroup = useCallback(async (group: {
    id: string;
    label: string;
    description?: string;
    defaultExpanded: boolean;
  }) => {
    console.log("Group creation will be handled by the GroupCreationWidget");
  }, []);

  // Handle save layout
  const handleSaveLayout = useCallback(async () => {
    try {
      console.log("Saving layout configuration");
      const systemFields = currentFields.filter(f => f.isSystem);
      const customFields = currentFields.filter(f => !f.isSystem);

      if (systemFields.length > 0) {
        const systemFieldUpdates = systemFields.map(field => ({
          field_name: field.id,
          field_group: field.group || 'basic',
          group_order: 0
        }));

        for (const update of systemFieldUpdates) {
          await new Promise(resolve => {
            updateFieldsByGroup([update]);
            setTimeout(resolve, 100);
          });
        }
      }

      if (customFields.length > 0) {
        const customFieldOrder = customFields.map(field => ({
          id: field.id,
          order_index: field.order_index,
          field_group: field.group,
          visible: field.visible,
          required: field.required
        }));
        await reorderFields(customFieldOrder);
      }

      setHasUnsavedChanges(false);
      toast({
        title: "Layout Saved",
        description: "Field layout and order have been saved successfully."
      });
    } catch (error) {
      console.error("Failed to save layout:", error);
      toast({
        title: "Save Failed",
        description: "Failed to save field layout. Please try again.",
        variant: "destructive"
      });
    }
  }, [currentFields, updateFieldsByGroup, reorderFields, toast]);

  // Handle reset layout
  const handleResetLayout = useCallback(() => {
    if (window.confirm("Are you sure you want to reset the layout to default? This will remove all custom groupings.")) {
      const resetFields = initializeFields();
      setCurrentFields(resetFields);
      setHasUnsavedChanges(false);
      toast({
        title: "Layout Reset",
        description: "Field layout has been reset to default."
      });
    }
  }, [initializeFields, toast]);

  // Memoize grouped fields calculation
  const groupedFields = useMemo(() => {
    const grouped = currentFields.reduce((acc, field) => {
      const group = field.group || 'custom';
      if (!acc[group]) acc[group] = [];
      acc[group].push(field);
      return acc;
    }, {} as Record<string, FieldItem[]>);

    Object.keys(grouped).forEach(groupId => {
      grouped[groupId].sort((a, b) => (a.order_index || 0) - (b.order_index || 0));
    });

    const defaultGroups = getDefaultGroups();
    defaultGroups.forEach(defaultGroup => {
      if (!grouped[defaultGroup.id]) {
        grouped[defaultGroup.id] = [];
      }
    });

    dbFieldGroups.forEach(dbGroup => {
      if (!grouped[dbGroup.id]) {
        grouped[dbGroup.id] = [];
      }
    });

    return grouped;
  }, [currentFields, dbFieldGroups, getDefaultGroups]);

  // Memoize field groups for components
  const fieldGroupsForComponents: FieldGroup[] = useMemo(() => {
    const defaultGroups = getDefaultGroups();
    return Object.entries(groupedFields).map(([groupId, fields]) => {
      const dbGroup = dbFieldGroups.find(g => g.id === groupId);
      const defaultGroup = defaultGroups.find(g => g.id === groupId);

      return {
        id: groupId,
        label: dbGroup?.label || defaultGroup?.label || groupId,
        fields,
        expanded: expandedGroups[groupId] ?? true,
        canDelete: canDeleteGroup(groupId),
        isSystem: defaultGroup ? true : false
      };
    });
  }, [groupedFields, dbFieldGroups, expandedGroups, getDefaultGroups, canDeleteGroup]);

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="bg-white border-b px-6 py-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Layout Editor</h2>
            <p className="text-sm text-muted-foreground">
              {module.charAt(0).toUpperCase() + module.slice(1)} module field layout
              {hasUnsavedChanges && <span className="text-orange-600 ml-2">• Unsaved changes</span>}
            </p>
          </div>
          
          <div className="flex items-center gap-3">
            {/* View Toggle */}
            <Tabs value={activeView} onValueChange={value => onViewChange(value as "form" | "list")}>
              <TabsList className="grid w-[180px] grid-cols-2">
                <TabsTrigger value="form" className="flex items-center gap-1">
                  Layout
                </TabsTrigger>
                <TabsTrigger value="list" className="flex items-center gap-1">
                  Preview
                </TabsTrigger>
              </TabsList>
            </Tabs>
            
            {/* Action Buttons */}
            <Button variant="outline" size="sm" onClick={handleResetLayout}>
              <RotateCcw className="h-3 w-3 mr-1" />
              Reset
            </Button>
            <Button 
              size="sm" 
              onClick={handleSaveLayout} 
              className={hasUnsavedChanges ? "bg-orange-600 hover:bg-orange-700" : ""}
            >
              <Save className="h-3 w-3 mr-1" />
              Save Layout
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content - REMOVED DragDropContext wrapper */}
      <div className="flex-1 overflow-hidden">
        <Tabs value={activeView} className="h-full">
          <TabsContent value="form" className="h-full m-0">
            <FieldDragDropArea
              fieldGroups={fieldGroupsForComponents}
              selectedField={selectedField}
              onFieldSelect={onFieldSelect}
              onToggleFieldVisibility={toggleFieldVisibility}
              onToggleGroupExpanded={toggleGroupExpanded}
              onEditGroupName={handleEditGroupName}
              onDeleteGroup={handleDeleteGroup}
              onCreateGroup={handleCreateGroup}
              fields={currentFields}
              onFieldsUpdate={setCurrentFields}
              onFieldCreated={handleFieldCreated}
            />
          </TabsContent>
          
          <TabsContent value="list" className="h-full m-0">
            <ZohoStyleFormPreview
              fieldGroups={fieldGroupsForComponents}
              selectedField={selectedField}
              onFieldSelect={onFieldSelect}
            />
          </TabsContent>
        </Tabs>
      </div>

      {/* Stats Footer */}
      <div className="bg-white border-t px-6 py-2">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="bg-blue-100 text-blue-700">
              {currentFields.filter(f => f.isSystem).length} System
            </Badge>
            <Badge variant="secondary" className="bg-purple-100 text-purple-700">
              {currentFields.filter(f => !f.isSystem).length} Custom
            </Badge>
            <Badge variant="secondary" className="bg-green-100 text-green-700">
              {currentFields.filter(f => f.visible).length} Visible
            </Badge>
          </div>
          
          <div className="text-muted-foreground">
            {Object.keys(groupedFields).length} section{Object.keys(groupedFields).length !== 1 ? 's' : ''}
          </div>
        </div>
      </div>
    </div>
  );
}
