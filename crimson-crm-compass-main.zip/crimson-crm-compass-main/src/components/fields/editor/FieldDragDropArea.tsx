
import React, { useState } from "react";
import { Droppable, Draggable } from "react-beautiful-dnd";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  ChevronDown,
  ChevronRight,
  Eye,
  EyeOff,
  GripVertical,
  Settings,
  Trash2,
  Edit3,
  Check,
  X,
  Plus,
  FolderPlus,
} from "lucide-react";
import { useFieldDragDrop } from "./DragDropContext";

interface FieldItem {
  id: string;
  label: string;
  type: string;
  required: boolean;
  visible: boolean;
  isSystem: boolean;
  group?: string;
  order_index: number;
}

interface FieldGroup {
  id: string;
  label: string;
  fields: FieldItem[];
  expanded: boolean;
  canDelete: boolean;
  isSystem?: boolean;
}

interface FieldDragDropAreaProps {
  fieldGroups: FieldGroup[];
  selectedField: string | null;
  onFieldSelect: (fieldId: string) => void;
  onToggleFieldVisibility: (fieldId: string) => void;
  onToggleGroupExpanded: (groupId: string) => void;
  onEditGroupName: (groupId: string, newName: string) => void;
  onDeleteGroup: (groupId: string) => void;
  onCreateGroup: (group: any) => void;
  fields: FieldItem[];
  onFieldsUpdate: (fields: FieldItem[]) => void;
  onFieldCreated?: (fieldId: string) => void;
}

export function FieldDragDropArea({
  fieldGroups,
  selectedField,
  onFieldSelect,
  onToggleFieldVisibility,
  onToggleGroupExpanded,
  onEditGroupName,
  onDeleteGroup,
  onCreateGroup,
  fields,
  onFieldsUpdate,
  onFieldCreated,
}: FieldDragDropAreaProps) {
  const [editingGroup, setEditingGroup] = useState<string | null>(null);
  const [editingName, setEditingName] = useState("");
  const [showGroupCreator, setShowGroupCreator] = useState(false);
  
  const { isDragging, draggedItem, setDraggedItem, setIsDragging } = useFieldDragDrop();

  const handleStartEdit = (groupId: string, currentName: string) => {
    setEditingGroup(groupId);
    setEditingName(currentName);
  };

  const handleSaveEdit = () => {
    if (editingGroup && editingName.trim()) {
      onEditGroupName(editingGroup, editingName.trim());
    }
    setEditingGroup(null);
    setEditingName("");
  };

  const handleCancelEdit = () => {
    setEditingGroup(null);
    setEditingName("");
  };

  const handleFieldDragStart = (fieldId: string, sourceGroup: string) => {
    console.log("Starting drag for existing field:", fieldId, "from group:", sourceGroup);
    setDraggedItem({
      id: fieldId,
      type: "existing-field",
      sourceGroup
    });
    setIsDragging(true);
  };

  // Enhanced drop zone indicator component
  const DropZoneIndicator = ({ groupId, position }: { groupId: string; position: number }) => {
    const isActive = isDragging && (
      (draggedItem?.type === "new-field") ||
      (draggedItem?.type === "existing-field" && draggedItem.sourceGroup !== groupId)
    );

    if (!isActive) return null;

    return (
      <div className="relative">
        <div className="h-1 bg-blue-500 rounded-full mx-4 my-1 transition-all duration-200 shadow-lg">
          <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-2 h-2 bg-blue-500 rounded-full -translate-x-1"></div>
          <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-2 h-2 bg-blue-500 rounded-full translate-x-1"></div>
        </div>
        <div className="text-xs text-blue-600 text-center font-medium">
          Drop here for position {position + 1}
        </div>
      </div>
    );
  };

  return (
    <ScrollArea className="h-full">
      <div className="p-6 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Field Groups</h3>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowGroupCreator(!showGroupCreator)}
          >
            <FolderPlus className="h-4 w-4 mr-2" />
            New Group
          </Button>
        </div>

        {/* Field Groups */}
        {fieldGroups.map((group) => (
          <Card key={group.id} className="border-2 border-dashed border-gray-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onToggleGroupExpanded(group.id)}
                    className="p-1 h-6 w-6"
                  >
                    {group.expanded ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                  </Button>

                  {editingGroup === group.id ? (
                    <div className="flex items-center gap-2">
                      <Input
                        value={editingName}
                        onChange={(e) => setEditingName(e.target.value)}
                        className="h-8 text-sm"
                        onKeyDown={(e) => {
                          if (e.key === "Enter") handleSaveEdit();
                          if (e.key === "Escape") handleCancelEdit();
                        }}
                        autoFocus
                      />
                      <Button size="sm" variant="ghost" onClick={handleSaveEdit}>
                        <Check className="h-3 w-3" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={handleCancelEdit}>
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <h4 className="font-medium">{group.label}</h4>
                      {group.isSystem && (
                        <Badge variant="secondary" className="text-xs">
                          System
                        </Badge>
                      )}
                    </>
                  )}
                </div>

                <div className="flex items-center gap-1">
                  <Badge variant="outline" className="text-xs">
                    {group.fields.length} fields
                  </Badge>
                  
                  {editingGroup !== group.id && (
                    <>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleStartEdit(group.id, group.label)}
                        className="h-7 w-7 p-0"
                      >
                        <Edit3 className="h-3 w-3" />
                      </Button>
                      
                      {group.canDelete && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onDeleteGroup(group.id)}
                          className="h-7 w-7 p-0 text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      )}
                    </>
                  )}
                </div>
              </div>
            </CardHeader>

            {group.expanded && (
              <CardContent className="pt-0">
                {/* Enhanced Droppable area with precise positioning */}
                <Droppable droppableId={group.id}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className={`min-h-[100px] rounded-lg border-2 border-dashed p-3 transition-all duration-200 ${
                        snapshot.isDraggingOver || (isDragging && draggedItem?.type === "new-field")
                          ? "border-blue-400 bg-blue-50 ring-2 ring-blue-200"
                          : "border-gray-200 bg-gray-50/50"
                      }`}
                    >
                      {/* Empty state with enhanced drop zone */}
                      {group.fields.length === 0 ? (
                        <>
                          <DropZoneIndicator groupId={group.id} position={0} />
                          <div className={`text-center py-8 transition-all duration-200 ${
                            snapshot.isDraggingOver || (isDragging && draggedItem?.type === "new-field")
                              ? "text-blue-600"
                              : "text-muted-foreground"
                          }`}>
                            <Settings className={`h-8 w-8 mx-auto mb-2 transition-all duration-200 ${
                              snapshot.isDraggingOver || (isDragging && draggedItem?.type === "new-field")
                                ? "text-blue-500"
                                : "opacity-50"
                            }`} />
                            {isDragging && draggedItem?.type === "new-field" ? (
                              <>
                                <p className="text-sm font-medium">Drop field here</p>
                                <p className="text-xs">Release to add {draggedItem.label} to this group</p>
                              </>
                            ) : (
                              <>
                                <p className="text-sm">No fields in this group</p>
                                <p className="text-xs">Drag fields here to add them</p>
                              </>
                            )}
                          </div>
                        </>
                      ) : (
                        <div className="space-y-1">
                          {/* Drop zone at the beginning */}
                          <DropZoneIndicator groupId={group.id} position={0} />
                          
                          {group.fields.map((field, index) => (
                            <React.Fragment key={field.id}>
                              <Draggable
                                draggableId={field.id}
                                index={index}
                              >
                                {(provided, snapshot) => (
                                  <div
                                    ref={provided.innerRef}
                                    {...provided.draggableProps}
                                    className={`group flex items-center gap-3 p-3 bg-white rounded-lg border shadow-sm transition-all hover:shadow-md ${
                                      selectedField === field.id
                                        ? "ring-2 ring-blue-500 border-blue-200"
                                        : "border-gray-200"
                                    } ${snapshot.isDragging ? "rotate-2 shadow-lg z-50 ring-2 ring-blue-300" : ""}`}
                                    onClick={() => onFieldSelect(field.id)}
                                  >
                                    <div
                                      {...provided.dragHandleProps}
                                      className="cursor-grab text-gray-400 hover:text-gray-600 active:cursor-grabbing"
                                      onMouseDown={() => handleFieldDragStart(field.id, group.id)}
                                    >
                                      <GripVertical className="h-4 w-4" />
                                    </div>

                                    <div className="flex-1 min-w-0">
                                      <div className="flex items-center gap-2">
                                        <span className="font-medium truncate">
                                          {field.label}
                                        </span>
                                        <Badge
                                          variant={field.isSystem ? "secondary" : "outline"}
                                          className="text-xs"
                                        >
                                          {field.type}
                                        </Badge>
                                        {field.required && (
                                          <Badge variant="destructive" className="text-xs">
                                            Required
                                          </Badge>
                                        )}
                                      </div>
                                      <p className="text-xs text-muted-foreground truncate">
                                        ID: {field.id} | Order: {field.order_index}
                                      </p>
                                    </div>

                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        onToggleFieldVisibility(field.id);
                                      }}
                                      className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                                    >
                                      {field.visible ? (
                                        <Eye className="h-4 w-4 text-green-600" />
                                      ) : (
                                        <EyeOff className="h-4 w-4 text-gray-400" />
                                      )}
                                    </Button>
                                  </div>
                                )}
                              </Draggable>
                              
                              {/* Drop zone after each field */}
                              <DropZoneIndicator groupId={group.id} position={index + 1} />
                            </React.Fragment>
                          ))}
                        </div>
                      )}
                      
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </CardContent>
            )}
          </Card>
        ))}
      </div>
    </ScrollArea>
  );
}
