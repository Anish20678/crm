
import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Plus, X, Wand2 } from "lucide-react";
import { useAdvancedFieldCreation } from "@/hooks/useAdvancedFieldCreation";
import type { CustomFieldType } from "@/lib/types/customFields";

interface AdvancedFieldCreationDialogProps {
  isOpen: boolean;
  onClose: () => void;
  module: string;
  groupId: string;
  onFieldCreated?: (fieldId: string) => void;
}

const FIELD_TYPES: { value: CustomFieldType; label: string; description: string }[] = [
  { value: "text", label: "Text", description: "Single line text input" },
  { value: "textarea", label: "Textarea", description: "Multi-line text input" },
  { value: "number", label: "Number", description: "Numeric input with validation" },
  { value: "email", label: "Email", description: "Email address with validation" },
  { value: "phone", label: "Phone", description: "Phone number input" },
  { value: "url", label: "URL", description: "Website URL input" },
  { value: "date", label: "Date", description: "Date picker" },
  { value: "boolean", label: "Checkbox", description: "True/false checkbox" },
  { value: "select", label: "Dropdown", description: "Select from predefined options" },
  { value: "currency", label: "Currency", description: "Monetary value input" },
];

export function AdvancedFieldCreationDialog({
  isOpen,
  onClose,
  module,
  groupId,
  onFieldCreated,
}: AdvancedFieldCreationDialogProps) {
  const { createAdvancedField, isCreating } = useAdvancedFieldCreation(module);
  
  const [fieldType, setFieldType] = useState<CustomFieldType>("text");
  const [label, setLabel] = useState("");
  const [required, setRequired] = useState(false);
  const [placeholder, setPlaceholder] = useState("");
  const [description, setDescription] = useState("");
  const [defaultValue, setDefaultValue] = useState("");
  
  // Validation rules
  const [minLength, setMinLength] = useState("");
  const [maxLength, setMaxLength] = useState("");
  const [minValue, setMinValue] = useState("");
  const [maxValue, setMaxValue] = useState("");
  const [pattern, setPattern] = useState("");
  
  // Select options
  const [selectOptions, setSelectOptions] = useState<string[]>([""]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!label.trim()) return;

    const validationRules: any = {};
    
    if (minLength) validationRules.minLength = parseInt(minLength);
    if (maxLength) validationRules.maxLength = parseInt(maxLength);
    if (minValue) validationRules.min = parseFloat(minValue);
    if (maxValue) validationRules.max = parseFloat(maxValue);
    if (pattern) validationRules.pattern = pattern;

    const options = {
      label: label.trim(),
      required,
      placeholder: placeholder || undefined,
      description: description || undefined,
      defaultValue: defaultValue || undefined,
      validationRules: Object.keys(validationRules).length > 0 ? validationRules : undefined,
      selectOptions: fieldType === 'select' ? selectOptions.filter(opt => opt.trim()) : undefined,
    };

    const fieldId = await createAdvancedField(fieldType, groupId, options);
    
    if (fieldId) {
      onFieldCreated?.(fieldId);
      handleClose();
    }
  };

  const handleClose = () => {
    setFieldType("text");
    setLabel("");
    setRequired(false);
    setPlaceholder("");
    setDescription("");
    setDefaultValue("");
    setMinLength("");
    setMaxLength("");
    setMinValue("");
    setMaxValue("");
    setPattern("");
    setSelectOptions([""]);
    onClose();
  };

  const addSelectOption = () => {
    setSelectOptions([...selectOptions, ""]);
  };

  const updateSelectOption = (index: number, value: string) => {
    const newOptions = [...selectOptions];
    newOptions[index] = value;
    setSelectOptions(newOptions);
  };

  const removeSelectOption = (index: number) => {
    if (selectOptions.length > 1) {
      setSelectOptions(selectOptions.filter((_, i) => i !== index));
    }
  };

  const selectedFieldType = FIELD_TYPES.find(ft => ft.value === fieldType);

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wand2 className="h-5 w-5 text-purple-600" />
            Create Advanced Field
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Field Type Selection */}
          <div className="space-y-3">
            <Label>Field Type</Label>
            <Select value={fieldType} onValueChange={(value) => setFieldType(value as CustomFieldType)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {FIELD_TYPES.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    <div>
                      <div className="font-medium">{type.label}</div>
                      <div className="text-sm text-muted-foreground">{type.description}</div>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedFieldType && (
              <p className="text-sm text-muted-foreground">{selectedFieldType.description}</p>
            )}
          </div>

          <Separator />

          {/* Basic Properties */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="label">Field Label *</Label>
              <Input
                id="label"
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                placeholder="Enter field label"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="placeholder">Placeholder</Label>
              <Input
                id="placeholder"
                value={placeholder}
                onChange={(e) => setPlaceholder(e.target.value)}
                placeholder="Enter placeholder text"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Optional field description"
              rows={2}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="required"
              checked={required}
              onCheckedChange={setRequired}
            />
            <Label htmlFor="required">Required field</Label>
          </div>

          {/* Default Value */}
          {fieldType !== 'boolean' && (
            <div className="space-y-2">
              <Label htmlFor="defaultValue">Default Value</Label>
              <Input
                id="defaultValue"
                value={defaultValue}
                onChange={(e) => setDefaultValue(e.target.value)}
                placeholder="Optional default value"
                type={fieldType === 'number' || fieldType === 'currency' ? 'number' : 'text'}
              />
            </div>
          )}

          <Separator />

          {/* Field-specific configurations */}
          {(fieldType === 'text' || fieldType === 'textarea') && (
            <div className="space-y-4">
              <h4 className="font-medium">Text Validation</h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="minLength">Minimum Length</Label>
                  <Input
                    id="minLength"
                    type="number"
                    value={minLength}
                    onChange={(e) => setMinLength(e.target.value)}
                    placeholder="Min characters"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="maxLength">Maximum Length</Label>
                  <Input
                    id="maxLength"
                    type="number"
                    value={maxLength}
                    onChange={(e) => setMaxLength(e.target.value)}
                    placeholder="Max characters"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="pattern">Pattern (RegEx)</Label>
                <Input
                  id="pattern"
                  value={pattern}
                  onChange={(e) => setPattern(e.target.value)}
                  placeholder="^[A-Za-z0-9]+$"
                />
              </div>
            </div>
          )}

          {(fieldType === 'number' || fieldType === 'currency') && (
            <div className="space-y-4">
              <h4 className="font-medium">Number Validation</h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="minValue">Minimum Value</Label>
                  <Input
                    id="minValue"
                    type="number"
                    value={minValue}
                    onChange={(e) => setMinValue(e.target.value)}
                    placeholder="Minimum value"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="maxValue">Maximum Value</Label>
                  <Input
                    id="maxValue"
                    type="number"
                    value={maxValue}
                    onChange={(e) => setMaxValue(e.target.value)}
                    placeholder="Maximum value"
                  />
                </div>
              </div>
            </div>
          )}

          {fieldType === 'select' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">Dropdown Options</h4>
                <Button type="button" variant="outline" size="sm" onClick={addSelectOption}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Option
                </Button>
              </div>
              <div className="space-y-2">
                {selectOptions.map((option, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input
                      value={option}
                      onChange={(e) => updateSelectOption(index, e.target.value)}
                      placeholder={`Option ${index + 1}`}
                    />
                    {selectOptions.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeSelectOption(index)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <Separator />

          {/* Submit buttons */}
          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={isCreating || !label.trim()}>
              {isCreating ? "Creating..." : "Create Field"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
