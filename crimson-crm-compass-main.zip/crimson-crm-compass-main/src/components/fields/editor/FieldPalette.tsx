
import React from "react";
import { Draggable, Droppable } from "react-beautiful-dnd";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Search, Type, Calendar, CheckSquare, Hash, FileText, Mail, Phone, Globe, DollarSign, FolderOpen, Grip } from "lucide-react";
import { useFieldDragDrop } from "./DragDropContext";
import type { CustomFieldType } from "@/lib/types/customFields";

const FIELD_TYPES = [
  { type: "text", label: "Text", icon: Type, description: "Single line text input" },
  { type: "textarea", label: "Textarea", icon: FileText, description: "Multi-line text input" },
  { type: "email", label: "Email", icon: Mail, description: "Email address field" },
  { type: "phone", label: "Phone", icon: Phone, description: "Phone number field" },
  { type: "date", label: "Date", icon: Calendar, description: "Date picker field" },
  { type: "boolean", label: "Checkbox", icon: CheckSquare, description: "True/false checkbox" },
  { type: "number", label: "Number", icon: Hash, description: "Numeric input field" },
  { type: "select", label: "Select", icon: FolderOpen, description: "Dropdown selection" },
  { type: "url", label: "URL", icon: Globe, description: "Website URL field" },
  { type: "currency", label: "Currency", icon: DollarSign, description: "Monetary value field" }
] as const;

interface FieldPaletteProps {
  searchTerm: string;
  onSearchChange: (term: string) => void;
}

export function FieldPalette({ searchTerm, onSearchChange }: FieldPaletteProps) {
  const { setDraggedItem, setIsDragging } = useFieldDragDrop();

  const filteredFieldTypes = FIELD_TYPES.filter(fieldType =>
    fieldType.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
    fieldType.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search field types..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* Field Types List */}
      <div className="space-y-2">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-medium text-muted-foreground">Field Types</h3>
          <Badge variant="outline" className="text-xs">
            {filteredFieldTypes.length}
          </Badge>
        </div>

        {/* Virtual droppable for field palette */}
        <Droppable droppableId="field-palette" isDropDisabled={true}>
          {(provided) => (
            <div ref={provided.innerRef} {...provided.droppableProps}>
              {filteredFieldTypes.map((fieldType, index) => {
                const Icon = fieldType.icon;
                return (
                  <Draggable
                    key={`palette-${fieldType.type}`}
                    draggableId={`palette-${fieldType.type}`}
                    index={index}
                  >
                    {(provided, snapshot) => (
                      <Card
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        className={`cursor-grab hover:shadow-md transition-all border border-gray-200 hover:border-blue-300 bg-white hover:bg-blue-50 ${
                          snapshot.isDragging ? 'rotate-2 shadow-lg opacity-90' : ''
                        }`}
                        onDragStart={() => {
                          console.log("Starting drag for field type:", fieldType.type);
                          setDraggedItem({
                            id: `palette-${fieldType.type}`,
                            type: "new-field",
                            fieldType: fieldType.type as CustomFieldType,
                            label: `New ${fieldType.label} Field`
                          });
                          setIsDragging(true);
                        }}
                      >
                        <CardContent className="p-3 my-0 py-[13px]">
                          <div className="flex items-center gap-2">
                            <Grip className="h-4 w-4 text-gray-400" />
                            <Icon className="h-4 w-4 text-blue-600" />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium truncate">{fieldType.label}</p>
                              <p className="text-xs text-muted-foreground truncate">
                                Drag to add to a group
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </Draggable>
                );
              })}
              {provided.placeholder}
            </div>
          )}
        </Droppable>

        {filteredFieldTypes.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <Type className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p className="text-sm">No field types found</p>
            <p className="text-xs">Try adjusting your search</p>
          </div>
        )}
      </div>
    </div>
  );
}
