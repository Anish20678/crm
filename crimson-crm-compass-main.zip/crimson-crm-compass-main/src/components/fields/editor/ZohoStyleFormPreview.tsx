
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Calendar, CalendarDays, DollarSign, Eye, EyeOff } from "lucide-react";
import { cn } from "@/lib/utils";

interface FormField {
  id: string;
  label: string;
  type: string;
  required: boolean;
  visible: boolean;
  isSystem: boolean;
  group?: string;
  placeholder?: string;
  options?: string[];
}

interface FieldGroup {
  id: string;
  label: string;
  fields: FormField[];
  expanded: boolean;
}

interface ZohoStyleFormPreviewProps {
  fieldGroups: FieldGroup[];
  selectedField: string | null;
  onFieldSelect: (fieldId: string) => void;
}

export function ZohoStyleFormPreview({
  fieldGroups,
  selectedField,
  onFieldSelect,
}: ZohoStyleFormPreviewProps) {
  const renderFieldInput = (field: FormField) => {
    const isSelected = selectedField === field.id;
    const baseClasses = cn(
      "transition-all duration-200",
      isSelected && "ring-2 ring-blue-500 ring-offset-2"
    );

    switch (field.type) {
      case "textarea":
        return (
          <Textarea
            placeholder={field.placeholder || `Enter ${field.label.toLowerCase()}`}
            className={baseClasses}
            onClick={() => onFieldSelect(field.id)}
            readOnly
          />
        );
      
      case "boolean":
        return (
          <div className={cn("flex items-center space-x-2 p-2 rounded", baseClasses)}>
            <Checkbox 
              id={field.id}
              onClick={() => onFieldSelect(field.id)}
            />
            <label htmlFor={field.id} className="text-sm cursor-pointer">
              {field.label}
            </label>
          </div>
        );
      
      case "select":
        return (
          <Select onValueChange={() => onFieldSelect(field.id)}>
            <SelectTrigger className={baseClasses}>
              <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map((option, index) => (
                <SelectItem key={index} value={option}>
                  {option}
                </SelectItem>
              )) || (
                <SelectItem value="option1">Option 1</SelectItem>
              )}
            </SelectContent>
          </Select>
        );
      
      case "date":
        return (
          <div className="relative">
            <Input
              type="date"
              className={baseClasses}
              onClick={() => onFieldSelect(field.id)}
              readOnly
            />
            <CalendarDays className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          </div>
        );
      
      case "currency":
        return (
          <div className="relative">
            <Input
              type="number"
              placeholder="0.00"
              className={cn(baseClasses, "pl-8")}
              onClick={() => onFieldSelect(field.id)}
              readOnly
            />
            <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          </div>
        );
      
      case "email":
        return (
          <Input
            type="email"
            placeholder={field.placeholder || "example@email.com"}
            className={baseClasses}
            onClick={() => onFieldSelect(field.id)}
            readOnly
          />
        );
      
      case "phone":
        return (
          <Input
            type="tel"
            placeholder={field.placeholder || "+1 (555) 123-4567"}
            className={baseClasses}
            onClick={() => onFieldSelect(field.id)}
            readOnly
          />
        );
      
      case "url":
        return (
          <Input
            type="url"
            placeholder={field.placeholder || "https://example.com"}
            className={baseClasses}
            onClick={() => onFieldSelect(field.id)}
            readOnly
          />
        );
      
      case "number":
        return (
          <Input
            type="number"
            placeholder={field.placeholder || "Enter number"}
            className={baseClasses}
            onClick={() => onFieldSelect(field.id)}
            readOnly
          />
        );
      
      default:
        return (
          <Input
            type="text"
            placeholder={field.placeholder || `Enter ${field.label.toLowerCase()}`}
            className={baseClasses}
            onClick={() => onFieldSelect(field.id)}
            readOnly
          />
        );
    }
  };

  return (
    <div className="h-full overflow-auto bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-xl font-semibold">Form Preview</h2>
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              Live Preview
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            Click on any field below to configure it
          </p>
        </div>

        <Card className="shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg">Lead Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {fieldGroups.map((group) => (
              <div key={group.id} className="space-y-4">
                {group.expanded && (
                  <>
                    <div className="flex items-center gap-2 border-b pb-2">
                      <h3 className="font-medium text-gray-900 capitalize">
                        {group.label === 'ungrouped' ? 'Other Fields' : group.label}
                      </h3>
                      <Badge variant="secondary" className="text-xs">
                        {group.fields.filter(f => f.visible).length} field{group.fields.filter(f => f.visible).length !== 1 ? 's' : ''}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {group.fields
                        .filter(field => field.visible)
                        .map((field) => (
                          <div key={field.id} className="space-y-2">
                            <div className="flex items-center gap-2">
                              <label className="text-sm font-medium text-gray-700">
                                {field.label}
                                {field.required && (
                                  <span className="text-red-500 ml-1">*</span>
                                )}
                              </label>
                              <div className="flex items-center gap-1">
                                {field.isSystem && (
                                  <Badge variant="secondary" className="text-xs">
                                    System
                                  </Badge>
                                )}
                                {!field.visible ? (
                                  <EyeOff className="h-3 w-3 text-gray-400" />
                                ) : (
                                  <Eye className="h-3 w-3 text-green-600" />
                                )}
                              </div>
                            </div>
                            {renderFieldInput(field)}
                          </div>
                        ))}
                    </div>
                  </>
                )}
              </div>
            ))}

            {fieldGroups.every(group => group.fields.filter(f => f.visible).length === 0) && (
              <div className="text-center py-12 text-gray-500">
                <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <h3 className="font-medium mb-2">No visible fields</h3>
                <p className="text-sm">Add fields from the sidebar to see them here</p>
              </div>
            )}

            <div className="flex justify-end gap-3 pt-6 border-t">
              <Button variant="outline">Cancel</Button>
              <Button>Save Lead</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
