
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  ChevronDown, 
  ChevronRight, 
  Plus, 
  GripVertical, 
  Eye, 
  EyeOff, 
  Settings,
  Trash2
} from "lucide-react";
import { Droppable, Draggable } from "react-beautiful-dnd";
import { cn } from "@/lib/utils";

interface FieldItem {
  id: string;
  label: string;
  type: string;
  required: boolean;
  visible: boolean;
  isSystem: boolean;
}

interface FieldGroupSectionProps {
  groupId: string;
  groupName: string;
  fields: FieldItem[];
  isExpanded: boolean;
  isInColumn?: boolean;
  onToggleExpanded: () => void;
  onFieldSelect: (fieldId: string) => void;
  onToggleFieldVisibility: (fieldId: string) => void;
  onAddField: () => void;
  selectedField: string | null;
}

export function FieldGroupSection({
  groupId,
  groupName,
  fields,
  isExpanded,
  isInColumn = false,
  onToggleExpanded,
  onFieldSelect,
  onToggleFieldVisibility,
  onAddField,
  selectedField,
}: FieldGroupSectionProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(groupName);

  const handleSaveName = () => {
    // TODO: Implement save group name functionality
    console.log("Saving group name:", editedName);
    setIsEditing(false);
  };

  const handleDeleteGroup = () => {
    // TODO: Implement delete group functionality
    console.log("Deleting group:", groupId);
  };

  return (
    <Card className={cn("transition-all duration-200", isInColumn && "mb-4")}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggleExpanded}
              className="h-6 w-6"
            >
              {isExpanded ? (
                <ChevronDown className="h-4 w-4" />
              ) : (
                <ChevronRight className="h-4 w-4" />
              )}
            </Button>
            
            {isEditing ? (
              <div className="flex items-center gap-2">
                <Input
                  value={editedName}
                  onChange={(e) => setEditedName(e.target.value)}
                  className="h-7 text-sm"
                  onBlur={handleSaveName}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handleSaveName();
                    } else if (e.key === "Escape") {
                      setEditedName(groupName);
                      setIsEditing(false);
                    }
                  }}
                  autoFocus
                />
              </div>
            ) : (
              <CardTitle 
                className="text-base capitalize cursor-pointer hover:text-blue-600"
                onClick={() => setIsEditing(true)}
              >
                {groupName === 'ungrouped' ? 'Other Fields' : groupName}
              </CardTitle>
            )}
          </div>
          
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs">
              {fields.length} field{fields.length !== 1 ? 's' : ''}
            </Badge>
            <Button
              variant="ghost"
              size="icon"
              onClick={onAddField}
              className="h-6 w-6"
            >
              <Plus className="h-3 w-3" />
            </Button>
            {groupId !== 'basic' && groupId !== 'ungrouped' && (
              <Button
                variant="ghost"
                size="icon"
                onClick={handleDeleteGroup}
                className="h-6 w-6 text-red-600 hover:text-red-700"
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      
      {isExpanded && (
        <CardContent className="pt-0">
          <Droppable droppableId={groupId}>
            {(provided, snapshot) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                className={cn(
                  "space-y-2 min-h-[60px] p-2 rounded-lg transition-colors",
                  snapshot.isDraggingOver && "bg-blue-50 border-2 border-blue-200 border-dashed"
                )}
              >
                {fields.map((field, index) => (
                  <Draggable key={field.id} draggableId={field.id} index={index}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={cn(
                          "p-3 bg-white border rounded-lg transition-all cursor-pointer hover:shadow-sm",
                          snapshot.isDragging && "shadow-lg rotate-1 z-50",
                          selectedField === field.id && "border-blue-500 bg-blue-50",
                          !field.visible && "opacity-50"
                        )}
                        onClick={() => onFieldSelect(field.id)}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            {...provided.dragHandleProps}
                            className="text-gray-400 hover:text-gray-600 cursor-grab active:cursor-grabbing"
                          >
                            <GripVertical className="h-4 w-4" />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="font-medium truncate text-sm">{field.label}</p>
                              <div className="flex gap-1">
                                {field.isSystem && (
                                  <Badge variant="secondary" className="text-xs">
                                    System
                                  </Badge>
                                )}
                                {field.required && (
                                  <Badge variant="destructive" className="text-xs">
                                    Required
                                  </Badge>
                                )}
                              </div>
                            </div>
                            <p className="text-xs text-gray-500 capitalize">
                              {field.type} field
                            </p>
                          </div>
                          
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={(e) => {
                                e.stopPropagation();
                                onToggleFieldVisibility(field.id);
                              }}
                              className="h-7 w-7"
                            >
                              {field.visible ? (
                                <Eye className="h-3 w-3" />
                              ) : (
                                <EyeOff className="h-3 w-3" />
                              )}
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={(e) => {
                                e.stopPropagation();
                                onFieldSelect(field.id);
                              }}
                              className="h-7 w-7"
                            >
                              <Settings className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
                
                {fields.length === 0 && (
                  <div className="text-center py-6 text-gray-500">
                    <Plus className="h-6 w-6 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No fields in this group</p>
                    <p className="text-xs">Drag fields here or click + to add</p>
                  </div>
                )}
              </div>
            )}
          </Droppable>
        </CardContent>
      )}
    </Card>
  );
}
