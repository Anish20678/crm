
import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { FolderPlus, Layout, Sparkles, Users, Building, Target, Calendar } from "lucide-react";
import { useFlexibleGroupManagement } from "@/hooks/useFlexibleGroupManagement";

interface GroupTemplateSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  module: string;
  onGroupCreated?: (groupId: string) => void;
}

const TEMPLATE_ICONS = {
  contact_info: Users,
  business_profile: Building,
  lead_qualification: Target,
  personal_info: Users,
  professional_info: Building,
  communication_prefs: Users,
  deal_basics: Target,
  project_details: Building,
  financial_terms: Target,
  timeline_milestones: Calendar,
  task_details: Calendar,
  assignment_tracking: Users,
  relationships: Building,
};

export function GroupTemplateSelector({
  isOpen,
  onClose,
  module,
  onGroupCreated,
}: GroupTemplateSelectorProps) {
  const { createGroupFromTemplate, getAvailableTemplates, isCreating } = useFlexibleGroupManagement(module);
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);

  const templates = getAvailableTemplates();

  const handleCreateFromTemplate = async (templateId: string) => {
    const result = await createGroupFromTemplate(templateId);
    if (result) {
      onGroupCreated?.(result);
      onClose();
    }
  };

  const getTemplateIcon = (templateId: string) => {
    const IconComponent = TEMPLATE_ICONS[templateId as keyof typeof TEMPLATE_ICONS] || FolderPlus;
    return IconComponent;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Layout className="h-5 w-5 text-blue-600" />
            Choose Group Template
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <p className="text-muted-foreground">
            Select a pre-built group template to quickly organize your {module} fields, or create a custom group.
          </p>

          <Separator />

          {templates.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {templates.map((template) => {
                const IconComponent = getTemplateIcon(template.id);
                return (
                  <Card 
                    key={template.id} 
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      selectedTemplate === template.id ? 'ring-2 ring-blue-500 border-blue-200' : ''
                    }`}
                    onClick={() => setSelectedTemplate(template.id)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-blue-50 rounded-lg">
                          <IconComponent className="h-5 w-5 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <CardTitle className="text-base">{template.label}</CardTitle>
                          {template.description && (
                            <CardDescription className="text-sm mt-1">
                              {template.description}
                            </CardDescription>
                          )}
                        </div>
                      </div>
                    </CardHeader>

                    {template.fields && template.fields.length > 0 && (
                      <CardContent className="pt-0">
                        <div className="space-y-2">
                          <div className="text-sm font-medium text-muted-foreground">
                            Suggested Fields:
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {template.fields.slice(0, 4).map((field, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {field.label}
                                {field.required && <span className="text-red-500 ml-1">*</span>}
                              </Badge>
                            ))}
                            {template.fields.length > 4 && (
                              <Badge variant="outline" className="text-xs">
                                +{template.fields.length - 4} more
                              </Badge>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    )}

                    <div className="p-4 pt-0">
                      <Button
                        size="sm"
                        className="w-full"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCreateFromTemplate(template.id);
                        }}
                        disabled={isCreating}
                      >
                        {isCreating ? "Creating..." : "Create Group"}
                      </Button>
                    </div>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card className="p-8 text-center">
              <div className="flex flex-col items-center gap-4">
                <div className="p-4 bg-gray-50 rounded-full">
                  <Sparkles className="h-8 w-8 text-gray-400" />
                </div>
                <div>
                  <h3 className="text-lg font-medium">No Templates Available</h3>
                  <p className="text-muted-foreground mt-1">
                    No pre-built templates are available for the {module} module.
                  </p>
                </div>
              </div>
            </Card>
          )}

          <Separator />

          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
