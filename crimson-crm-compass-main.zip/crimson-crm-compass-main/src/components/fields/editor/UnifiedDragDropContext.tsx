
import React, { createContext, useContext, useState, useCallback } from "react";
import { DragDropContext, DropResult } from "react-beautiful-dnd";
import { useToast } from "@/hooks/use-toast";
import { useEnhancedFieldCreation } from "@/hooks/useEnhancedFieldCreation";
import type { CustomFieldType } from "@/lib/types/customFields";

interface DraggedField {
  id: string;
  type: "existing" | "new";
  fieldType?: CustomFieldType;
  label?: string;
}

interface UnifiedDragDropContextType {
  draggedField: DraggedField | null;
  setDraggedField: (field: DraggedField | null) => void;
  isDragging: boolean;
  setIsDragging: (dragging: boolean) => void;
  handleDrop: (result: DropResult, onFieldCreated?: (fieldId: string) => void) => Promise<void>;
}

const UnifiedDragDropContext = createContext<UnifiedDragDropContextType | null>(null);

export function useUnifiedDragDrop() {
  const context = useContext(UnifiedDragDropContext);
  if (!context) {
    throw new Error("useUnifiedDragDrop must be used within UnifiedDragDropProvider");
  }
  return context;
}

interface UnifiedDragDropProviderProps {
  children: React.ReactNode;
  module: string;
  onFieldReorder: (result: DropResult) => void;
  onFieldSelect?: (fieldId: string) => void;
}

export function UnifiedDragDropProvider({
  children,
  module,
  onFieldReorder,
  onFieldSelect,
}: UnifiedDragDropProviderProps) {
  const [draggedField, setDraggedField] = useState<DraggedField | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const { toast } = useToast();
  const { createFieldWithType, isCreating } = useEnhancedFieldCreation(module);

  const handleDrop = useCallback(async (result: DropResult, onFieldCreated?: (fieldId: string) => void) => {
    if (!result.destination) {
      setDraggedField(null);
      setIsDragging(false);
      return;
    }

    const { source, destination, draggableId } = result;

    // Handle new field creation from palette
    if (draggedField?.type === "new" && draggedField.fieldType) {
      try {
        console.log("Creating new field:", draggedField.fieldType, "in group:", destination.droppableId);
        
        const fieldId = await createFieldWithType(
          draggedField.fieldType,
          destination.droppableId,
          {
            label: draggedField.label,
            required: false,
          }
        );

        if (fieldId && onFieldCreated) {
          onFieldCreated(fieldId);
        }

        toast({
          title: "Field added successfully",
          description: `${draggedField.label || draggedField.fieldType} field has been added to the group.`,
        });
      } catch (error) {
        console.error("Failed to create field:", error);
        toast({
          title: "Error",
          description: "Failed to add field. Please try again.",
          variant: "destructive",
        });
      }
    } else {
      // Handle existing field reordering
      onFieldReorder(result);
    }

    setDraggedField(null);
    setIsDragging(false);
  }, [draggedField, createFieldWithType, onFieldReorder, toast]);

  const contextValue: UnifiedDragDropContextType = {
    draggedField,
    setDraggedField,
    isDragging,
    setIsDragging,
    handleDrop,
  };

  return (
    <UnifiedDragDropContext.Provider value={contextValue}>
      <DragDropContext onDragEnd={handleDrop}>
        {children}
      </DragDropContext>
    </UnifiedDragDropContext.Provider>
  );
}
