
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { PanelLeftClose, PanelLeftOpen, ArrowLeft, Type, Layers } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { GroupCreationWidget } from "./GroupCreationWidget";
import { FieldPalette } from "./FieldPalette";

interface FieldEditorSidebarProps {
  module: string;
  collapsed: boolean;
  onToggleCollapse: () => void;
  selectedField: string | null;
  onFieldSelect: (fieldId: string) => void;
  onCreateGroup?: (group: {
    id: string;
    label: string;
    description?: string;
    defaultExpanded: boolean;
  }) => void;
}

export function FieldEditorSidebar({
  module,
  collapsed,
  onToggleCollapse,
  selectedField,
  onFieldSelect,
  onCreateGroup
}: FieldEditorSidebarProps) {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [showGroupCreation, setShowGroupCreation] = useState(false);

  const handleCreateGroup = (group: {
    id: string;
    label: string;
    description?: string;
    defaultExpanded: boolean;
  }) => {
    if (onCreateGroup) {
      onCreateGroup(group);
    }
    console.log("Creating group:", group);
  };

  if (collapsed) {
    return (
      <div className="w-16 bg-white border-r flex flex-col">
        <div className="p-4">
          <Button variant="ghost" size="icon" onClick={onToggleCollapse} className="w-8 h-8">
            <PanelLeftOpen className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex-1 flex flex-col items-center py-4 space-y-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/module-editor")}
            className="w-8 h-8"
            title="Back to Module Editor"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="w-8 h-8" title="Field Types">
            <Type className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="w-8 h-8" title="New Section">
            <Layers className="h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-80 bg-white border-r flex flex-col">
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold">Field Toolkit</h2>
          <Button variant="ghost" size="icon" onClick={onToggleCollapse} className="w-8 h-8">
            <PanelLeftClose className="h-4 w-4" />
          </Button>
        </div>
        
        <Button
          variant="outline"
          size="sm"
          onClick={() => navigate("/module-editor")}
          className="w-full mb-3"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Module Editor
        </Button>
      </div>

      {/* New Section Button */}
      <div className="p-4 border-b bg-gradient-to-r from-blue-50 to-indigo-50">
        <Button
          onClick={() => setShowGroupCreation(true)}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white shadow-sm"
          size="sm"
        >
          <Layers className="h-4 w-4 mr-2" />
          NEW SECTION
        </Button>
      </div>

      {/* Group Creation Widget */}
      <GroupCreationWidget
        isOpen={showGroupCreation}
        onClose={() => setShowGroupCreation(false)}
        onCreateGroup={handleCreateGroup}
      />

      {/* Field Palette */}
      <ScrollArea className="flex-1">
        <div className="p-4">
          <FieldPalette
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
          />
        </div>
      </ScrollArea>
    </div>
  );
}
