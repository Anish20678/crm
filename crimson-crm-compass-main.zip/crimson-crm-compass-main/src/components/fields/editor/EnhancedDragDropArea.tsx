import React, { useState } from "react";
import { Droppable, Draggable } from "react-beautiful-dnd";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  ChevronDown,
  ChevronRight,
  Eye,
  EyeOff,
  GripVertical,
  Settings,
  Trash2,
  Edit3,
  Check,
  X,
  Plus,
  FolderPlus,
} from "lucide-react";
import { EnhancedFieldCreationWidget } from "./EnhancedFieldCreationWidget";
import { GroupCreationWidget } from "./GroupCreationWidget";
import { useUnifiedDragDrop } from "./UnifiedDragDropContext";

interface FieldItem {
  id: string;
  label: string;
  type: string;
  required: boolean;
  visible: boolean;
  isSystem: boolean;
  group?: string;
  order_index: number;
}

interface FieldGroup {
  id: string;
  label: string;
  fields: FieldItem[];
  expanded: boolean;
  canDelete: boolean;
  isSystem?: boolean;
}

interface EnhancedDragDropAreaProps {
  fieldGroups: FieldGroup[];
  selectedField: string | null;
  onFieldSelect: (fieldId: string) => void;
  onToggleFieldVisibility: (fieldId: string) => void;
  onToggleGroupExpanded: (groupId: string) => void;
  onEditGroupName: (groupId: string, newName: string) => void;
  onDeleteGroup: (groupId: string) => void;
  onAddFieldToGroup: (groupId: string) => void;
  onCreateGroup: (group: any) => void;
  module: string;
}

export function EnhancedDragDropArea({
  fieldGroups,
  selectedField,
  onFieldSelect,
  onToggleFieldVisibility,
  onToggleGroupExpanded,
  onEditGroupName,
  onDeleteGroup,
  onAddFieldToGroup,
  onCreateGroup,
  module,
}: EnhancedDragDropAreaProps) {
  const [editingGroup, setEditingGroup] = useState<string | null>(null);
  const [editingName, setEditingName] = useState("");
  const [showGroupCreator, setShowGroupCreator] = useState(false);
  const [expandedCreationWidgets, setExpandedCreationWidgets] = useState<Record<string, boolean>>({});
  
  const { isDragging, draggedField } = useUnifiedDragDrop();

  const handleStartEdit = (groupId: string, currentName: string) => {
    setEditingGroup(groupId);
    setEditingName(currentName);
  };

  const handleSaveEdit = () => {
    if (editingGroup && editingName.trim()) {
      onEditGroupName(editingGroup, editingName.trim());
    }
    setEditingGroup(null);
    setEditingName("");
  };

  const handleCancelEdit = () => {
    setEditingGroup(null);
    setEditingName("");
  };

  const toggleCreationWidget = (groupId: string) => {
    setExpandedCreationWidgets(prev => ({
      ...prev,
      [groupId]: !prev[groupId],
    }));
  };

  const handleFieldCreated = (fieldId: string) => {
    setExpandedCreationWidgets({});
    onFieldSelect(fieldId);
  };

  return (
    <ScrollArea className="h-full">
      <div className="p-6 space-y-4">
        {/* Header with group creation */}
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Field Groups</h3>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowGroupCreator(!showGroupCreator)}
          >
            <FolderPlus className="h-4 w-4 mr-2" />
            New Group
          </Button>
        </div>

        {/* Group Creation Widget */}
        <GroupCreationWidget
          isOpen={showGroupCreator}
          onClose={() => setShowGroupCreator(false)}
          onCreateGroup={(group) => {
            onCreateGroup(group);
            setShowGroupCreator(false);
          }}
        />

        {/* Field Groups */}
        {fieldGroups.map((group) => (
          <Card key={group.id} className="border-2 border-dashed border-gray-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onToggleGroupExpanded(group.id)}
                    className="p-1 h-6 w-6"
                  >
                    {group.expanded ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                  </Button>

                  {editingGroup === group.id ? (
                    <div className="flex items-center gap-2">
                      <Input
                        value={editingName}
                        onChange={(e) => setEditingName(e.target.value)}
                        className="h-8 text-sm"
                        onKeyDown={(e) => {
                          if (e.key === "Enter") handleSaveEdit();
                          if (e.key === "Escape") handleCancelEdit();
                        }}
                        autoFocus
                      />
                      <Button size="sm" variant="ghost" onClick={handleSaveEdit}>
                        <Check className="h-3 w-3" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={handleCancelEdit}>
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <h4 className="font-medium">{group.label}</h4>
                      {group.isSystem && (
                        <Badge variant="secondary" className="text-xs">
                          System
                        </Badge>
                      )}
                    </>
                  )}
                </div>

                <div className="flex items-center gap-1">
                  <Badge variant="outline" className="text-xs">
                    {group.fields.length} fields
                  </Badge>
                  
                  {editingGroup !== group.id && (
                    <>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleStartEdit(group.id, group.label)}
                        className="h-7 w-7 p-0"
                      >
                        <Edit3 className="h-3 w-3" />
                      </Button>
                      
                      {group.canDelete && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onDeleteGroup(group.id)}
                          className="h-7 w-7 p-0 text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      )}
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleCreationWidget(group.id)}
                        className="h-7 w-7 p-0"
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </CardHeader>

            {group.expanded && (
              <CardContent className="pt-0">
                {/* Field Creation Widget */}
                {expandedCreationWidgets[group.id] && (
                  <div className="mb-4">
                    <EnhancedFieldCreationWidget
                      module={module}
                      groupId={group.id}
                      onFieldCreated={handleFieldCreated}
                    />
                  </div>
                )}

                {/* Enhanced Droppable area for fields */}
                <Droppable droppableId={group.id}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className={`min-h-[100px] rounded-lg border-2 border-dashed p-3 transition-all duration-200 ${
                        snapshot.isDraggingOver || (isDragging && draggedField?.type === "new")
                          ? "border-blue-400 bg-blue-50 ring-2 ring-blue-200"
                          : "border-gray-200 bg-gray-50/50"
                      }`}
                    >
                      {/* Enhanced empty state with drop zone indicator */}
                      {group.fields.length === 0 ? (
                        <div className={`text-center py-8 transition-all duration-200 ${
                          snapshot.isDraggingOver || (isDragging && draggedField?.type === "new")
                            ? "text-blue-600"
                            : "text-muted-foreground"
                        }`}>
                          <Settings className={`h-8 w-8 mx-auto mb-2 transition-all duration-200 ${
                            snapshot.isDraggingOver || (isDragging && draggedField?.type === "new")
                              ? "text-blue-500"
                              : "opacity-50"
                          }`} />
                          {isDragging && draggedField?.type === "new" ? (
                            <>
                              <p className="text-sm font-medium">Drop field here</p>
                              <p className="text-xs">Release to add {draggedField.label} to this group</p>
                            </>
                          ) : (
                            <>
                              <p className="text-sm">No fields in this group</p>
                              <p className="text-xs">Drag fields here or use the + button to add fields</p>
                            </>
                          )}
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {group.fields.map((field, index) => (
                            <Draggable
                              key={field.id}
                              draggableId={field.id}
                              index={index}
                            >
                              {(provided, snapshot) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  className={`group flex items-center gap-3 p-3 bg-white rounded-lg border shadow-sm transition-all hover:shadow-md ${
                                    selectedField === field.id
                                      ? "ring-2 ring-blue-500 border-blue-200"
                                      : "border-gray-200"
                                  } ${snapshot.isDragging ? "rotate-2 shadow-lg z-50" : ""}`}
                                  onClick={() => onFieldSelect(field.id)}
                                >
                                  <div
                                    {...provided.dragHandleProps}
                                    className="cursor-grab text-gray-400 hover:text-gray-600"
                                  >
                                    <GripVertical className="h-4 w-4" />
                                  </div>

                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2">
                                      <span className="font-medium truncate">
                                        {field.label}
                                      </span>
                                      <Badge
                                        variant={field.isSystem ? "secondary" : "outline"}
                                        className="text-xs"
                                      >
                                        {field.type}
                                      </Badge>
                                      {field.required && (
                                        <Badge variant="destructive" className="text-xs">
                                          Required
                                        </Badge>
                                      )}
                                    </div>
                                    <p className="text-xs text-muted-foreground truncate">
                                      ID: {field.id}
                                    </p>
                                  </div>

                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onToggleFieldVisibility(field.id);
                                    }}
                                    className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                                  >
                                    {field.visible ? (
                                      <Eye className="h-4 w-4 text-green-600" />
                                    ) : (
                                      <EyeOff className="h-4 w-4 text-gray-400" />
                                    )}
                                  </Button>
                                </div>
                              )}
                            </Draggable>
                          ))}
                        </div>
                      )}
                      
                      {/* Drop indicator for new fields */}
                      {isDragging && draggedField?.type === "new" && snapshot.isDraggingOver && (
                        <div className="border-2 border-dashed border-blue-400 bg-blue-50 rounded-lg p-4 mt-2 text-center text-blue-600">
                          <p className="text-sm font-medium">Add {draggedField.label} here</p>
                        </div>
                      )}
                      
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </CardContent>
            )}
          </Card>
        ))}
      </div>
    </ScrollArea>
  );
}
