
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  X, 
  Save, 
  Trash2, 
  Settings, 
  Type, 
  FileText, 
  Mail, 
  Phone, 
  Calendar, 
  CheckSquare, 
  Hash,
  FolderOpen,
  Eye,
  EyeOff,
  Percent
} from "lucide-react";
import { useCustomFieldsData } from "@/hooks/useCustomFieldsData";
import { useCustomFieldsMutations } from "@/hooks/useCustomFieldsMutations";
import { useSystemFieldDisplay } from "@/hooks/useSystemFieldDisplay";
import { useSystemFieldConfigs } from "@/hooks/useSystemFieldConfigs";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import type { CustomFieldType } from "@/lib/types/customFields";

interface FieldConfigurationPanelProps {
  module: string;
  fieldId: string;
  onClose: () => void;
}

const FIELD_TYPE_ICONS = {
  text: Type,
  textarea: FileText,
  email: Mail,
  phone: Phone,
  date: Calendar,
  boolean: CheckSquare,
  number: Hash,
  select: FolderOpen,
};

const FIELD_TYPES = [
  { value: "text", label: "Text", icon: Type },
  { value: "textarea", label: "Textarea", icon: FileText },
  { value: "email", label: "Email", icon: Mail },
  { value: "phone", label: "Phone", icon: Phone },
  { value: "date", label: "Date", icon: Calendar },
  { value: "boolean", label: "Boolean", icon: CheckSquare },
  { value: "number", label: "Number", icon: Hash },
  { value: "select", label: "Select", icon: FolderOpen },
];

export function FieldConfigurationPanel({
  module,
  fieldId,
  onClose,
}: FieldConfigurationPanelProps) {
  const { customFields, refetch: refetchCustomFields } = useCustomFieldsData(module);
  const { visibleFields } = useSystemFieldDisplay(module);
  const { upsertField, deleteField } = useCustomFieldsMutations(module);
  const { upsertConfig, systemFieldConfigs } = useSystemFieldConfigs(module);
  const { toast } = useToast();
  
  // Find the field (either system or custom)
  const systemField = visibleFields.find(f => f.fieldName === fieldId);
  const customField = customFields.find(f => f.id === fieldId);
  const field = systemField || customField;
  const isSystemField = !!systemField;
  
  // Get existing system field config if it exists
  const existingSystemConfig = systemFieldConfigs.find(config => config.field_name === fieldId);
  
  // Local state for field configuration
  const [label, setLabel] = useState(field?.label || "");
  const [required, setRequired] = useState(
    isSystemField 
      ? (existingSystemConfig?.is_required ?? field?.required ?? false)
      : (field?.required || false)
  );
  const [visible, setVisible] = useState(
    isSystemField 
      ? (existingSystemConfig?.is_visible ?? field?.visible ?? true)
      : (field?.visible ?? true)
  );
  const [fieldType, setFieldType] = useState<CustomFieldType>(
    isSystemField ? (systemField.type as CustomFieldType) : (customField?.field_type as CustomFieldType) || "text"
  );
  const [description, setDescription] = useState(
    customField?.description || ""
  );
  const [placeholder, setPlaceholder] = useState(
    customField?.placeholder || ""
  );
  const [defaultValue, setDefaultValue] = useState(
    customField?.default_value || ""
  );
  const [selectOptions, setSelectOptions] = useState(
    customField?.select_options?.join("\n") || ""
  );
  const [widthPercentage, setWidthPercentage] = useState(
    isSystemField 
      ? (existingSystemConfig?.width_percentage ?? 100)
      : 100
  );

  if (!field) {
    return (
      <div className="p-6 text-center">
        <p className="text-muted-foreground">Field not found</p>
      </div>
    );
  }

  const IconComponent = FIELD_TYPE_ICONS[fieldType as keyof typeof FIELD_TYPE_ICONS] || Type;

  const handleSave = async () => {
    try {
      if (isSystemField) {
        // Save system field configuration with all properties
        await upsertConfig({
          module,
          field_name: fieldId,
          is_visible: visible,
          is_required: required,
          width_percentage: widthPercentage,
          field_order: existingSystemConfig?.field_order || 0,
          field_group: existingSystemConfig?.field_group || 'basic',
          group_order: existingSystemConfig?.group_order || 0,
        });
        
        toast({
          title: "System Field Updated",
          description: `${label} configuration has been saved.`,
        });
      } else {
        // Save custom field
        const fieldData = {
          id: fieldId,
          module,
          name: customField?.name || fieldId,
          label,
          field_type: fieldType,
          required,
          visible,
          order_index: customField?.order_index || 0,
          options: fieldType === 'select' ? selectOptions.split("\n").filter(Boolean) : undefined,
          description,
          placeholder,
          default_value: defaultValue,
          select_options: fieldType === 'select' ? selectOptions.split("\n").filter(Boolean) : undefined,
        };

        await upsertField(fieldData);
        
        // Refresh custom fields data
        setTimeout(() => {
          refetchCustomFields();
        }, 500);
        
        toast({
          title: "Custom Field Updated",
          description: `${label} has been saved successfully.`,
        });
      }
      
      onClose();
    } catch (error) {
      console.error("Failed to save field:", error);
      toast({
        title: "Error",
        description: "Failed to save field configuration. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async () => {
    if (isSystemField) {
      toast({
        title: "Cannot Delete",
        description: "System fields cannot be deleted.",
        variant: "destructive",
      });
      return;
    }

    if (window.confirm(`Are you sure you want to delete the field "${label}"? This action cannot be undone.`)) {
      try {
        await deleteField(fieldId);
        
        toast({
          title: "Field Deleted",
          description: `${label} has been deleted successfully.`,
        });
        
        onClose();
      } catch (error) {
        console.error("Failed to delete field:", error);
        toast({
          title: "Error",
          description: "Failed to delete field. Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <IconComponent className="h-5 w-5 text-blue-600" />
            <h3 className="font-semibold">Field Configuration</h3>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="flex items-center gap-2 mt-2">
          {isSystemField ? (
            <Badge variant="secondary">System Field</Badge>
          ) : (
            <Badge variant="outline">Custom Field</Badge>
          )}
          {!visible && (
            <Badge variant="secondary" className="text-xs">
              <EyeOff className="h-3 w-3 mr-1" />
              Hidden
            </Badge>
          )}
        </div>
      </div>

      {/* Configuration Form */}
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="label">Label</Label>
                <Input
                  id="label"
                  value={label}
                  onChange={(e) => setLabel(e.target.value)}
                  placeholder="Enter field label"
                />
              </div>

              {!isSystemField && (
                <div className="space-y-2">
                  <Label htmlFor="type">Field Type</Label>
                  <Select value={fieldType} onValueChange={(value) => setFieldType(value as CustomFieldType)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {FIELD_TYPES.map((type) => {
                        const Icon = type.icon;
                        return (
                          <SelectItem key={type.value} value={type.value}>
                            <div className="flex items-center gap-2">
                              <Icon className="h-4 w-4" />
                              {type.label}
                            </div>
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {!isSystemField && (
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Enter field description (optional)"
                    rows={2}
                  />
                </div>
              )}
            </CardContent>
          </Card>

          {/* Field Settings */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Field Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Visible</Label>
                  <p className="text-xs text-muted-foreground">
                    Show this field in forms and lists
                  </p>
                </div>
                <Switch
                  checked={visible}
                  onCheckedChange={setVisible}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Required</Label>
                  <p className="text-xs text-muted-foreground">
                    Make this field mandatory
                  </p>
                </div>
                <Switch
                  checked={required}
                  onCheckedChange={setRequired}
                />
              </div>

              {isSystemField && (
                <div className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Percent className="h-4 w-4 text-muted-foreground" />
                      <Label>Field Width: {widthPercentage}%</Label>
                    </div>
                    <Slider
                      value={[widthPercentage]}
                      onValueChange={(value) => setWidthPercentage(value[0])}
                      max={100}
                      min={25}
                      step={5}
                      className="w-full"
                    />
                    <p className="text-xs text-muted-foreground">
                      Adjust how much horizontal space this field takes up
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Advanced Settings */}
          {!isSystemField && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Advanced Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="placeholder">Placeholder</Label>
                  <Input
                    id="placeholder"
                    value={placeholder}
                    onChange={(e) => setPlaceholder(e.target.value)}
                    placeholder="Enter placeholder text"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="defaultValue">Default Value</Label>
                  <Input
                    id="defaultValue"
                    value={defaultValue}
                    onChange={(e) => setDefaultValue(e.target.value)}
                    placeholder="Enter default value"
                  />
                </div>

                {fieldType === "select" && (
                  <div className="space-y-2">
                    <Label htmlFor="options">Select Options</Label>
                    <Textarea
                      id="options"
                      value={selectOptions}
                      onChange={(e) => setSelectOptions(e.target.value)}
                      placeholder="Enter options (one per line)"
                      rows={4}
                    />
                    <p className="text-xs text-muted-foreground">
                      Enter each option on a new line
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Field Preview */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="p-4 border rounded-lg bg-muted/50">
                <Label className="text-sm font-medium">
                  {label || "Field Label"}
                  {required && <span className="text-red-500 ml-1">*</span>}
                </Label>
                {fieldType === "textarea" ? (
                  <Textarea
                    placeholder={placeholder || "Enter text..."}
                    className="mt-1"
                    disabled
                  />
                ) : fieldType === "select" ? (
                  <Select disabled>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder={placeholder || "Select option..."} />
                    </SelectTrigger>
                  </Select>
                ) : fieldType === "boolean" ? (
                  <div className="flex items-center space-x-2 mt-2">
                    <Switch disabled />
                    <Label className="text-sm text-muted-foreground">
                      {placeholder || "Toggle option"}
                    </Label>
                  </div>
                ) : (
                  <Input
                    type={fieldType === "email" ? "email" : fieldType === "number" ? "number" : "text"}
                    placeholder={placeholder || "Enter value..."}
                    className="mt-1"
                    disabled
                    style={{ width: `${widthPercentage}%` }}
                  />
                )}
                {description && (
                  <p className="text-xs text-muted-foreground mt-1">
                    {description}
                  </p>
                )}
                {isSystemField && (
                  <p className="text-xs text-blue-600 mt-1">
                    Field width: {widthPercentage}%
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </ScrollArea>

      {/* Footer Actions */}
      <div className="p-4 border-t">
        <div className="flex gap-2">
          <Button onClick={handleSave} className="flex-1">
            <Save className="h-4 w-4 mr-2" />
            Save Changes
          </Button>
          {!isSystemField && (
            <Button 
              variant="destructive" 
              size="icon"
              onClick={handleDelete}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
