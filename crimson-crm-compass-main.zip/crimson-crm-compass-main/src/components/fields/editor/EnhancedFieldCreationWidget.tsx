
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, 
  Type, 
  Hash, 
  Mail, 
  Phone, 
  Calendar, 
  ToggleLeft, 
  List, 
  FileText,
  Sparkles
} from "lucide-react";
import { useEnhancedFieldCreation } from "@/hooks/useEnhancedFieldCreation";
import type { CustomFieldType } from "@/lib/types/customFields";

interface EnhancedFieldCreationWidgetProps {
  module: string;
  groupId: string;
  onFieldCreated?: (fieldId: string) => void;
}

const FIELD_TYPES: Array<{
  type: CustomFieldType;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
  color: string;
}> = [
  { type: "text", label: "Text", icon: Type, description: "Single line text input", color: "blue" },
  { type: "number", label: "Number", icon: Hash, description: "Numeric input field", color: "green" },
  { type: "email", label: "Email", icon: Mail, description: "Email address field", color: "purple" },
  { type: "phone", label: "Phone", icon: Phone, description: "Phone number field", color: "orange" },
  { type: "date", label: "Date", icon: Calendar, description: "Date picker field", color: "red" },
  { type: "boolean", label: "Checkbox", icon: ToggleLeft, description: "True/false checkbox", color: "indigo" },
  { type: "select", label: "Dropdown", icon: List, description: "Multiple choice dropdown", color: "pink" },
  { type: "textarea", label: "Text Area", icon: FileText, description: "Multi-line text input", color: "teal" },
];

export function EnhancedFieldCreationWidget({ 
  module, 
  groupId, 
  onFieldCreated 
}: EnhancedFieldCreationWidgetProps) {
  const [showCustomForm, setShowCustomForm] = useState(false);
  const [fieldLabel, setFieldLabel] = useState("");
  const [fieldDescription, setFieldDescription] = useState("");
  const [selectedType, setSelectedType] = useState<CustomFieldType>("text");
  
  const { createFieldWithType, isCreating } = useEnhancedFieldCreation(module);

  const handleQuickCreate = async (fieldType: CustomFieldType) => {
    const fieldId = await createFieldWithType(fieldType, groupId);
    if (fieldId && onFieldCreated) {
      onFieldCreated(fieldId);
    }
  };

  const handleCustomCreate = async () => {
    if (!fieldLabel.trim()) return;
    
    const fieldId = await createFieldWithType(selectedType, groupId, {
      label: fieldLabel,
      description: fieldDescription || undefined,
    });
    
    if (fieldId) {
      setFieldLabel("");
      setFieldDescription("");
      setShowCustomForm(false);
      if (onFieldCreated) {
        onFieldCreated(fieldId);
      }
    }
  };

  if (showCustomForm) {
    return (
      <Card className="border-dashed border-2 border-blue-200 bg-blue-50/50">
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-blue-600" />
            Create Custom Field
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="field-label">Field Label</Label>
            <Input
              id="field-label"
              value={fieldLabel}
              onChange={(e) => setFieldLabel(e.target.value)}
              placeholder="Enter field label..."
              className="mt-1"
            />
          </div>
          
          <div>
            <Label htmlFor="field-description">Description (Optional)</Label>
            <Textarea
              id="field-description"
              value={fieldDescription}
              onChange={(e) => setFieldDescription(e.target.value)}
              placeholder="Field description or help text..."
              rows={2}
              className="mt-1"
            />
          </div>
          
          <div>
            <Label>Field Type</Label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {FIELD_TYPES.map((fieldType) => {
                const Icon = fieldType.icon;
                return (
                  <button
                    key={fieldType.type}
                    onClick={() => setSelectedType(fieldType.type)}
                    className={`p-2 rounded-md border text-left transition-colors ${
                      selectedType === fieldType.type
                        ? "border-blue-500 bg-blue-50 text-blue-700"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Icon className="h-4 w-4" />
                      <span className="text-sm font-medium">{fieldType.label}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
          
          <div className="flex gap-2 pt-2">
            <Button 
              onClick={handleCustomCreate} 
              disabled={!fieldLabel.trim() || isCreating}
              size="sm"
              className="flex-1"
            >
              {isCreating ? "Creating..." : "Create Field"}
            </Button>
            <Button 
              variant="outline" 
              onClick={() => setShowCustomForm(false)}
              size="sm"
            >
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-dashed border-2 border-gray-200 bg-gray-50/50">
      <CardContent className="p-4">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-medium text-gray-700">Quick Add Fields</h4>
            <Badge variant="secondary" className="text-xs">
              {groupId} group
            </Badge>
          </div>
          
          {/* Quick create buttons */}
          <div className="grid grid-cols-2 gap-2">
            {FIELD_TYPES.slice(0, 6).map((fieldType) => {
              const Icon = fieldType.icon;
              return (
                <Button
                  key={fieldType.type}
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickCreate(fieldType.type)}
                  disabled={isCreating}
                  className="justify-start h-auto p-2 text-xs"
                >
                  <Icon className="h-3 w-3 mr-1" />
                  {fieldType.label}
                </Button>
              );
            })}
          </div>
          
          <div className="flex gap-2 pt-2 border-t">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowCustomForm(true)}
              className="flex-1 text-xs"
            >
              <Sparkles className="h-3 w-3 mr-1" />
              Custom Field
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleQuickCreate("textarea")}
              disabled={isCreating}
              className="text-xs"
            >
              <FileText className="h-3 w-3 mr-1" />
              Text Area
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
