
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Plus, X, Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface GroupCreationWidgetProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateGroup: (group: {
    id: string;
    label: string;
    description?: string;
    defaultExpanded: boolean;
  }) => void;
}

export function GroupCreationWidget({
  isOpen,
  onClose,
  onCreateGroup,
}: GroupCreationWidgetProps) {
  const [groupName, setGroupName] = useState("");
  const [description, setDescription] = useState("");
  const [defaultExpanded, setDefaultExpanded] = useState(true);

  const handleCreate = () => {
    if (!groupName.trim()) return;

    const groupId = groupName.toLowerCase().replace(/\s+/g, '-');
    
    onCreateGroup({
      id: groupId,
      label: groupName,
      description: description || undefined,
      defaultExpanded,
    });

    // Reset form
    setGroupName("");
    setDescription("");
    setDefaultExpanded(true);
    onClose();
  };

  const handleCancel = () => {
    setGroupName("");
    setDescription("");
    setDefaultExpanded(true);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <Card className="mx-4 mb-4 border-2 border-blue-200 bg-blue-50">
      <CardContent className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-medium text-blue-900">Create New Section</h3>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleCancel}
            className="h-6 w-6 text-blue-600 hover:text-blue-800"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="space-y-3">
          <div>
            <Label htmlFor="group-name" className="text-sm font-medium text-blue-900">
              Section Name *
            </Label>
            <Input
              id="group-name"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="e.g., Contact Information"
              className="mt-1"
              autoFocus
            />
          </div>

          <div>
            <Label htmlFor="group-description" className="text-sm font-medium text-blue-900">
              Description
            </Label>
            <Textarea
              id="group-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Optional description for this section"
              className="mt-1 h-16 resize-none"
            />
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="default-expanded" className="text-sm font-medium text-blue-900">
              Expanded by default
            </Label>
            <Switch
              id="default-expanded"
              checked={defaultExpanded}
              onCheckedChange={setDefaultExpanded}
            />
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <Button
            onClick={handleCreate}
            disabled={!groupName.trim()}
            size="sm"
            className="flex-1"
          >
            <Check className="h-4 w-4 mr-1" />
            Create Section
          </Button>
          <Button
            variant="outline"
            onClick={handleCancel}
            size="sm"
            className="flex-1"
          >
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
