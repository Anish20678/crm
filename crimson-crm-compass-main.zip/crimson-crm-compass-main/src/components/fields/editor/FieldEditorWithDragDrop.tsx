
import React, { useState } from "react";
import { DropResult } from "react-beautiful-dnd";
import { FieldDragDropProvider, useFieldDragDrop } from "./DragDropContext";
import { FieldEditorMain } from "./FieldEditorMain";
import { FieldEditorSidebar } from "./FieldEditorSidebar";

interface FieldEditorWithDragDropProps {
  module: string;
}

function FieldEditorContent({ module }: { module: string }) {
  const [selectedField, setSelectedField] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<"form" | "list">("form");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { handleDrop } = useFieldDragDrop();

  // This component now has access to the drag-drop context
  const handleFieldCreated = (fieldId: string) => {
    setSelectedField(fieldId);
  };

  return (
    <div className="min-h-screen flex w-full bg-gray-50">
      <FieldEditorSidebar
        module={module}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        selectedField={selectedField}
        onFieldSelect={setSelectedField}
      />
      
      <FieldEditorMain
        module={module}
        selectedField={selectedField}
        onFieldSelect={setSelectedField}
        activeView={activeView}
        onViewChange={setActiveView}
      />
    </div>
  );
}

export function FieldEditorWithDragDrop({ module }: FieldEditorWithDragDropProps) {
  return (
    <FieldDragDropProvider module={module}>
      <FieldEditorContent module={module} />
    </FieldDragDropProvider>
  );
}
