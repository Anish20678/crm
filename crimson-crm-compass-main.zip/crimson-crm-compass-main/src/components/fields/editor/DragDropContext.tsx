import React, { createContext, useContext, useState, useCallback } from "react";
import { DragDropContext, DropResult } from "react-beautiful-dnd";
import { useToast } from "@/hooks/use-toast";
import { useEnhancedFieldCreation } from "@/hooks/useEnhancedFieldCreation";
import { useCustomFieldsMutations } from "@/hooks/useCustomFieldsMutations";
import { useSystemFieldConfigs } from "@/hooks/useSystemFieldConfigs";
import { calculateInsertOrderIndex } from "@/lib/orderIndexUtils";
import type { CustomFieldType } from "@/lib/types/customFields";

interface DraggedItem {
  id: string;
  type: "new-field" | "existing-field";
  fieldType?: CustomFieldType;
  label?: string;
  sourceGroup?: string;
}

interface FieldItem {
  id: string;
  label: string;
  type: string;
  required: boolean;
  visible: boolean;
  isSystem: boolean;
  group?: string;
  order_index: number;
}

interface FieldDragDropContextType {
  draggedItem: DraggedItem | null;
  setDraggedItem: (item: DraggedItem | null) => void;
  isDragging: boolean;
  setIsDragging: (dragging: boolean) => void;
  handleDrop: (result: DropResult, fields: FieldItem[], onFieldsUpdate: (fields: FieldItem[]) => void, onFieldCreated?: (fieldId: string) => void) => Promise<void>;
}

const FieldDragDropContext = createContext<FieldDragDropContextType | null>(null);

export function useFieldDragDrop() {
  const context = useContext(FieldDragDropContext);
  if (!context) {
    throw new Error("useFieldDragDrop must be used within FieldDragDropProvider");
  }
  return context;
}

interface FieldDragDropProviderProps {
  children: React.ReactNode;
  module: string;
}

export function FieldDragDropProvider({ children, module }: FieldDragDropProviderProps) {
  const [draggedItem, setDraggedItem] = useState<DraggedItem | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const { toast } = useToast();
  const { createFieldWithType } = useEnhancedFieldCreation(module);
  const { reorderFields } = useCustomFieldsMutations(module);
  const { updateFieldsByGroup } = useSystemFieldConfigs(module);

  const handleDrop = useCallback(async (
    result: DropResult, 
    fields: FieldItem[], 
    onFieldsUpdate: (fields: FieldItem[]) => void,
    onFieldCreated?: (fieldId: string) => void
  ) => {
    console.log("Drop operation started:", result);
    console.log("Dragged item:", draggedItem);
    console.log("Current fields:", fields);

    if (!result.destination) {
      console.log("No destination, clearing drag state");
      setDraggedItem(null);
      setIsDragging(false);
      return;
    }

    const { source, destination, draggableId } = result;
    const targetGroupId = destination.droppableId;
    const insertPosition = destination.index;

    try {
      // Handle new field creation
      if (draggedItem?.type === "new-field" && draggedItem.fieldType) {
        console.log(`Creating new field: ${draggedItem.fieldType} at position ${insertPosition} in group: ${targetGroupId}`);
        
        // Get fields in target group for precise positioning
        const targetGroupFields = fields
          .filter(f => f.group === targetGroupId)
          .sort((a, b) => a.order_index - b.order_index);

        // Calculate precise order index for insertion
        const newOrderIndex = calculateInsertOrderIndex(targetGroupFields, insertPosition);
        console.log("Calculated order index:", newOrderIndex);

        // Create field with only allowed options
        const fieldOptions = {
          label: draggedItem.label || `New ${draggedItem.fieldType} Field`,
          required: false,
        };

        const fieldId = await createFieldWithType(
          draggedItem.fieldType,
          targetGroupId,
          fieldOptions
        );

        // Update the field with the correct order index after creation
        if (fieldId) {
          await reorderFields([{
            id: fieldId,
            order_index: newOrderIndex,
            field_group: targetGroupId,
            visible: true,
            required: false
          }]);

          if (onFieldCreated) {
            onFieldCreated(fieldId);
          }
        }

        toast({
          title: "Field added successfully",
          description: `${draggedItem.label || draggedItem.fieldType} field has been added at position ${insertPosition + 1}.`,
        });

        return;
      }

      // Handle existing field reordering
      if (draggedItem?.type === "existing-field") {
        console.log(`Reordering field: ${draggableId} to position ${insertPosition} in group: ${targetGroupId}`);
        
        const fieldToMove = fields.find(f => f.id === draggableId);
        if (!fieldToMove) {
          console.error("Field to move not found:", draggableId);
          return;
        }

        // Get current fields in target group (excluding the field being moved)
        const targetGroupFields = fields
          .filter(f => f.group === targetGroupId && f.id !== draggableId)
          .sort((a, b) => a.order_index - b.order_index);

        // Calculate precise order index for the new position
        const newOrderIndex = calculateInsertOrderIndex(targetGroupFields, insertPosition);
        console.log("Calculated new order index:", newOrderIndex);

        // Create updated fields array with immediate UI update
        const updatedFields = fields.map(field => 
          field.id === fieldToMove.id 
            ? { ...field, group: targetGroupId, order_index: newOrderIndex }
            : field
        );

        // Update UI immediately for responsive feedback
        onFieldsUpdate(updatedFields);

        // Persist changes to database
        if (fieldToMove.isSystem) {
          // Update system field configuration
          await updateFieldsByGroup([{
            field_name: fieldToMove.id,
            field_group: targetGroupId,
            group_order: 0,
          }]);
        } else {
          // Update custom field with precise positioning
          await reorderFields([{
            id: fieldToMove.id,
            order_index: newOrderIndex,
            field_group: targetGroupId,
            visible: fieldToMove.visible,
            required: fieldToMove.required
          }]);
        }

        toast({
          title: "Field repositioned",
          description: `${fieldToMove.label} has been moved to position ${insertPosition + 1} in ${targetGroupId}.`,
        });
      }

    } catch (error) {
      console.error("Drop operation failed:", error);
      toast({
        title: "Error",
        description: "Failed to complete the operation. Please try again.",
        variant: "destructive",
      });
      
      // Revert UI changes on error by refetching current state
      const revertedFields = [...fields];
      onFieldsUpdate(revertedFields);
    } finally {
      setDraggedItem(null);
      setIsDragging(false);
    }
  }, [draggedItem, createFieldWithType, reorderFields, updateFieldsByGroup, toast]);

  // Handle the main drag end event - this will be called by the DragDropContext
  const handleDragEnd = useCallback(async (result: DropResult) => {
    console.log("DragDropContext onDragEnd triggered:", result);
    // This function will be called when connected to the main context
    // For now, we'll keep it simple and let individual components handle their own logic
  }, []);

  const contextValue: FieldDragDropContextType = {
    draggedItem,
    setDraggedItem,
    isDragging,
    setIsDragging,
    handleDrop,
  };

  return (
    <FieldDragDropContext.Provider value={contextValue}>
      <DragDropContext onDragEnd={handleDragEnd}>
        {children}
      </DragDropContext>
    </FieldDragDropContext.Provider>
  );
}
