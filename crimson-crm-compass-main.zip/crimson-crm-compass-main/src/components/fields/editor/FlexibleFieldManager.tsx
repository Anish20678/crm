
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Wand2,
  Plus,
  Layout,
  Copy,
  Settings,
  ArrowUpDown,
  MoreVertical,
  Eye,
  EyeOff,
} from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { AdvancedFieldCreationDialog } from "./AdvancedFieldCreationDialog";
import { GroupTemplateSelector } from "./GroupTemplateSelector";
import { useCustomFieldsData } from "@/hooks/useCustomFieldsData";
import { useFlexibleGroupManagement } from "@/hooks/useFlexibleGroupManagement";
import { useAdvancedFieldCreation } from "@/hooks/useAdvancedFieldCreation";

interface FlexibleFieldManagerProps {
  module: string;
  selectedField: string | null;
  onFieldSelect: (fieldId: string) => void;
  onToggleFieldVisibility: (fieldId: string) => void;
}

export function FlexibleFieldManager({
  module,
  selectedField,
  onFieldSelect,
  onToggleFieldVisibility,
}: FlexibleFieldManagerProps) {
  const { customFields, isLoading } = useCustomFieldsData(module);
  const { fieldGroups, refetch } = useFlexibleGroupManagement(module);
  const { duplicateField } = useAdvancedFieldCreation(module);
  
  const [showAdvancedCreator, setShowAdvancedCreator] = useState(false);
  const [showTemplateSelector, setShowTemplateSelector] = useState(false);
  const [selectedGroupId, setSelectedGroupId] = useState<string>("custom");

  // Group fields by field_group
  const groupedFields = React.useMemo(() => {
    const grouped: Record<string, typeof customFields> = {};
    
    // Initialize with existing field groups
    fieldGroups.forEach(group => {
      grouped[group.id] = [];
    });
    
    // Add a default "custom" group if it doesn't exist
    if (!grouped["custom"]) {
      grouped["custom"] = [];
    }
    
    // Group the custom fields
    customFields.forEach(field => {
      const groupId = field.field_group || 'custom';
      if (!grouped[groupId]) {
        grouped[groupId] = [];
      }
      grouped[groupId].push(field);
    });
    
    return grouped;
  }, [customFields, fieldGroups]);

  const handleDuplicateField = async (fieldId: string) => {
    const duplicatedFieldId = await duplicateField(fieldId);
    if (duplicatedFieldId) {
      onFieldSelect(duplicatedFieldId);
    }
  };

  const handleCreateAdvancedField = (groupId: string) => {
    setSelectedGroupId(groupId);
    setShowAdvancedCreator(true);
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-6 border-b bg-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold">Field Manager</h3>
            <p className="text-sm text-muted-foreground">
              Manage and organize your {module} fields
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowTemplateSelector(true)}
            >
              <Layout className="h-4 w-4 mr-2" />
              Templates
            </Button>
            <Button
              size="sm"
              onClick={() => handleCreateAdvancedField("custom")}
            >
              <Wand2 className="h-4 w-4 mr-2" />
              Advanced
            </Button>
          </div>
        </div>
      </div>

      {/* Field Groups */}
      <ScrollArea className="flex-1">
        <div className="p-6 space-y-6">
          {fieldGroups.length === 0 && Object.keys(groupedFields).length === 0 ? (
            <Card className="p-8 text-center">
              <div className="flex flex-col items-center gap-4">
                <Settings className="h-12 w-12 text-gray-400" />
                <div>
                  <h3 className="text-lg font-medium">No Field Groups</h3>
                  <p className="text-muted-foreground mt-1">
                    Create your first field group to get started
                  </p>
                </div>
                <Button onClick={() => setShowTemplateSelector(true)}>
                  <Layout className="h-4 w-4 mr-2" />
                  Browse Templates
                </Button>
              </div>
            </Card>
          ) : (
            <>
              {/* Display configured field groups */}
              {fieldGroups.map((group) => {
                const groupFields = groupedFields[group.id] || [];
                
                return (
                  <Card key={group.id} className="border-l-4 border-l-blue-500">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-base flex items-center gap-2">
                            {group.label}
                            <Badge variant="outline" className="text-xs">
                              {groupFields.length} fields
                            </Badge>
                          </CardTitle>
                          {group.description && (
                            <p className="text-sm text-muted-foreground mt-1">
                              {group.description}
                            </p>
                          )}
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleCreateAdvancedField(group.id)}
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent>
                              <DropdownMenuItem onClick={() => handleCreateAdvancedField(group.id)}>
                                <Plus className="h-4 w-4 mr-2" />
                                Add Field
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <ArrowUpDown className="h-4 w-4 mr-2" />
                                Reorder Fields
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Settings className="h-4 w-4 mr-2" />
                                Group Settings
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="pt-0">
                      {groupFields.length === 0 ? (
                        <div className="text-center py-8 text-muted-foreground">
                          <Settings className="h-8 w-8 mx-auto mb-2 opacity-50" />
                          <p className="text-sm">No fields in this group</p>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="mt-2"
                            onClick={() => handleCreateAdvancedField(group.id)}
                          >
                            <Plus className="h-4 w-4 mr-2" />
                            Add First Field
                          </Button>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {groupFields.map((field) => (
                            <div
                              key={field.id}
                              className={`group flex items-center gap-3 p-3 bg-gray-50 rounded-lg border cursor-pointer transition-all hover:shadow-sm ${
                                selectedField === field.id
                                  ? "ring-2 ring-blue-500 border-blue-200 bg-blue-50"
                                  : "border-gray-200"
                              }`}
                              onClick={() => onFieldSelect(field.id)}
                            >
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2">
                                  <span className="font-medium truncate">
                                    {field.label}
                                  </span>
                                  <Badge variant="outline" className="text-xs">
                                    {field.field_type}
                                  </Badge>
                                  {field.required && (
                                    <Badge variant="destructive" className="text-xs">
                                      Required
                                    </Badge>
                                  )}
                                </div>
                                <p className="text-xs text-muted-foreground truncate">
                                  {field.name}
                                </p>
                              </div>

                              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onToggleFieldVisibility(field.id);
                                  }}
                                  className="h-8 w-8 p-0"
                                >
                                  {field.visible ? (
                                    <Eye className="h-4 w-4 text-green-600" />
                                  ) : (
                                    <EyeOff className="h-4 w-4 text-gray-400" />
                                  )}
                                </Button>
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="h-8 w-8 p-0"
                                      onClick={(e) => e.stopPropagation()}
                                    >
                                      <MoreVertical className="h-4 w-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent>
                                    <DropdownMenuItem onClick={() => handleDuplicateField(field.id)}>
                                      <Copy className="h-4 w-4 mr-2" />
                                      Duplicate
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => onFieldSelect(field.id)}>
                                      <Settings className="h-4 w-4 mr-2" />
                                      Configure
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}

              {/* Display ungrouped fields in default "custom" group if no groups exist */}
              {fieldGroups.length === 0 && groupedFields["custom"] && groupedFields["custom"].length > 0 && (
                <Card className="border-l-4 border-l-purple-500">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-base flex items-center gap-2">
                          Custom Fields
                          <Badge variant="outline" className="text-xs">
                            {groupedFields["custom"].length} fields
                          </Badge>
                        </CardTitle>
                        <p className="text-sm text-muted-foreground mt-1">
                          User-defined custom fields
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCreateAdvancedField("custom")}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>

                  <CardContent className="pt-0">
                    <div className="space-y-2">
                      {groupedFields["custom"].map((field) => (
                        <div
                          key={field.id}
                          className={`group flex items-center gap-3 p-3 bg-gray-50 rounded-lg border cursor-pointer transition-all hover:shadow-sm ${
                            selectedField === field.id
                              ? "ring-2 ring-blue-500 border-blue-200 bg-blue-50"
                              : "border-gray-200"
                          }`}
                          onClick={() => onFieldSelect(field.id)}
                        >
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-medium truncate">
                                {field.label}
                              </span>
                              <Badge variant="outline" className="text-xs">
                                {field.field_type}
                              </Badge>
                              {field.required && (
                                <Badge variant="destructive" className="text-xs">
                                  Required
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground truncate">
                              {field.name}
                            </p>
                          </div>

                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                onToggleFieldVisibility(field.id);
                              }}
                              className="h-8 w-8 p-0"
                            >
                              {field.visible ? (
                                <Eye className="h-4 w-4 text-green-600" />
                              ) : (
                                <EyeOff className="h-4 w-4 text-gray-400" />
                              )}
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent>
                                <DropdownMenuItem onClick={() => handleDuplicateField(field.id)}>
                                  <Copy className="h-4 w-4 mr-2" />
                                  Duplicate
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => onFieldSelect(field.id)}>
                                  <Settings className="h-4 w-4 mr-2" />
                                  Configure
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </div>
      </ScrollArea>

      {/* Dialogs */}
      <AdvancedFieldCreationDialog
        isOpen={showAdvancedCreator}
        onClose={() => setShowAdvancedCreator(false)}
        module={module}
        groupId={selectedGroupId}
        onFieldCreated={(fieldId) => {
          onFieldSelect(fieldId);
          setShowAdvancedCreator(false);
        }}
      />

      <GroupTemplateSelector
        isOpen={showTemplateSelector}
        onClose={() => setShowTemplateSelector(false)}
        module={module}
        onGroupCreated={(groupId) => {
          setShowTemplateSelector(false);
          refetch(); // Refresh the field groups
        }}
      />
    </div>
  );
}
