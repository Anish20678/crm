
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Layers,
  Eye,
  EyeOff,
  FolderOpen,
  Shield,
  CheckSquare,
  Square
} from "lucide-react";
import { useSystemFieldDisplay } from "@/hooks/useSystemFieldDisplay";
import { useCustomFieldsData } from "@/hooks/useCustomFieldsData";
import { useFieldGroups } from "@/hooks/useFieldGroups";
import { useSystemFieldConfigs } from "@/hooks/useSystemFieldConfigs";
import { toast } from "@/hooks/use-toast";

interface BulkFieldOperationsProps {
  module: string;
}

export function BulkFieldOperations({ module }: BulkFieldOperationsProps) {
  const [selectedFields, setSelectedFields] = useState<string[]>([]);
  const [operationType, setOperationType] = useState<string>("");
  const [operationValue, setOperationValue] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState(false);

  const { visibleFields } = useSystemFieldDisplay(module);
  const { customFields } = useCustomFieldsData(module);
  const { fieldGroups } = useFieldGroups(module);
  const { upsertConfig } = useSystemFieldConfigs(module);

  // Combine all fields for selection
  const allFields = [
    ...visibleFields.map(field => ({
      id: field.fieldName,
      name: field.fieldName,
      label: field.label,
      type: "system" as const,
    })),
    ...customFields.map(field => ({
      id: field.id,
      name: field.name,
      label: field.label,
      type: "custom" as const,
    }))
  ];

  const handleFieldToggle = (fieldId: string) => {
    setSelectedFields(prev => 
      prev.includes(fieldId) 
        ? prev.filter(id => id !== fieldId)
        : [...prev, fieldId]
    );
  };

  const handleSelectAll = () => {
    setSelectedFields(allFields.map(f => f.id));
  };

  const handleDeselectAll = () => {
    setSelectedFields([]);
  };

  const handleBulkOperation = async () => {
    if (!operationType || selectedFields.length === 0) {
      toast({
        title: "Invalid operation",
        description: "Please select an operation type and at least one field.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);

    try {
      switch (operationType) {
        case "visibility_show":
          for (const fieldId of selectedFields) {
            const field = allFields.find(f => f.id === fieldId);
            if (field?.type === "system") {
              await upsertConfig({
                module,
                field_name: field.name,
                is_visible: true,
              });
            }
          }
          break;

        case "visibility_hide":
          for (const fieldId of selectedFields) {
            const field = allFields.find(f => f.id === fieldId);
            if (field?.type === "system") {
              await upsertConfig({
                module,
                field_name: field.name,
                is_visible: false,
              });
            }
          }
          break;

        case "group_assignment":
          for (const fieldId of selectedFields) {
            const field = allFields.find(f => f.id === fieldId);
            if (field?.type === "system") {
              await upsertConfig({
                module,
                field_name: field.name,
                field_group: operationValue,
              });
            }
          }
          break;

        default:
          throw new Error("Unknown operation type");
      }

      toast({
        title: "Bulk operation completed",
        description: `Successfully updated ${selectedFields.length} fields.`,
      });

      setSelectedFields([]);
      setOperationType("");
      setOperationValue("");
    } catch (error) {
      toast({
        title: "Bulk operation failed",
        description: "An error occurred while performing the bulk operation.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Layers className="h-5 w-5" />
          Bulk Field Operations
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Operation Selection */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Operation Type</label>
            <Select value={operationType} onValueChange={setOperationType}>
              <SelectTrigger>
                <SelectValue placeholder="Select operation" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="visibility_show">
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4" />
                    Show Fields
                  </div>
                </SelectItem>
                <SelectItem value="visibility_hide">
                  <div className="flex items-center gap-2">
                    <EyeOff className="h-4 w-4" />
                    Hide Fields
                  </div>
                </SelectItem>
                <SelectItem value="group_assignment">
                  <div className="flex items-center gap-2">
                    <FolderOpen className="h-4 w-4" />
                    Assign to Group
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {operationType === "group_assignment" && (
            <div>
              <label className="text-sm font-medium mb-2 block">Target Group</label>
              <Select value={operationValue} onValueChange={setOperationValue}>
                <SelectTrigger>
                  <SelectValue placeholder="Select group" />
                </SelectTrigger>
                <SelectContent>
                  {fieldGroups.map(group => (
                    <SelectItem key={group.id} value={group.id}>
                      {group.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>

        {/* Field Selection */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <label className="text-sm font-medium">Select Fields</label>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleSelectAll}>
                <CheckSquare className="h-4 w-4 mr-1" />
                All
              </Button>
              <Button variant="outline" size="sm" onClick={handleDeselectAll}>
                <Square className="h-4 w-4 mr-1" />
                None
              </Button>
            </div>
          </div>

          <div className="max-h-60 overflow-y-auto border rounded-md p-3 space-y-2">
            {allFields.map(field => (
              <div key={field.id} className="flex items-center space-x-2">
                <Checkbox
                  id={field.id}
                  checked={selectedFields.includes(field.id)}
                  onCheckedChange={() => handleFieldToggle(field.id)}
                />
                <label htmlFor={field.id} className="text-sm cursor-pointer flex items-center gap-2">
                  {field.label}
                  <Badge variant="outline" className="text-xs">
                    {field.type}
                  </Badge>
                </label>
              </div>
            ))}
          </div>

          {selectedFields.length > 0 && (
            <div className="mt-2 text-sm text-muted-foreground">
              {selectedFields.length} field{selectedFields.length !== 1 ? 's' : ''} selected
            </div>
          )}
        </div>

        {/* Progress and Action */}
        {isProcessing && (
          <div className="space-y-2">
            <Progress value={66} className="w-full" />
            <p className="text-sm text-muted-foreground">Processing bulk operation...</p>
          </div>
        )}

        <Button 
          onClick={handleBulkOperation}
          disabled={!operationType || selectedFields.length === 0 || isProcessing}
          className="w-full"
        >
          {isProcessing ? "Processing..." : "Apply Bulk Operation"}
        </Button>
      </CardContent>
    </Card>
  );
}
