
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Settings, 
  Eye, 
  FolderOpen, 
  Sparkles,
  Layers,
  Shield,
  File,
  Zap
} from "lucide-react";
import { FieldManagementPanel } from "./FieldManagementPanel";
import { GroupManagementPanel } from "./GroupManagementPanel";
import { LivePreviewPanel } from "./LivePreviewPanel";
import { AdvancedFieldSettings } from "./AdvancedFieldSettings";
import { BulkFieldOperations } from "./BulkFieldOperations";

interface UnifiedFieldManagerProps {
  module: string;
}

export function UnifiedFieldManager({ module }: UnifiedFieldManagerProps) {
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState<"form" | "list">("form");

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            Unified Field Manager
          </h3>
          <p className="text-sm text-muted-foreground">
            Comprehensive field and group management for {module} module
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline">
            {module.charAt(0).toUpperCase() + module.slice(1)}
          </Badge>
          <Badge variant="secondary">Enhanced</Badge>
        </div>
      </div>

      {/* Main Interface */}
      <Tabs defaultValue="fields" className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="fields" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Fields
          </TabsTrigger>
          <TabsTrigger value="groups" className="flex items-center gap-2">
            <FolderOpen className="h-4 w-4" />
            Groups
          </TabsTrigger>
          <TabsTrigger value="preview" className="flex items-center gap-2">
            <Eye className="h-4 w-4" />
            Preview
          </TabsTrigger>
          <TabsTrigger value="advanced" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Advanced
          </TabsTrigger>
          <TabsTrigger value="bulk" className="flex items-center gap-2">
            <Layers className="h-4 w-4" />
            Bulk Ops
          </TabsTrigger>
          <TabsTrigger value="templates" className="flex items-center gap-2">
            <File className="h-4 w-4" />
            Templates
          </TabsTrigger>
        </TabsList>

        {/* Fields Management */}
        <TabsContent value="fields">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Field Configuration</CardTitle>
              </CardHeader>
              <CardContent>
                <FieldManagementPanel
                  module={module}
                  selectedGroup={selectedGroup}
                  onGroupSelect={setSelectedGroup}
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Live Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <LivePreviewPanel
                  module={module}
                  previewMode={previewMode}
                  selectedGroup={selectedGroup}
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Groups Management */}
        <TabsContent value="groups">
          <GroupManagementPanel
            module={module}
            onGroupSelect={setSelectedGroup}
          />
        </TabsContent>

        {/* Preview */}
        <TabsContent value="preview">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Form & List Preview</CardTitle>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setPreviewMode("form")}
                    className={`px-3 py-1 text-sm rounded ${
                      previewMode === "form" 
                        ? "bg-primary text-primary-foreground" 
                        : "bg-muted"
                    }`}
                  >
                    Form View
                  </button>
                  <button
                    onClick={() => setPreviewMode("list")}
                    className={`px-3 py-1 text-sm rounded ${
                      previewMode === "list" 
                        ? "bg-primary text-primary-foreground" 
                        : "bg-muted"
                    }`}
                  >
                    List View
                  </button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <LivePreviewPanel
                module={module}
                previewMode={previewMode}
                selectedGroup={selectedGroup}
              />
            </CardContent>
          </Card>
        </TabsContent>

        {/* Advanced Settings */}
        <TabsContent value="advanced">
          <AdvancedFieldSettings module={module} />
        </TabsContent>

        {/* Bulk Operations */}
        <TabsContent value="bulk">
          <BulkFieldOperations module={module} />
        </TabsContent>

        {/* Templates (placeholder for now) */}
        <TabsContent value="templates">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <File className="h-5 w-5" />
                Field Templates
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-muted-foreground">
                <File className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Template management interface will be available here.</p>
                <p className="text-sm">Create, save, and apply field configurations as templates.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
