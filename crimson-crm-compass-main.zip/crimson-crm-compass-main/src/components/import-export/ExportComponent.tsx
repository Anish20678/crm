
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { useCustomFieldsData } from "@/hooks/useCustomFieldsData";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import { Label } from "@/components/ui/label";

type RecordModule = "lead" | "deal" | "contact" | "task";
const MODULE_OPTIONS: { label: string, value: RecordModule }[] = [
  { label: "Leads", value: "lead" },
  { label: "Deals", value: "deal" },
  { label: "Contacts", value: "contact" },
  { label: "Tasks", value: "task" },
];

const tableMap: Record<RecordModule, "contacts" | "deals" | "tasks"> = {
  lead: "contacts",
  deal: "deals",
  contact: "contacts",
  task: "tasks",
};

export function ExportComponent() {
  const [selectedModule, setSelectedModule] = useState<RecordModule>("lead");
  const { customFields } = useCustomFieldsData(selectedModule);

  const { data = [], isLoading, error } = useQuery({
    queryKey: ["export-data", selectedModule],
    queryFn: async () => {
      const table = tableMap[selectedModule];
      const { data, error } = await supabase.from(table).select("*");
      if (error) throw error;
      return data || [];
    }
  });

  const handleExport = () => {
    if (!data.length) {
      alert("No data to export");
      return;
    }
    // Build export array: one row per record,
    // columns: custom fields only, mapped by field.name
    const headers = customFields.map(f => f.label);
    const rows = data.map((row: any) => {
      return customFields.map(f => 
        row[f.name] ?? ""
      );
    });
    const worksheetData = [
      headers,
      ...rows
    ];
    const ws = XLSX.utils.aoa_to_sheet(worksheetData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, selectedModule);
    const excelBuffer = XLSX.write(wb, { type: "array", bookType: "xlsx" });
    const blob = new Blob([excelBuffer], { type: "application/octet-stream" });
    saveAs(blob, `export-${selectedModule}.xlsx`);
  };

  return (
    <div>
      <div className="flex gap-2 mb-4">
        {MODULE_OPTIONS.map(mod => (
          <Button 
            key={mod.value} 
            variant={selectedModule === mod.value ? "default" : "outline"}
            onClick={() => setSelectedModule(mod.value)}
            size="sm"
          >{mod.label}</Button>
        ))}
      </div>
      {isLoading && <div>Loading data...</div>}
      {error && <div className="text-red-600 text-xs">{String(error)}</div>}
      <Button onClick={handleExport} disabled={isLoading || !customFields.length}>
        Download Excel
      </Button>
      <div className="text-xs mt-3 text-muted-foreground">
        Exports only fields that are currently defined in the Fields Editor.
      </div>
    </div>
  );
}
