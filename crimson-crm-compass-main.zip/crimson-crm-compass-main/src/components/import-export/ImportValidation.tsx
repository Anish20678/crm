
import React from "react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, CheckCircle, XCircle } from "lucide-react";

export interface ValidationError {
  row: number;
  field: string;
  value: any;
  error: string;
  severity: "error" | "warning";
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  warnings: ValidationError[];
  validRowCount: number;
  totalRowCount: number;
}

interface ImportValidationProps {
  validationResult: ValidationResult;
  onProceed: () => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export function ImportValidation({
  validationResult,
  onProceed,
  onCancel,
  isLoading = false,
}: ImportValidationProps) {
  const { errors, warnings, validRowCount, totalRowCount } = validationResult;
  const hasErrors = errors.length > 0;
  const hasWarnings = warnings.length > 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-4">
        {hasErrors ? (
          <XCircle className="h-5 w-5 text-red-500" />
        ) : (
          <CheckCircle className="h-5 w-5 text-green-500" />
        )}
        <h3 className="font-semibold">
          Validation Results: {validRowCount} of {totalRowCount} rows valid
        </h3>
      </div>

      {hasErrors && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            {errors.length} error(s) found. Please fix these before importing.
          </AlertDescription>
        </Alert>
      )}

      {hasWarnings && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            {warnings.length} warning(s) found. You can still proceed but review these issues.
          </AlertDescription>
        </Alert>
      )}

      {(hasErrors || hasWarnings) && (
        <div className="max-h-60 overflow-y-auto border rounded p-3">
          <h4 className="font-medium mb-2">Issues Found:</h4>
          <div className="space-y-2">
            {[...errors, ...warnings].map((issue, index) => (
              <div key={index} className="flex items-start gap-2 text-sm">
                <Badge variant={issue.severity === "error" ? "destructive" : "secondary"}>
                  Row {issue.row + 1}
                </Badge>
                <div>
                  <span className="font-medium">{issue.field}:</span> {issue.error}
                  {issue.value && (
                    <span className="text-muted-foreground ml-1">
                      (value: "{String(issue.value)}")
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex gap-2">
        <button
          onClick={onProceed}
          disabled={hasErrors || isLoading}
          className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? "Importing..." : `Import ${validRowCount} Valid Records`}
        </button>
        <button
          onClick={onCancel}
          className="px-4 py-2 border border-gray-300 rounded hover:bg-gray-50"
        >
          Cancel
        </button>
      </div>
    </div>
  );
}
