
import { useMemo } from "react";
import type { ValidationError, ValidationResult } from "./ImportValidation";

export interface FieldConfig {
  name: string;
  label: string;
  required?: boolean;
  type?: "text" | "email" | "phone" | "date" | "boolean" | "number";
  validate?: (value: any) => string | null;
}

export function useImportValidation(
  mappedRows: Record<string, any>[],
  fieldConfigs: FieldConfig[],
  module: string
) {
  return useMemo((): ValidationResult => {
    const errors: ValidationError[] = [];
    const warnings: ValidationError[] = [];
    let validRowCount = 0;

    mappedRows.forEach((row, rowIndex) => {
      let rowHasErrors = false;

      // Module-specific required fields
      const moduleRequiredFields = getModuleRequiredFields(module);
      
      fieldConfigs.forEach((field) => {
        const value = row[field.name];
        const isEmpty = value === null || value === undefined || value === "";

        // Check required fields
        if ((field.required || moduleRequiredFields.includes(field.name)) && isEmpty) {
          errors.push({
            row: rowIndex,
            field: field.label,
            value,
            error: `${field.label} is required`,
            severity: "error",
          });
          rowHasErrors = true;
          return;
        }

        // Skip validation for empty optional fields
        if (isEmpty) return;

        // Type validation
        const typeError = validateFieldType(value, field.type || "text", field.label);
        if (typeError) {
          errors.push({
            row: rowIndex,
            field: field.label,
            value,
            error: typeError,
            severity: "error",
          });
          rowHasErrors = true;
        }

        // Custom validation
        if (field.validate) {
          const customError = field.validate(value);
          if (customError) {
            errors.push({
              row: rowIndex,
              field: field.label,
              value,
              error: customError,
              severity: "error",
            });
            rowHasErrors = true;
          }
        }
      });

      // Module-specific validations
      const moduleErrors = validateModuleSpecific(row, module, rowIndex);
      errors.push(...moduleErrors.filter(e => e.severity === "error"));
      warnings.push(...moduleErrors.filter(e => e.severity === "warning"));
      
      if (moduleErrors.some(e => e.severity === "error")) {
        rowHasErrors = true;
      }

      if (!rowHasErrors) {
        validRowCount++;
      }
    });

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      validRowCount,
      totalRowCount: mappedRows.length,
    };
  }, [mappedRows, fieldConfigs, module]);
}

function getModuleRequiredFields(module: string): string[] {
  switch (module) {
    case "lead":
    case "contact":
      return ["first_name"];
    case "deal":
      return ["name"];
    case "task":
      return ["title"];
    default:
      return [];
  }
}

function validateFieldType(value: any, type: string, fieldLabel: string): string | null {
  const stringValue = String(value).trim();

  switch (type) {
    case "email":
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(stringValue)) {
        return `${fieldLabel} must be a valid email address`;
      }
      break;

    case "phone":
      const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
      if (!phoneRegex.test(stringValue.replace(/[\s\-\(\)]/g, ""))) {
        return `${fieldLabel} must be a valid phone number`;
      }
      break;

    case "date":
      const date = new Date(stringValue);
      if (isNaN(date.getTime())) {
        return `${fieldLabel} must be a valid date`;
      }
      break;

    case "boolean":
      const validBooleans = ["true", "false", "1", "0", "yes", "no"];
      if (!validBooleans.includes(stringValue.toLowerCase())) {
        return `${fieldLabel} must be true/false, yes/no, or 1/0`;
      }
      break;

    case "number":
      if (isNaN(Number(stringValue))) {
        return `${fieldLabel} must be a valid number`;
      }
      break;
  }

  return null;
}

function validateModuleSpecific(row: any, module: string, rowIndex: number): ValidationError[] {
  const errors: ValidationError[] = [];

  switch (module) {
    case "lead":
    case "contact":
      // Email validation if provided
      if (row.email && row.email.trim()) {
        const emailError = validateFieldType(row.email, "email", "Email");
        if (emailError) {
          errors.push({
            row: rowIndex,
            field: "Email",
            value: row.email,
            error: emailError,
            severity: "error",
          });
        }
      }

      // Phone validation if provided
      if (row.phone && row.phone.trim()) {
        const phoneError = validateFieldType(row.phone, "phone", "Phone");
        if (phoneError) {
          errors.push({
            row: rowIndex,
            field: "Phone",
            value: row.phone,
            error: phoneError,
            severity: "error",
          });
        }
      }

      // Warning for leads without contact info
      if (!row.email && !row.phone) {
        errors.push({
          row: rowIndex,
          field: "Contact Info",
          value: "",
          error: "No email or phone provided - contact will be hard to reach",
          severity: "warning",
        });
      }
      break;

    case "deal":
      // Amount validation if provided
      if (row.amount && isNaN(Number(row.amount))) {
        errors.push({
          row: rowIndex,
          field: "Amount",
          value: row.amount,
          error: "Amount must be a valid number",
          severity: "error",
        });
      }

      // Date validations
      if (row.expected_delivery_date) {
        const date = new Date(row.expected_delivery_date);
        if (isNaN(date.getTime())) {
          errors.push({
            row: rowIndex,
            field: "Expected Delivery Date",
            value: row.expected_delivery_date,
            error: "Must be a valid date",
            severity: "error",
          });
        }
      }
      break;

    case "task":
      // Priority validation
      if (row.priority && !["low", "medium", "high", "urgent"].includes(row.priority.toLowerCase())) {
        errors.push({
          row: rowIndex,
          field: "Priority",
          value: row.priority,
          error: "Priority must be low, medium, high, or urgent",
          severity: "error",
        });
      }

      // Status validation
      if (row.status && !["todo", "in_progress", "completed", "cancelled"].includes(row.status.toLowerCase())) {
        errors.push({
          row: rowIndex,
          field: "Status",
          value: row.status,
          error: "Status must be todo, in_progress, completed, or cancelled",
          severity: "error",
        });
      }
      break;
  }

  return errors;
}
