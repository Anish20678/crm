
import { useState } from "react";
import * as XLSX from "xlsx";

export function useExcelFields() {
  const [headers, setHeaders] = useState<string[]>([]);
  const [rows, setRows] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  function parseFile(file: File) {
    setError(null);
    setHeaders([]);
    setRows([]);
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json(sheet, { header: 1 });
        if (!json.length) throw new Error("Empty file.");
        const [headerRow, ...bodyRows] = json as Array<any>;
        setHeaders(headerRow.map(String));
        setRows(bodyRows.map((r) => {
          const obj: Record<string,string> = {};
          headerRow.forEach((h: string, idx: number) => {
            obj[String(h)] = (r[idx] !== undefined ? String(r[idx]) : "");
          });
          return obj;
        }));
      } catch (err: any) {
        setError("Could not parse Excel file. " + (err.message || ""));
      }
    };
    reader.onerror = () => setError("Failed to read file");
    reader.readAsArrayBuffer(file);
  }

  return { headers, rows, error, parseFile };
}
