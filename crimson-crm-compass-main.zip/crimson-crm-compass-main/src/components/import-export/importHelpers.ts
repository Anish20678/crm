
/**
 * Helper functions for data import processing
 */

export function convertBooleanValue(value: any): boolean | null {
  if (value === null || value === undefined || value === "") {
    return null;
  }
  
  const stringValue = String(value).toLowerCase().trim();
  
  if (["true", "yes", "1", "on", "enabled"].includes(stringValue)) {
    return true;
  }
  
  if (["false", "no", "0", "off", "disabled"].includes(stringValue)) {
    return false;
  }
  
  return null;
}

export function convertDateValue(value: any): string | null {
  if (value === null || value === undefined || value === "") {
    return null;
  }
  
  const date = new Date(value);
  if (isNaN(date.getTime())) {
    return null;
  }
  
  return date.toISOString();
}

export function convertNumberValue(value: any): number | null {
  if (value === null || value === undefined || value === "") {
    return null;
  }
  
  const number = Number(value);
  if (isNaN(number)) {
    return null;
  }
  
  return number;
}

export function sanitizeStringValue(value: any): string | null {
  if (value === null || value === undefined) {
    return null;
  }
  
  const stringValue = String(value).trim();
  return stringValue === "" ? null : stringValue;
}

export function prepareRecordForImport(record: any, module: string, userId: string): any {
  const cleanedRecord = { ...record };
  cleanedRecord.user_id = userId;
  
  // Apply type conversions based on field names
  Object.keys(cleanedRecord).forEach(key => {
    const value = cleanedRecord[key];
    
    // Handle empty strings
    if (value === "") {
      cleanedRecord[key] = null;
      return;
    }
    
    // Boolean fields
    if (key.startsWith("is_") || key === "proposal_sent" || key === "follow_up_required") {
      cleanedRecord[key] = convertBooleanValue(value);
    }
    
    // Date fields
    else if (key.includes("date") || key.includes("_at")) {
      cleanedRecord[key] = convertDateValue(value);
    }
    
    // Number fields
    else if (key === "amount" || key.includes("price") || key.includes("count") || key === "duration_minutes") {
      cleanedRecord[key] = convertNumberValue(value);
    }
    
    // String fields
    else if (typeof value === "string") {
      cleanedRecord[key] = sanitizeStringValue(value);
    }
  });
  
  // Module-specific field handling
  switch (module) {
    case "lead":
      cleanedRecord.is_client = false; // Leads are not clients by default
      break;
      
    case "contact":
      if (cleanedRecord.is_client === null || cleanedRecord.is_client === undefined) {
        cleanedRecord.is_client = true; // Contacts are clients by default
      }
      break;
      
    case "task":
      if (!cleanedRecord.status) {
        cleanedRecord.status = "todo";
      }
      if (!cleanedRecord.priority) {
        cleanedRecord.priority = "medium";
      }
      break;
      
    case "deal":
      if (!cleanedRecord.status) {
        cleanedRecord.status = "new";
      }
      break;
  }
  
  return cleanedRecord;
}
