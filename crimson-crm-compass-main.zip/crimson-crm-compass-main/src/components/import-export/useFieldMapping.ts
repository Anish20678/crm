
import { useState, useMemo } from "react";

type SimpleField = {
  name: string;
  label: string;
};

/**
 * Maps Excel headers to field names and provides mapped rows
 */
export function useFieldMapping(
  fields: SimpleField[],
  headers: string[],
  rows: any[]
) {
  const [mapping, setMapping] = useState<Record<string, string>>({});

  // Which headers are not mapped yet
  const unmappedHeaders = useMemo(() => {
    return headers.filter(h => !mapping[h]);
  }, [headers, mapping]);

  // Transformed list of objects, ready for database
  const mappedRows = useMemo(() => {
    if (!rows.length || !Object.values(mapping).some(Boolean)) return [];
    return rows.map(r => {
      const obj: Record<string,string> = {};
      for (const [header, fieldName] of Object.entries(mapping)) {
        if (fieldName) obj[fieldName] = r[header];
      }
      return obj;
    });
  }, [rows, mapping]);

  // Check for mapping errors (e.g., duplicate field assignments)
  const errors = useMemo(() => {
    const assignedFields = Object.values(mapping).filter(Boolean);
    const dupes = assignedFields.filter(
      (v, i, a) => a.indexOf(v) !== i && v !== ""
    );
    return dupes.length ? ["A field has been mapped more than once"] : [];
  }, [mapping]);

  return {
    mapping,
    setMapping,
    mappedRows,
    unmappedHeaders,
    errors,
  };
}
