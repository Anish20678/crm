import React, { useState } from "react";
import { useExcelFields } from "./useExcelFields";
import { useFieldMapping } from "./useFieldMapping";
import { useImportValidation, type FieldConfig } from "./useImportValidation";
import { ImportValidation } from "./ImportValidation";
import { ImportProgress, type ImportProgressData } from "./ImportProgress";
import { Button } from "@/components/ui/button";
import { useCustomFieldsData } from "@/hooks/useCustomFieldsData";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAllModuleFields } from "./useAllModuleFields";

type RecordModule = "lead" | "deal" | "contact" | "task";
const MODULE_OPTIONS: { label: string, value: RecordModule }[] = [
  { label: "Leads", value: "lead" },
  { label: "Deals", value: "deal" },
  { label: "Contacts", value: "contact" },
  { label: "Tasks", value: "task" },
];

export function ImportComponent() {
  const [selectedModule, setSelectedModule] = useState<RecordModule>("lead");
  const { customFields } = useCustomFieldsData(selectedModule);
  const [step, setStep] = useState<0 | 1 | 2 | 3 | 4>(0); // upload, mapping, validation, importing, complete
  const [file, setFile] = useState<File | null>(null);
  const [importProgress, setImportProgress] = useState<ImportProgressData | null>(null);
  const { headers, rows, error: excelErr, parseFile } = useExcelFields();
  const {
    mapping,
    setMapping,
    mappedRows,
    unmappedHeaders,
    errors: mappingErrors
  } = useFieldMapping(
    useAllModuleFields(selectedModule, customFields)
      .flatMap(group => group.fields),
    headers,
    rows
  );

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Create field configs for validation
  const fieldConfigs: FieldConfig[] = useAllModuleFields(selectedModule, customFields)
    .flatMap(group => group.fields)
    .map(field => ({
      name: field.name,
      label: field.label,
      required: getRequiredFields(selectedModule).includes(field.name),
      type: getFieldType(field.name),
    }));

  const validationResult = useImportValidation(mappedRows, fieldConfigs, selectedModule);

  // Database table name for each module
  const tableMap: Record<RecordModule, "contacts" | "deals" | "tasks"> = {
    lead: "contacts",
    deal: "deals",
    contact: "contacts",
    task: "tasks",
  };

  // All available fields for mapping, grouped
  const allFieldsGrouped = useAllModuleFields(selectedModule, customFields);

  // Enhanced import mutation with progress tracking
  const importMutation = useMutation({
    mutationFn: async (records: any[]) => {
      console.log("Starting enhanced import process...");
      
      // Check authentication
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError || !user) {
        throw new Error("You must be logged in to import data");
      }

      setImportProgress({
        phase: "importing",
        progress: 0,
        processedRows: 0,
        totalRows: records.length,
        successCount: 0,
        errorCount: 0,
      });

      const table = tableMap[selectedModule];
      const batchSize = 50; // Smaller batches for better progress tracking
      const totalBatches = Math.ceil(records.length / batchSize);
      let successCount = 0;
      let errorCount = 0;
      const errors: Array<{ row: number; error: string }> = [];

      // Prepare records with user_id and data cleaning
      const recordsWithUserId = records.map((record, index) => {
        const cleanedRecord = { ...record };
        cleanedRecord.user_id = user.id;
        
        // Convert empty strings to null and handle data types
        Object.keys(cleanedRecord).forEach(key => {
          if (cleanedRecord[key] === "") {
            cleanedRecord[key] = null;
          }
          
          // Convert boolean strings
          if (typeof cleanedRecord[key] === "string") {
            const lowerValue = cleanedRecord[key].toLowerCase();
            if (["true", "yes", "1"].includes(lowerValue)) {
              cleanedRecord[key] = true;
            } else if (["false", "no", "0"].includes(lowerValue)) {
              cleanedRecord[key] = false;
            }
          }
          
          // Handle module-specific conversions
          if (selectedModule === "lead" || selectedModule === "contact") {
            if (key === "is_client" && selectedModule === "lead") {
              cleanedRecord[key] = false; // Leads are not clients by default
            }
          }
        });

        return cleanedRecord;
      });

      // Process in batches
      for (let i = 0; i < recordsWithUserId.length; i += batchSize) {
        const batch = recordsWithUserId.slice(i, i + batchSize);
        const currentBatch = Math.floor(i / batchSize) + 1;
        
        setImportProgress(prev => prev ? {
          ...prev,
          currentBatch,
          totalBatches,
          processedRows: i,
        } : null);

        try {
          const { data, error: batchError } = await supabase
            .from(table)
            .insert(batch)
            .select('id');
          
          if (batchError) {
            console.error(`Batch ${currentBatch} error:`, batchError);
            
            // Try individual records if batch fails
            for (let j = 0; j < batch.length; j++) {
              try {
                const { error: individualError } = await supabase
                  .from(table)
                  .insert([batch[j]]);
                
                if (individualError) {
                  errorCount++;
                  errors.push({
                    row: i + j,
                    error: individualError.message,
                  });
                } else {
                  successCount++;
                }
              } catch (err: any) {
                errorCount++;
                errors.push({
                  row: i + j,
                  error: err.message || "Unknown error",
                });
              }
            }
          } else {
            successCount += data?.length || batch.length;
          }
        } catch (err: any) {
          console.error(`Batch ${currentBatch} exception:`, err);
          errorCount += batch.length;
          batch.forEach((_, j) => {
            errors.push({
              row: i + j,
              error: err.message || "Unknown error",
            });
          });
        }

        // Update progress
        const progress = Math.round(((i + batchSize) / recordsWithUserId.length) * 100);
        setImportProgress(prev => prev ? {
          ...prev,
          progress: Math.min(progress, 100),
          processedRows: Math.min(i + batchSize, recordsWithUserId.length),
          successCount,
          errorCount,
          errors: errors.slice(-10), // Keep last 10 errors
        } : null);

        // Small delay to show progress
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      console.log(`Import completed. Success: ${successCount}, Errors: ${errorCount}`);
      
      if (errorCount > 0 && successCount === 0) {
        throw new Error(`Import failed completely. ${errorCount} records failed to import.`);
      }

      return { successCount, errorCount, totalRecords: recordsWithUserId.length, errors };
    },
    onSuccess: (result) => {
      setImportProgress(prev => prev ? {
        ...prev,
        phase: "completed",
        progress: 100,
      } : null);
      
      queryClient.invalidateQueries();
      toast({ 
        title: "Import completed", 
        description: `Successfully imported ${result.successCount} ${selectedModule} records!${result.errorCount > 0 ? ` ${result.errorCount} records failed.` : ''}` 
      });
    },
    onError: (err: any) => {
      console.error("Import mutation error:", err);
      setImportProgress(prev => prev ? {
        ...prev,
        phase: "error",
        errors: [{ row: 0, error: err.message }],
      } : null);
      
      toast({ 
        title: "Import failed", 
        description: err.message || String(err), 
        variant: "destructive" 
      });
    }
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setFile(e.target.files[0]);
      parseFile(e.target.files[0]);
      setStep(1);
    }
  };

  const handleMappingChange = (header: string, fieldName: string) => {
    setMapping(prev => ({ ...prev, [header]: fieldName }));
  };

  const handleStartOver = () => {
    setStep(0);
    setFile(null);
    setMapping({});
    setImportProgress(null);
  };

  const handleProceedToValidation = () => {
    setStep(2);
  };

  const handleImport = () => {
    setStep(3);
    importMutation.mutate(mappedRows);
  };

  const handleValidationProceed = () => {
    handleImport();
  };

  const handleProgressClose = () => {
    handleStartOver();
  };

  // Show import progress overlay
  if (step === 3 && importProgress) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <ImportProgress progress={importProgress} onClose={handleProgressClose} />
      </div>
    );
  }

  return (
    <div>
      <div className="flex gap-2 mb-4">
        {MODULE_OPTIONS.map(mod => (
          <Button 
            key={mod.value} 
            variant={selectedModule === mod.value ? "default" : "outline"}
            onClick={() => { 
              setSelectedModule(mod.value); 
              setStep(0); 
              setFile(null); 
              setMapping({}); 
            }}
            size="sm"
          >{mod.label}</Button>
        ))}
      </div>
      
      {step === 0 && (
        <div className="space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-medium text-blue-900 mb-2">Import Requirements:</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• You must be logged in to import data</li>
              <li>• Excel file must have proper column headers</li>
              <li>• Required fields: {getRequiredFields(selectedModule).join(", ")}</li>
              <li>• Data will be validated before import</li>
            </ul>
          </div>
          
          <Label htmlFor="import-file" className="block">Select Excel file (.xlsx)</Label>
          <Input 
            id="import-file"
            type="file"
            accept=".xlsx"
            onChange={handleFileChange}
            className="mb-2"
          />
          {excelErr && <div className="text-sm text-red-600">{excelErr}</div>}
        </div>
      )}
      
      {step === 1 && headers.length > 0 && (
        <div className="space-y-4">
          <h3 className="font-semibold">Map Excel Columns</h3>
          <div className="text-sm text-gray-600 mb-4">
            Map your Excel columns to the appropriate {selectedModule} fields. Required fields are marked in red.
          </div>
          
          <div className="overflow-auto max-h-[20rem] border rounded mb-2">
            <table className="min-w-full text-sm">
              <thead>
                <tr>
                  <th className="p-2 bg-gray-50">Excel Header</th>
                  <th className="p-2 bg-gray-50">Map to Field</th>
                </tr>
              </thead>
              <tbody>
                {headers.map((h, index) => (
                  <tr key={h} className={index % 2 === 0 ? "bg-gray-25" : ""}>
                    <td className="p-2 font-medium">{h}</td>
                    <td className="p-2">
                      <select
                        className="bg-background border px-2 py-1 rounded text-sm w-full"
                        value={mapping[h] || ""}
                        onChange={e => handleMappingChange(h, e.target.value)}
                      >
                        <option value="">(skip this column)</option>
                        {allFieldsGrouped.map(group => (
                          <optgroup key={group.group} label={group.group}>
                            {group.fields.map(f => (
                              <option 
                                value={f.name} 
                                key={f.name}
                                style={{
                                  color: getRequiredFields(selectedModule).includes(f.name) ? 'red' : 'inherit'
                                }}
                              >
                                {f.label} {getRequiredFields(selectedModule).includes(f.name) ? '*' : ''}
                              </option>
                            ))}
                          </optgroup>
                        ))}
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="flex gap-2">
            <Button 
              onClick={handleProceedToValidation}
              disabled={Object.keys(mapping).filter(key => mapping[key]).length === 0}
            >
              Validate Data ({Object.keys(mapping).filter(key => mapping[key]).length} columns mapped)
            </Button>
            <Button 
              onClick={handleStartOver} 
              variant="outline"
            >Start Over</Button>
          </div>
          
          {Object.keys(mapping).filter(key => mapping[key]).length === 0 && (
            <div className="text-xs text-red-600">
              Please map at least one column before proceeding.
            </div>
          )}
        </div>
      )}
      
      {step === 2 && (
        <ImportValidation
          validationResult={validationResult}
          onProceed={handleValidationProceed}
          onCancel={handleStartOver}
          isLoading={importMutation.isPending}
        />
      )}
    </div>
  );
}

function getRequiredFields(module: string): string[] {
  switch (module) {
    case "lead":
    case "contact":
      return ["first_name"];
    case "deal":
      return ["name"];
    case "task":
      return ["title"];
    default:
      return [];
  }
}

function getFieldType(fieldName: string): "text" | "email" | "phone" | "date" | "boolean" | "number" {
  if (fieldName.includes("email")) return "email";
  if (fieldName.includes("phone")) return "phone";
  if (fieldName.includes("date")) return "date";
  if (fieldName.includes("amount") || fieldName.includes("price")) return "number";
  if (fieldName.includes("is_") || fieldName === "proposal_sent") return "boolean";
  return "text";
}
