
import React from "react";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, XCircle, AlertTriangle } from "lucide-react";

export interface ImportProgressData {
  phase: "validating" | "importing" | "completed" | "error";
  progress: number;
  processedRows: number;
  totalRows: number;
  successCount: number;
  errorCount: number;
  currentBatch?: number;
  totalBatches?: number;
  errors?: Array<{
    row: number;
    error: string;
  }>;
}

interface ImportProgressProps {
  progress: ImportProgressData;
  onClose?: () => void;
}

export function ImportProgress({ progress, onClose }: ImportProgressProps) {
  const { phase, progress: percent, processedRows, totalRows, successCount, errorCount } = progress;

  const getPhaseText = () => {
    switch (phase) {
      case "validating":
        return "Validating data...";
      case "importing":
        return `Importing records... (${processedRows}/${totalRows})`;
      case "completed":
        return "Import completed!";
      case "error":
        return "Import failed";
      default:
        return "Processing...";
    }
  };

  const getIcon = () => {
    switch (phase) {
      case "completed":
        return <CheckCircle className="h-6 w-6 text-green-500" />;
      case "error":
        return <XCircle className="h-6 w-6 text-red-500" />;
      default:
        return <AlertTriangle className="h-6 w-6 text-blue-500" />;
    }
  };

  return (
    <div className="bg-white border rounded-lg p-6 max-w-md mx-auto">
      <div className="flex items-center gap-3 mb-4">
        {getIcon()}
        <h3 className="font-semibold text-lg">{getPhaseText()}</h3>
      </div>

      {phase !== "error" && (
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>Progress</span>
              <span>{Math.round(percent)}%</span>
            </div>
            <Progress value={percent} className="w-full" />
          </div>

          {phase === "importing" && progress.currentBatch && progress.totalBatches && (
            <div className="text-sm text-gray-600">
              Batch {progress.currentBatch} of {progress.totalBatches}
            </div>
          )}

          {(phase === "completed" || phase === "importing") && (
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium text-green-600">Success:</span>
                <div className="text-2xl font-bold text-green-600">{successCount}</div>
              </div>
              <div>
                <span className="font-medium text-red-600">Errors:</span>
                <div className="text-2xl font-bold text-red-600">{errorCount}</div>
              </div>
            </div>
          )}
        </div>
      )}

      {phase === "error" && progress.errors && (
        <div className="mt-4">
          <h4 className="font-medium text-red-600 mb-2">Recent Errors:</h4>
          <div className="max-h-32 overflow-y-auto text-sm bg-red-50 p-3 rounded">
            {progress.errors.slice(0, 5).map((error, index) => (
              <div key={index} className="mb-1">
                <span className="font-medium">Row {error.row + 1}:</span> {error.error}
              </div>
            ))}
            {progress.errors.length > 5 && (
              <div className="text-gray-600">... and {progress.errors.length - 5} more errors</div>
            )}
          </div>
        </div>
      )}

      {(phase === "completed" || phase === "error") && onClose && (
        <button
          onClick={onClose}
          className="w-full mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Close
        </button>
      )}
    </div>
  );
}
