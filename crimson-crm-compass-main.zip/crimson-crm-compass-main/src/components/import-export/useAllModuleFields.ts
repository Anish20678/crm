
import type { CustomField } from "@/lib/types/customFields";

/**
 * Built-in fields for each module
 */
const BUILTIN_FIELDS: Record<string, { name: string; label: string }[]> = {
  lead: [
    { name: "first_name", label: "First Name" },
    { name: "last_name", label: "Last Name" },
    { name: "email", label: "Email" },
    { name: "phone", label: "Phone" },
    { name: "company", label: "Company" },
    { name: "position", label: "Position" },
    { name: "status", label: "Status" },
    { name: "notes", label: "Notes" },
    // Lead-specific
    { name: "business_name", label: "Business Name" },
    { name: "business_type", label: "Business Type" },
    { name: "emirates", label: "Emirates" },
    { name: "lead_source", label: "Lead Source" },
    { name: "campaign_name", label: "Campaign Name" },
    { name: "inquiry_date", label: "Inquiry Date" },
    { name: "initial_whatsapp_message", label: "Initial WhatsApp Message" },
    { name: "call_notes", label: "Call Notes" },
    { name: "proposal_sent", label: "Proposal Sent" },
    { name: "proposal_files", label: "Proposal Files" },
    { name: "follow_up_date", label: "Follow Up Date" },
    { name: "preferred_contact_method", label: "Preferred Contact Method" },
    { name: "is_client", label: "Is Client" },
    { name: "phone_numbers", label: "Phone Numbers" },
  ],
  contact: [
    { name: "first_name", label: "First Name" },
    { name: "last_name", label: "Last Name" },
    { name: "email", label: "Email" },
    { name: "phone", label: "Phone" },
    { name: "company", label: "Company" },
    { name: "position", label: "Position" },
    { name: "status", label: "Status" },
    { name: "notes", label: "Notes" },
    { name: "business_name", label: "Business Name" },
    { name: "business_type", label: "Business Type" },
    { name: "emirates", label: "Emirates" },
    { name: "lead_source", label: "Lead Source" },
    { name: "campaign_name", label: "Campaign Name" },
    { name: "inquiry_date", label: "Inquiry Date" },
    { name: "initial_whatsapp_message", label: "Initial WhatsApp Message" },
    { name: "call_notes", label: "Call Notes" },
    { name: "proposal_sent", label: "Proposal Sent" },
    { name: "proposal_files", label: "Proposal Files" },
    { name: "follow_up_date", label: "Follow Up Date" },
    { name: "preferred_contact_method", label: "Preferred Contact Method" },
    { name: "is_client", label: "Is Client" },
    { name: "phone_numbers", label: "Phone Numbers" },
  ],
  deal: [
    { name: "name", label: "Deal Name" },
    { name: "amount", label: "Amount" },
    { name: "status", label: "Status" },
    { name: "created_at", label: "Created At" },
    { name: "updated_at", label: "Updated At" },
    { name: "project_type", label: "Project Type" },
    { name: "service_package", label: "Service Package" },
    { name: "project_scope", label: "Project Scope" },
    { name: "requirements_received", label: "Requirements Received" },
    { name: "start_date", label: "Start Date" },
    { name: "expected_delivery_date", label: "Expected Delivery Date" },
    { name: "actual_delivery_date", label: "Actual Delivery Date" },
    { name: "milestones", label: "Milestones" },
    { name: "payment_status", label: "Payment Status" },
    { name: "payment_received_date", label: "Payment Received Date" },
    { name: "invoice_file", label: "Invoice File" },
    { name: "client_notes", label: "Client Notes" },
    { name: "internal_notes", label: "Internal Notes" },
    { name: "project_files", label: "Project Files" },
    { name: "final_deliverables", label: "Final Deliverables" },
    { name: "contact_id", label: "Contact Id" },
  ],
  task: [
    { name: "title", label: "Task Title" },
    { name: "description", label: "Description" },
    { name: "status", label: "Status" },
    { name: "priority", label: "Priority" },
    { name: "due_date", label: "Due Date" },
    { name: "assigned_to", label: "Assigned To" },
    { name: "related_to_type", label: "Related To Type" },
    { name: "related_to_id", label: "Related To Id" },
    { name: "created_at", label: "Created At" },
    { name: "updated_at", label: "Updated At" },
    { name: "user_id", label: "User Id" },
  ],
};

/**
 * Get all fields (built-in and custom) for a module. Custom fields override built-ins if same name.
 */
export function useAllModuleFields(module: string, customFields: CustomField[]) {
  // Filter out built-ins that are duplicated by a custom field (by name)
  const customNames = new Set(customFields.map(f => f.name));
  const builtin = (BUILTIN_FIELDS[module] || [])
    .filter(f => !customNames.has(f.name));
  return [
    { group: "Platform fields", fields: builtin },
    { group: "Custom fields", fields: customFields.map(f => ({ name: f.name, label: f.label })) }
  ]
}
