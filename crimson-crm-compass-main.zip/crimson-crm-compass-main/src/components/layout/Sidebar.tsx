
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { navigation } from "@/config/navigation";
import { ChevronRight, Menu } from "lucide-react";
import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";

export function Sidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [expandedItems, setExpandedItems] = useState<Record<string, boolean>>({});
  const location = useLocation();

  // Initialize expanded state for each navigation item
  useEffect(() => {
    const initialExpandedState: Record<string, boolean> = {};
    navigation.forEach((item) => {
      // Set Workspace to be expanded by default, or if the current path matches any of its items
      if (item.title === "Workspace") {
        initialExpandedState[item.title] = true;
      } else if (item.items) {
        // For other items, expand if the current path matches any of its items
        const shouldExpand = item.items.some((subItem) => location.pathname === subItem.href);
        initialExpandedState[item.title] = shouldExpand;
      }
    });
    setExpandedItems(initialExpandedState);
  }, []);

  const toggleExpanded = (title: string) => {
    setExpandedItems((prev) => ({
      ...prev,
      [title]: !prev[title],
    }));
  };

  return (
    <div
      className={cn(
        "flex flex-col border-r bg-gray-50/40",
        isCollapsed ? "w-16" : "w-64"
      )}
    >
      <div className="flex h-16 items-center border-b px-4">
        {!isCollapsed && (
          <Link to="/" className="flex items-center gap-2">
            <span className="text-xl font-semibold text-crimson">CRM</span>
          </Link>
        )}
        <Button
          variant="ghost"
          size="icon"
          className={cn("ml-auto", isCollapsed && "mx-auto")}
          onClick={() => setIsCollapsed(!isCollapsed)}
        >
          <Menu className="h-5 w-5" />
        </Button>
      </div>
      <div className="flex-1 overflow-auto py-4">
        <nav className="grid gap-1 px-2">
          {navigation.map((item, index) => {
            const isActive = item.href
              ? location.pathname === item.href
              : item.items?.some((subItem) => location.pathname === subItem.href);

            if (!item.items) {
              return (
                <Button
                  key={index}
                  variant={isActive ? "secondary" : "ghost"}
                  className={cn(
                    "justify-start",
                    isCollapsed && "justify-center px-2"
                  )}
                  asChild
                >
                  <Link to={item.href || "#"}>
                    <item.icon className="mr-2 h-5 w-5" />
                    {!isCollapsed && item.title}
                  </Link>
                </Button>
              );
            }

            const isExpanded = expandedItems[item.title] || false;

            return (
              <Collapsible key={index} open={isExpanded} onOpenChange={() => !isCollapsed && toggleExpanded(item.title)}>
                <CollapsibleTrigger asChild>
                  <Button
                    variant={isActive ? "secondary" : "ghost"}
                    className={cn(
                      "justify-start w-full",
                      isCollapsed && "justify-center px-2"
                    )}
                  >
                    <item.icon className="mr-2 h-5 w-5" />
                    {!isCollapsed && (
                      <>
                        <span className="flex-1 text-left">{item.title}</span>
                        <ChevronRight className={cn("h-4 w-4 transition-transform", isExpanded && "rotate-90")} />
                      </>
                    )}
                  </Button>
                </CollapsibleTrigger>
                {!isCollapsed && (
                  <CollapsibleContent className="pl-6">
                    {item.items.map((subItem, subIndex) => (
                      <Button
                        key={subIndex}
                        variant={
                          location.pathname === subItem.href
                            ? "secondary"
                            : "ghost"
                        }
                        className="w-full justify-start"
                        asChild
                      >
                        <Link to={subItem.href || "#"}>
                          <subItem.icon className="mr-2 h-5 w-5" />
                          {subItem.title}
                        </Link>
                      </Button>
                    ))}
                  </CollapsibleContent>
                )}
              </Collapsible>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
