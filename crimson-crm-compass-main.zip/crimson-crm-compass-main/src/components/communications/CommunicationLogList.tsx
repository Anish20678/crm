
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { 
  Mail, 
  MessageCircle, 
  Phone, 
  Users, 
  ArrowUpRight, 
  ArrowDownLeft,
  Search
} from "lucide-react";
import { CommunicationLog } from "@/lib/types";
import { format } from "date-fns";

export function CommunicationLogList() {
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [directionFilter, setDirectionFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");

  const { data: logs = [], isLoading } = useQuery({
    queryKey: ["communication-logs"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from("communication_logs")
        .select(`
          *,
          contacts(first_name, last_name, business_name)
        `)
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as (CommunicationLog & { 
        contacts: { first_name: string; last_name: string; business_name: string } 
      })[];
    },
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'email':
        return <Mail className="h-4 w-4" />;
      case 'whatsapp':
        return <MessageCircle className="h-4 w-4" />;
      case 'call':
        return <Phone className="h-4 w-4" />;
      case 'meeting':
        return <Users className="h-4 w-4" />;
      default:
        return <MessageCircle className="h-4 w-4" />;
    }
  };

  const getDirectionIcon = (direction: string) => {
    return direction === 'outbound' ? 
      <ArrowUpRight className="h-4 w-4" /> : 
      <ArrowDownLeft className="h-4 w-4" />;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'sent':
        return "bg-blue-500";
      case 'delivered':
        return "bg-green-500";
      case 'read':
        return "bg-purple-500";
      case 'failed':
        return "bg-red-500";
      case 'pending':
        return "bg-yellow-500";
      default:
        return "bg-gray-500";
    }
  };

  const filteredLogs = logs.filter(log => {
    const matchesType = typeFilter === "all" || log.communication_type === typeFilter;
    const matchesDirection = directionFilter === "all" || log.direction === directionFilter;
    const matchesSearch = !searchTerm || 
      log.subject?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.content?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.contacts?.first_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.contacts?.last_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.contacts?.business_name?.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesType && matchesDirection && matchesSearch;
  });

  if (isLoading) {
    return <div className="flex justify-center p-8">Loading communication logs...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold">Communication Logs</h1>
        <p className="text-muted-foreground">Track all communications with your contacts</p>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by contact, subject, or content..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="email">Email</SelectItem>
                <SelectItem value="whatsapp">WhatsApp</SelectItem>
                <SelectItem value="call">Call</SelectItem>
                <SelectItem value="meeting">Meeting</SelectItem>
              </SelectContent>
            </Select>
            <Select value={directionFilter} onValueChange={setDirectionFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Direction" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Directions</SelectItem>
                <SelectItem value="inbound">Inbound</SelectItem>
                <SelectItem value="outbound">Outbound</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Communication Logs Table */}
      {filteredLogs.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <MessageCircle className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No communications found</h3>
            <p className="text-muted-foreground text-center">
              Communication logs will appear here as you interact with your contacts.
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Recent Communications ({filteredLogs.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Direction</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getTypeIcon(log.communication_type)}
                        <span className="capitalize">{log.communication_type}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {log.contacts?.business_name || 
                       `${log.contacts?.first_name || ''} ${log.contacts?.last_name || ''}`}
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{log.subject || "No subject"}</div>
                        {log.content && (
                          <div className="text-sm text-muted-foreground truncate max-w-xs">
                            {log.content}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getDirectionIcon(log.direction)}
                        <span className="capitalize">{log.direction}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(log.status)}>
                        {log.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {format(new Date(log.created_at), "MMM d, yyyy HH:mm")}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
