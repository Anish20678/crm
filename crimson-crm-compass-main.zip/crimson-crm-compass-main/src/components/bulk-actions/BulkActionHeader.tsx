
import React from "react";
import { Checkbox } from "@/components/ui/checkbox";

interface BulkActionHeaderProps {
  selectedCount: number;
  totalCount: number;
  onSelectAll: () => void;
  onClearSelection: () => void;
}

export function BulkActionHeader({ 
  selectedCount, 
  totalCount, 
  onSelectAll, 
  onClearSelection 
}: BulkActionHeaderProps) {
  const isAllSelected = selectedCount === totalCount && totalCount > 0;
  const isIndeterminate = selectedCount > 0 && selectedCount < totalCount;

  const handleCheckboxChange = () => {
    if (isAllSelected || isIndeterminate) {
      onClearSelection();
    } else {
      onSelectAll();
    }
  };

  return (
    <Checkbox
      checked={isAllSelected}
      ref={(ref) => {
        if (ref) {
          // Access the underlying input element for indeterminate state
          const inputElement = ref.querySelector('input');
          if (inputElement) {
            inputElement.indeterminate = isIndeterminate;
          }
        }
      }}
      onCheckedChange={handleCheckboxChange}
      aria-label="Select all items"
    />
  );
}
