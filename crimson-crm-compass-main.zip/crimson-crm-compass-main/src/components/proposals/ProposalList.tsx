
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { FileText, Eye, Send, Edit, Trash2, Copy, Calendar, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";

interface Proposal {
  id: string;
  title: string;
  status: string;
  created_at: string;
  updated_at: string;
  sent_at?: string;
  viewed_at?: string;
  accepted_at?: string;
  contact_id?: string;
  contacts?: {
    first_name: string;
    last_name: string;
    company: string;
  };
  content: {
    sections?: Array<{
      id: string;
      type: string;
      title: string;
      content: string;
      order: number;
    }>;
  };
}

export function ProposalList() {
  const [selectedProposal, setSelectedProposal] = useState<Proposal | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data: proposals = [], isLoading } = useQuery({
    queryKey: ['proposals'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('proposals')
        .select(`
          *,
          contacts (
            first_name,
            last_name,
            company
          )
        `)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data as Proposal[];
    },
  });

  const deleteProposal = useMutation({
    mutationFn: async (proposalId: string) => {
      const { error } = await supabase
        .from('proposals')
        .delete()
        .eq('id', proposalId);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Proposal Deleted",
        description: "The proposal has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['proposals'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete proposal: " + error.message,
        variant: "destructive",
      });
    },
  });

  const duplicateProposal = useMutation({
    mutationFn: async (proposalId: string) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data: original, error: fetchError } = await supabase
        .from('proposals')
        .select('*')
        .eq('id', proposalId)
        .single();

      if (fetchError) throw fetchError;

      const { data, error } = await supabase
        .from('proposals')
        .insert({
          user_id: user.id,
          title: `Copy of ${original.title}`,
          content: original.content,
          brand_guidelines: original.brand_guidelines,
          contact_id: original.contact_id,
          status: 'draft',
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast({
        title: "Proposal Duplicated",
        description: "A copy of the proposal has been created.",
      });
      queryClient.invalidateQueries({ queryKey: ['proposals'] });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'secondary';
      case 'sent': return 'default';
      case 'viewed': return 'outline';
      case 'accepted': return 'default';
      case 'rejected': return 'destructive';
      default: return 'secondary';
    }
  };

  const getStatusIcon = (proposal: Proposal) => {
    if (proposal.accepted_at) return '✅';
    if (proposal.viewed_at) return '👁️';
    if (proposal.sent_at) return '📤';
    return '📝';
  };

  if (isLoading) {
    return <div className="text-center py-8">Loading proposals...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-semibold">My Proposals</h2>
          <p className="text-muted-foreground">Manage and track your proposals</p>
        </div>
        <Button onClick={() => navigate('/proposals')} className="gap-2">
          <Plus className="h-4 w-4" />
          New Proposal
        </Button>
      </div>

      {proposals.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Proposals Yet</h3>
            <p className="text-muted-foreground mb-4">
              Start creating your first proposal using the Proposal Builder.
            </p>
            <Button onClick={() => navigate('/proposals')}>
              <Plus className="h-4 w-4 mr-2" />
              Create First Proposal
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {proposals.map((proposal) => (
            <Card key={proposal.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <CardTitle className="text-lg line-clamp-2">{proposal.title}</CardTitle>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant={getStatusColor(proposal.status)}>
                        {getStatusIcon(proposal)} {proposal.status}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {proposal.contacts && (
                  <div>
                    <p className="text-sm font-medium">Client</p>
                    <p className="text-sm text-muted-foreground">
                      {proposal.contacts.first_name} {proposal.contacts.last_name}
                    </p>
                    <p className="text-sm text-muted-foreground">{proposal.contacts.company}</p>
                  </div>
                )}

                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    Created {format(new Date(proposal.created_at), 'MMM d, yyyy')}
                  </div>
                  {proposal.sent_at && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Send className="h-4 w-4" />
                      Sent {format(new Date(proposal.sent_at), 'MMM d, yyyy')}
                    </div>
                  )}
                  {proposal.viewed_at && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Eye className="h-4 w-4" />
                      Viewed {format(new Date(proposal.viewed_at), 'MMM d, yyyy')}
                    </div>
                  )}
                </div>

                <div className="flex gap-2 pt-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button size="sm" variant="outline" className="flex-1">
                        <Eye className="h-4 w-4 mr-1" />
                        View
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>{proposal.title}</DialogTitle>
                      </DialogHeader>
                      <div className="prose max-w-none">
                        {proposal.content?.sections?.map((section) => (
                          <div key={section.id} className="mb-6">
                            <h3 className="text-lg font-semibold mb-2">{section.title}</h3>
                            <div className="whitespace-pre-wrap text-sm text-muted-foreground">
                              {section.content || 'No content yet'}
                            </div>
                          </div>
                        ))}
                        {(!proposal.content?.sections || proposal.content.sections.length === 0) && (
                          <p className="text-muted-foreground">This proposal has no content yet.</p>
                        )}
                      </div>
                    </DialogContent>
                  </Dialog>
                  
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => navigate(`/proposals/edit/${proposal.id}`)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => duplicateProposal.mutate(proposal.id)}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                  
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => deleteProposal.mutate(proposal.id)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
