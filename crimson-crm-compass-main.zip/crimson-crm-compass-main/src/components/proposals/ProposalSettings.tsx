
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Settings } from "lucide-react";
import type { Contact } from "@/lib/types/core";

interface BrandGuidelines {
  id: string;
  name: string;
  colors: Record<string, string>;
  fonts: Record<string, string>;
  logo_url?: string;
  brand_voice?: string;
  is_default: boolean;
}

interface ProposalSettingsProps {
  proposal: {
    title: string;
    contact_id: string;
    brand_guidelines_id: string;
  };
  contacts: Contact[];
  brandGuidelines: BrandGuidelines[];
  onProposalChange: (updates: Partial<{ title: string; contact_id: string; brand_guidelines_id: string }>) => void;
}

export function ProposalSettings({ proposal, contacts, brandGuidelines, onProposalChange }: ProposalSettingsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="proposal-title">Proposal Title</Label>
          <Input
            id="proposal-title"
            placeholder="Enter proposal title"
            value={proposal.title}
            onChange={(e) => onProposalChange({ title: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="contact-select">Client</Label>
          <Select value={proposal.contact_id} onValueChange={(value) => 
            onProposalChange({ contact_id: value })
          }>
            <SelectTrigger>
              <SelectValue placeholder="Select client" />
            </SelectTrigger>
            <SelectContent>
              {contacts.map((contact) => (
                <SelectItem key={contact.id} value={contact.id}>
                  {contact.first_name} {contact.last_name} - {contact.company}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="brand-guidelines">Brand Guidelines</Label>
          <Select value={proposal.brand_guidelines_id} onValueChange={(value) => 
            onProposalChange({ brand_guidelines_id: value })
          }>
            <SelectTrigger>
              <SelectValue placeholder="Select brand guidelines" />
            </SelectTrigger>
            <SelectContent>
              {brandGuidelines.map((bg) => (
                <SelectItem key={bg.id} value={bg.id}>
                  {bg.name} {bg.is_default && "(Default)"}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardContent>
    </Card>
  );
}
