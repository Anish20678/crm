
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus } from "lucide-react";

interface AddSectionPanelProps {
  onAddSection: (type: string) => void;
}

export function AddSectionPanel({ onAddSection }: AddSectionPanelProps) {
  const sectionTypes = [
    { type: "executive_summary", label: "Executive Summary" },
    { type: "problem_statement", label: "Problem Statement" },
    { type: "solution_overview", label: "Solution Overview" },
    { type: "scope_of_work", label: "Scope of Work" },
    { type: "timeline", label: "Timeline" },
    { type: "pricing", label: "Pricing" },
    { type: "team", label: "Our Team" },
    { type: "testimonials", label: "Testimonials" },
    { type: "next_steps", label: "Next Steps" },
    { type: "custom", label: "Custom Section" },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Add Sections</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 gap-2">
          {sectionTypes.map((section) => (
            <Button
              key={section.type}
              variant="outline"
              size="sm"
              onClick={() => onAddSection(section.type)}
              className="justify-start text-sm"
            >
              <Plus className="h-3 w-3 mr-2" />
              {section.label}
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
