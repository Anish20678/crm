import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Save, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ProposalSettings } from "./ProposalSettings";
import { AddSectionPanel } from "./AddSectionPanel";
import { ProposalContent } from "./ProposalContent";
import type { Contact } from "@/lib/types/core";

interface ProposalSection {
  id: string;
  type: string;
  title: string;
  content: string;
  order: number;
}

interface BrandGuidelines {
  id: string;
  name: string;
  colors: Record<string, string>;
  fonts: Record<string, string>;
  logo_url?: string;
  brand_voice?: string;
  is_default: boolean;
}

interface ProposalEditorProps {
  proposalId?: string;
  onSave?: () => void;
}

export function ProposalEditor({ proposalId, onSave }: ProposalEditorProps) {
  const [proposal, setProposal] = useState({
    title: "",
    contact_id: "",
    sections: [] as ProposalSection[],
    brand_guidelines_id: "",
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch existing proposal if editing
  const { data: existingProposal, isLoading: isLoadingProposal } = useQuery({
    queryKey: ['proposal', proposalId],
    queryFn: async () => {
      if (!proposalId) return null;
      
      const { data, error } = await supabase
        .from('proposals')
        .select('*')
        .eq('id', proposalId)
        .single();
      
      if (error) throw error;
      return data;
    },
    enabled: !!proposalId,
  });

  // Load existing proposal data when it's fetched
  useEffect(() => {
    if (existingProposal && existingProposal.content) {
      const contentData = existingProposal.content as { sections?: ProposalSection[] };
      const brandGuidelinesData = existingProposal.brand_guidelines as { id?: string } | null;
      setProposal({
        title: existingProposal.title,
        contact_id: existingProposal.contact_id || "",
        sections: contentData.sections || [],
        brand_guidelines_id: brandGuidelinesData?.id || "",
      });
    }
  }, [existingProposal]);

  // Fetch contacts
  const { data: contacts = [] } = useQuery({
    queryKey: ['contacts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('contacts')
        .select('id, first_name, last_name, company, email')
        .order('first_name');
      
      if (error) throw error;
      return data as Contact[];
    },
  });

  // Fetch brand guidelines
  const { data: brandGuidelines = [] } = useQuery({
    queryKey: ['brand-guidelines'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('brand_guidelines')
        .select('*')
        .order('is_default', { ascending: false });
      
      if (error) throw error;
      return data as BrandGuidelines[];
    },
  });

  // Save proposal mutation
  const saveProposal = useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      setIsSaving(true);

      const proposalData = {
        user_id: user.id,
        title: proposal.title,
        contact_id: proposal.contact_id || null,
        content: JSON.parse(JSON.stringify({ sections: proposal.sections })),
        status: 'draft',
      };

      let result;
      if (proposalId) {
        // Update existing proposal
        const { data, error } = await supabase
          .from('proposals')
          .update(proposalData)
          .eq('id', proposalId)
          .select()
          .single();
        
        if (error) throw error;
        result = data;
      } else {
        // Create new proposal
        const { data, error } = await supabase
          .from('proposals')
          .insert(proposalData)
          .select()
          .single();

        if (error) throw error;
        result = data;
      }

      return result;
    },
    onSuccess: (data) => {
      setIsSaving(false);
      toast({
        title: proposalId ? "Proposal Updated" : "Proposal Saved",
        description: `Your proposal has been ${proposalId ? 'updated' : 'saved'} successfully.`,
      });
      queryClient.invalidateQueries({ queryKey: ['proposals'] });
      if (onSave) onSave();
    },
    onError: (error) => {
      setIsSaving(false);
      toast({
        title: "Error",
        description: "Failed to save proposal: " + error.message,
        variant: "destructive",
      });
    },
  });

  const addSection = (type: string) => {
    const newSection: ProposalSection = {
      id: Date.now().toString(),
      type,
      title: getSectionTitle(type),
      content: "",
      order: proposal.sections.length,
    };
    setProposal(prev => ({
      ...prev,
      sections: [...prev.sections, newSection],
    }));
  };

  const getSectionTitle = (type: string) => {
    const titles = {
      executive_summary: "Executive Summary",
      problem_statement: "Problem Statement", 
      solution_overview: "Solution Overview",
      scope_of_work: "Scope of Work",
      timeline: "Project Timeline",
      pricing: "Investment & Pricing",
      team: "Our Team",
      testimonials: "Client Testimonials",
      next_steps: "Next Steps",
      custom: "Custom Section",
    };
    return titles[type as keyof typeof titles] || "New Section";
  };

  const updateSection = (id: string, field: string, value: string) => {
    setProposal(prev => ({
      ...prev,
      sections: prev.sections.map(section =>
        section.id === id ? { ...section, [field]: value } : section
      ),
    }));
  };

  const removeSection = (id: string) => {
    setProposal(prev => ({
      ...prev,
      sections: prev.sections.filter(section => section.id !== id),
    }));
  };

  const moveSection = (id: string, direction: 'up' | 'down') => {
    setProposal(prev => {
      const sections = [...prev.sections];
      const index = sections.findIndex(section => section.id === id);
      
      if (index === -1) return prev;
      
      const newIndex = direction === 'up' ? index - 1 : index + 1;
      
      if (newIndex < 0 || newIndex >= sections.length) return prev;
      
      // Swap sections
      [sections[index], sections[newIndex]] = [sections[newIndex], sections[index]];
      
      // Update order
      sections.forEach((section, idx) => {
        section.order = idx;
      });
      
      return { ...prev, sections };
    });
  };

  const generateAIContent = async (sectionId: string, aiPrompt: string) => {
    if (!aiPrompt.trim()) {
      toast({
        title: "Missing Prompt",
        description: "Please enter a prompt for AI content generation.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    try {
      const selectedContact = contacts.find(c => c.id === proposal.contact_id);
      const selectedBrandGuidelines = brandGuidelines.find(bg => bg.id === proposal.brand_guidelines_id);
      
      const context = selectedContact 
        ? `Client: ${selectedContact.first_name} ${selectedContact.last_name} from ${selectedContact.company}`
        : "";

      const { data, error } = await supabase.functions.invoke('ai-proposal-generator', {
        body: {
          prompt: aiPrompt,
          context,
          brandGuidelines: selectedBrandGuidelines,
        },
      });

      if (error) throw error;

      if (data && data.content) {
        updateSection(sectionId, 'content', data.content);

        toast({
          title: "Content Generated",
          description: "AI has generated content for your section.",
        });
      } else {
        throw new Error("No content generated");
      }
    } catch (error) {
      console.error('AI Generation Error:', error);
      toast({
        title: "Generation Failed",
        description: "Failed to generate AI content. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleProposalChange = (updates: Partial<{ title: string; contact_id: string; brand_guidelines_id: string }>) => {
    setProposal(prev => ({ ...prev, ...updates }));
  };

  if (isLoadingProposal) {
    return <div className="text-center py-8">Loading proposal...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-semibold">
            {proposalId ? 'Edit Proposal' : 'Proposal Builder'}
          </h2>
          <p className="text-muted-foreground">
            {proposalId ? 'Update your proposal' : 'Create professional proposals with AI assistance'}
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => saveProposal.mutate()}
            disabled={isSaving}
          >
            <Save className="h-4 w-4 mr-2" />
            {isSaving ? 'Saving...' : 'Save Draft'}
          </Button>
          <Button disabled={!proposal.title || proposal.sections.length === 0}>
            <Send className="h-4 w-4 mr-2" />
            Send Proposal
          </Button>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-6">
        {/* Sidebar - Settings */}
        <div className="lg:col-span-1 space-y-4">
          <ProposalSettings
            proposal={proposal}
            contacts={contacts}
            brandGuidelines={brandGuidelines}
            onProposalChange={handleProposalChange}
          />
          <AddSectionPanel onAddSection={addSection} />
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          <ProposalContent
            proposal={proposal}
            onUpdateSection={updateSection}
            onMoveSection={moveSection}
            onRemoveSection={removeSection}
            onGenerateAIContent={generateAIContent}
            isGenerating={isGenerating}
          />
        </div>
      </div>
    </div>
  );
}
