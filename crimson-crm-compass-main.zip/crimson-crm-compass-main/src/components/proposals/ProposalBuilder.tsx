
import { ProposalEditor } from "./ProposalEditor";

export function ProposalBuilder() {
  return <ProposalEditor />;
}
