
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText } from "lucide-react";
import { ProposalSection } from "./ProposalSection";

interface ProposalSection {
  id: string;
  type: string;
  title: string;
  content: string;
  order: number;
}

interface ProposalContentProps {
  proposal: {
    title: string;
    sections: ProposalSection[];
  };
  onUpdateSection: (id: string, field: string, value: string) => void;
  onMoveSection: (id: string, direction: 'up' | 'down') => void;
  onRemoveSection: (id: string) => void;
  onGenerateAIContent: (sectionId: string, prompt: string) => Promise<void>;
  isGenerating: boolean;
}

export function ProposalContent({
  proposal,
  onUpdateSection,
  onMoveSection,
  onRemoveSection,
  onGenerateAIContent,
  isGenerating
}: ProposalContentProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          {proposal.title || "Untitled Proposal"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {proposal.sections.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Start building your proposal by adding sections from the sidebar.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {proposal.sections.map((section, index) => (
              <ProposalSection
                key={section.id}
                section={section}
                index={index}
                totalSections={proposal.sections.length}
                onUpdateSection={onUpdateSection}
                onMoveSection={onMoveSection}
                onRemoveSection={onRemoveSection}
                onGenerateAIContent={onGenerateAIContent}
                isGenerating={isGenerating}
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
