
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Wand2 } from "lucide-react";

interface AIContentDialogProps {
  onGenerateContent: (prompt: string) => Promise<void>;
  isGenerating: boolean;
}

export function AIContentDialog({ onGenerateContent, isGenerating }: AIContentDialogProps) {
  const [aiPrompt, setAiPrompt] = useState("");

  const handleGenerate = async () => {
    await onGenerateContent(aiPrompt);
    setAiPrompt("");
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline">
          <Wand2 className="h-4 w-4" />
          AI Generate
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Generate AI Content</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <Textarea
            placeholder="Describe what you want the AI to generate for this section..."
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
            rows={4}
          />
          <div className="flex gap-2">
            <Button 
              onClick={handleGenerate}
              disabled={isGenerating || !aiPrompt.trim()}
            >
              {isGenerating ? "Generating..." : "Generate Content"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
