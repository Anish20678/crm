
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Palette, Plus, Edit, Trash2, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

interface BrandGuidelines {
  id: string;
  name: string;
  colors: Record<string, string>;
  fonts: Record<string, string>;
  logo_url?: string;
  brand_voice?: string;
  is_default: boolean;
  created_at: string;
}

export function BrandGuidelinesManager() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingGuideline, setEditingGuideline] = useState<BrandGuidelines | null>(null);
  const [newGuideline, setNewGuideline] = useState({
    name: "",
    brand_voice: "",
    logo_url: "",
    colors: {
      primary: "#3b82f6",
      secondary: "#64748b",
      accent: "#10b981",
    },
    fonts: {
      heading: "Inter",
      body: "Inter",
    },
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: guidelines = [] } = useQuery({
    queryKey: ['brand-guidelines'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('brand_guidelines')
        .select('*')
        .order('is_default', { ascending: false });
      
      if (error) throw error;
      return data as BrandGuidelines[];
    },
  });

  const createGuideline = useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('brand_guidelines')
        .insert({
          user_id: user.id,
          name: newGuideline.name,
          brand_voice: newGuideline.brand_voice,
          logo_url: newGuideline.logo_url,
          colors: newGuideline.colors,
          fonts: newGuideline.fonts,
          is_default: guidelines.length === 0, // First guideline becomes default
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast({
        title: "Brand Guidelines Created",
        description: "Your brand guidelines have been saved successfully.",
      });
      setNewGuideline({
        name: "",
        brand_voice: "",
        logo_url: "",
        colors: { primary: "#3b82f6", secondary: "#64748b", accent: "#10b981" },
        fonts: { heading: "Inter", body: "Inter" },
      });
      setIsCreateDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ['brand-guidelines'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create brand guidelines: " + error.message,
        variant: "destructive",
      });
    },
  });

  const setAsDefault = useMutation({
    mutationFn: async (guidelineId: string) => {
      // First, unset all defaults
      await supabase
        .from('brand_guidelines')
        .update({ is_default: false })
        .neq('id', '');

      // Then set the selected one as default
      const { error } = await supabase
        .from('brand_guidelines')
        .update({ is_default: true })
        .eq('id', guidelineId);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Default Updated",
        description: "Default brand guidelines have been updated.",
      });
      queryClient.invalidateQueries({ queryKey: ['brand-guidelines'] });
    },
  });

  const deleteGuideline = useMutation({
    mutationFn: async (guidelineId: string) => {
      const { error } = await supabase
        .from('brand_guidelines')
        .delete()
        .eq('id', guidelineId);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Brand Guidelines Deleted",
        description: "Brand guidelines have been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['brand-guidelines'] });
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-semibold">Brand Guidelines</h2>
          <p className="text-muted-foreground">Manage your brand identity for consistent proposals</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Create Guidelines
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Brand Guidelines</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="guideline-name">Guidelines Name</Label>
                <Input
                  id="guideline-name"
                  placeholder="Company Brand Guidelines"
                  value={newGuideline.name}
                  onChange={(e) => setNewGuideline({...newGuideline, name: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="brand-voice">Brand Voice</Label>
                <Textarea
                  id="brand-voice"
                  placeholder="Describe your brand's tone and voice (e.g., Professional yet approachable, confident, innovative...)"
                  value={newGuideline.brand_voice}
                  onChange={(e) => setNewGuideline({...newGuideline, brand_voice: e.target.value})}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="logo-url">Logo URL</Label>
                <Input
                  id="logo-url"
                  placeholder="https://example.com/logo.png"
                  value={newGuideline.logo_url}
                  onChange={(e) => setNewGuideline({...newGuideline, logo_url: e.target.value})}
                />
              </div>

              <div className="space-y-4">
                <Label>Brand Colors</Label>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="primary-color">Primary</Label>
                    <div className="flex gap-2">
                      <Input
                        id="primary-color"
                        type="color"
                        value={newGuideline.colors.primary}
                        onChange={(e) => setNewGuideline({
                          ...newGuideline,
                          colors: { ...newGuideline.colors, primary: e.target.value }
                        })}
                        className="w-12 h-10 p-1"
                      />
                      <Input
                        value={newGuideline.colors.primary}
                        onChange={(e) => setNewGuideline({
                          ...newGuideline,
                          colors: { ...newGuideline.colors, primary: e.target.value }
                        })}
                        className="flex-1"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="secondary-color">Secondary</Label>
                    <div className="flex gap-2">
                      <Input
                        id="secondary-color"
                        type="color"
                        value={newGuideline.colors.secondary}
                        onChange={(e) => setNewGuideline({
                          ...newGuideline,
                          colors: { ...newGuideline.colors, secondary: e.target.value }
                        })}
                        className="w-12 h-10 p-1"
                      />
                      <Input
                        value={newGuideline.colors.secondary}
                        onChange={(e) => setNewGuideline({
                          ...newGuideline,
                          colors: { ...newGuideline.colors, secondary: e.target.value }
                        })}
                        className="flex-1"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="accent-color">Accent</Label>
                    <div className="flex gap-2">
                      <Input
                        id="accent-color"
                        type="color"
                        value={newGuideline.colors.accent}
                        onChange={(e) => setNewGuideline({
                          ...newGuideline,
                          colors: { ...newGuideline.colors, accent: e.target.value }
                        })}
                        className="w-12 h-10 p-1"
                      />
                      <Input
                        value={newGuideline.colors.accent}
                        onChange={(e) => setNewGuideline({
                          ...newGuideline,
                          colors: { ...newGuideline.colors, accent: e.target.value }
                        })}
                        className="flex-1"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <Label>Typography</Label>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="heading-font">Heading Font</Label>
                    <Input
                      id="heading-font"
                      placeholder="Inter, Arial, sans-serif"
                      value={newGuideline.fonts.heading}
                      onChange={(e) => setNewGuideline({
                        ...newGuideline,
                        fonts: { ...newGuideline.fonts, heading: e.target.value }
                      })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="body-font">Body Font</Label>
                    <Input
                      id="body-font"
                      placeholder="Inter, Arial, sans-serif"
                      value={newGuideline.fonts.body}
                      onChange={(e) => setNewGuideline({
                        ...newGuideline,
                        fonts: { ...newGuideline.fonts, body: e.target.value }
                      })}
                    />
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <Button onClick={() => createGuideline.mutate()}>
                  Create Guidelines
                </Button>
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {guidelines.map((guideline) => (
          <Card key={guideline.id} className={guideline.is_default ? "border-primary" : ""}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{guideline.name}</CardTitle>
                  <div className="flex gap-2 mt-2">
                    {guideline.is_default && (
                      <Badge variant="default" className="flex items-center gap-1">
                        <Star className="h-3 w-3" />
                        Default
                      </Badge>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {!guideline.is_default && (
                    <Button 
                      size="sm" 
                      variant="outline" 
                      onClick={() => setAsDefault.mutate(guideline.id)}
                      className="h-8 w-8 p-0"
                    >
                      <Star className="h-4 w-4" />
                    </Button>
                  )}
                  <Button size="sm" variant="outline" className="h-8 w-8 p-0">
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => deleteGuideline.mutate(guideline.id)}
                    className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {guideline.brand_voice && (
                <div>
                  <Label className="text-sm font-medium">Brand Voice</Label>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                    {guideline.brand_voice}
                  </p>
                </div>
              )}

              <div>
                <Label className="text-sm font-medium">Colors</Label>
                <div className="flex gap-2 mt-2">
                  {Object.entries(guideline.colors).map(([name, color]) => (
                    <div key={name} className="flex flex-col items-center gap-1">
                      <div 
                        className="w-8 h-8 rounded border"
                        style={{ backgroundColor: color }}
                      />
                      <span className="text-xs text-muted-foreground capitalize">{name}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium">Typography</Label>
                <div className="mt-2 space-y-1">
                  <p className="text-sm" style={{ fontFamily: guideline.fonts.heading }}>
                    {guideline.fonts.heading} (Heading)
                  </p>
                  <p className="text-sm text-muted-foreground" style={{ fontFamily: guideline.fonts.body }}>
                    {guideline.fonts.body} (Body)
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {guidelines.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Palette className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Brand Guidelines</h3>
            <p className="text-muted-foreground mb-4">
              Create your first brand guidelines to ensure consistent proposal designs.
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Guidelines
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
