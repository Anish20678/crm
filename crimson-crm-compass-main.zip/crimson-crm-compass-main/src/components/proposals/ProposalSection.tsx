
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { ArrowUp, ArrowDown, Trash2 } from "lucide-react";
import { AIContentDialog } from "./AIContentDialog";

interface ProposalSection {
  id: string;
  type: string;
  title: string;
  content: string;
  order: number;
}

interface ProposalSectionProps {
  section: ProposalSection;
  index: number;
  totalSections: number;
  onUpdateSection: (id: string, field: string, value: string) => void;
  onMoveSection: (id: string, direction: 'up' | 'down') => void;
  onRemoveSection: (id: string) => void;
  onGenerateAIContent: (sectionId: string, prompt: string) => Promise<void>;
  isGenerating: boolean;
}

export function ProposalSection({
  section,
  index,
  totalSections,
  onUpdateSection,
  onMoveSection,
  onRemoveSection,
  onGenerateAIContent,
  isGenerating
}: ProposalSectionProps) {
  const handleGenerateContent = async (prompt: string) => {
    await onGenerateAIContent(section.id, prompt);
  };

  return (
    <Card className="border-l-4 border-l-blue-500">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex-1 space-y-2">
            <Input
              value={section.title}
              onChange={(e) => onUpdateSection(section.id, 'title', e.target.value)}
              className="font-semibold text-lg border-none p-0 h-auto focus-visible:ring-0"
              placeholder="Section title"
            />
            <Badge variant="secondary">{section.type.replace('_', ' ')}</Badge>
          </div>
          <div className="flex gap-2">
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => onMoveSection(section.id, 'up')}
              disabled={index === 0}
            >
              <ArrowUp className="h-4 w-4" />
            </Button>
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => onMoveSection(section.id, 'down')}
              disabled={index === totalSections - 1}
            >
              <ArrowDown className="h-4 w-4" />
            </Button>
            <AIContentDialog 
              onGenerateContent={handleGenerateContent}
              isGenerating={isGenerating}
            />
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => onRemoveSection(section.id)}
              className="text-destructive hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Textarea
          value={section.content}
          onChange={(e) => onUpdateSection(section.id, 'content', e.target.value)}
          placeholder="Enter section content..."
          rows={8}
          className="min-h-[200px]"
        />
      </CardContent>
    </Card>
  );
}
