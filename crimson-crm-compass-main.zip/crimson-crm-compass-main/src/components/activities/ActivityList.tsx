
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Activity } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { 
  Phone, 
  Mail, 
  FileText, 
  Calendar,
  MessageSquare,
  User,
  DollarSign,
  CheckSquare,
  Edit,
  Clock,
  MapPin,
  Users,
  Tag,
  ArrowRight
} from "lucide-react";

interface ActivityListProps {
  filter?: string;
  relatedTo?: {
    type: string;
    id: string;
  };
  limit?: number;
}

export function ActivityList({ filter = "all", relatedTo, limit }: ActivityListProps) {
  const { data: activities = [], isLoading } = useQuery({
    queryKey: ["activities", filter, relatedTo],
    queryFn: async (): Promise<Activity[]> => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      let query = supabase
        .from("activities")
        .select("*")
        .eq("user_id", user.id)
        .order("activity_date", { ascending: false });

      if (filter && filter !== "all") {
        query = query.eq("activity_type", filter);
      }

      if (relatedTo) {
        query = query.eq("related_to_type", relatedTo.type).eq("related_to_id", relatedTo.id);
      }

      if (limit) {
        query = query.limit(limit);
      } else {
        query = query.limit(50);
      }

      const { data, error } = await query;

      if (error) throw error;
      return data || [];
    },
  });

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'call':
        return <Phone className="h-4 w-4" />;
      case 'email':
        return <Mail className="h-4 w-4" />;
      case 'note':
        return <FileText className="h-4 w-4" />;
      case 'meeting':
        return <Calendar className="h-4 w-4" />;
      case 'message':
        return <MessageSquare className="h-4 w-4" />;
      case 'contact':
        return <User className="h-4 w-4" />;
      case 'deal':
        return <DollarSign className="h-4 w-4" />;
      case 'task':
        return <CheckSquare className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'call':
        return 'bg-blue-100 text-blue-800';
      case 'email':
        return 'bg-green-100 text-green-800';
      case 'note':
        return 'bg-gray-100 text-gray-800';
      case 'meeting':
        return 'bg-purple-100 text-purple-800';
      case 'message':
        return 'bg-yellow-100 text-yellow-800';
      case 'contact':
        return 'bg-indigo-100 text-indigo-800';
      case 'deal':
        return 'bg-emerald-100 text-emerald-800';
      case 'task':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Activities</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-full"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>
          {relatedTo ? "Related Activities" : "Recent Activities"}
          {filter !== "all" && (
            <Badge variant="secondary" className="ml-2 capitalize">
              {filter}
            </Badge>
          )}
        </CardTitle>
        {!relatedTo && (
          <Button variant="outline" size="sm" asChild>
            <Link to="/activities/add">
              Add Activity
            </Link>
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {activities.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <p>No activities yet</p>
            <p className="text-sm">Activities will appear here as you use the CRM</p>
            {!relatedTo && (
              <Button className="mt-4" asChild>
                <Link to="/activities/add">Create Your First Activity</Link>
              </Button>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {activities.map((activity) => (
              <div key={activity.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3 flex-1">
                    <div className={`p-2 rounded-full ${getActivityColor(activity.activity_type)}`}>
                      {getActivityIcon(activity.activity_type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{activity.title}</h4>
                        <span className="text-sm text-gray-500">
                          {activity.activity_date 
                            ? format(new Date(activity.activity_date), 'MMM d, h:mm a')
                            : format(new Date(activity.created_at || ''), 'MMM d, h:mm a')
                          }
                        </span>
                      </div>
                      
                      {activity.description && (
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">{activity.description}</p>
                      )}

                      <div className="flex flex-wrap items-center gap-2 mb-3">
                        <Badge variant="secondary" className="text-xs capitalize">
                          {activity.activity_type}
                        </Badge>
                        {activity.related_to_type && (
                          <Badge variant="outline" className="text-xs capitalize">
                            {activity.related_to_type}
                          </Badge>
                        )}
                      </div>

                      {/* Enhanced metadata */}
                      <div className="flex flex-wrap items-center gap-4 text-xs text-gray-500">
                        {activity.duration_minutes && (
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {activity.duration_minutes}m
                          </div>
                        )}
                        {activity.location && (
                          <div className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {activity.location}
                          </div>
                        )}
                        {activity.participants && activity.participants.length > 0 && (
                          <div className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            {activity.participants.length} participant{activity.participants.length > 1 ? 's' : ''}
                          </div>
                        )}
                        {activity.tags && activity.tags.length > 0 && (
                          <div className="flex items-center gap-1">
                            <Tag className="h-3 w-3" />
                            {activity.tags.join(', ')}
                          </div>
                        )}
                      </div>

                      {activity.outcome && (
                        <div className="mt-3 p-2 bg-gray-50 rounded text-sm">
                          <p className="text-gray-600 font-medium mb-1">Outcome:</p>
                          <p className="text-gray-700">{activity.outcome}</p>
                        </div>
                      )}

                      {activity.follow_up_required && (
                        <div className="mt-2 flex items-center gap-1 text-orange-600 text-sm">
                          <ArrowRight className="h-3 w-3" />
                          Follow-up required
                          {activity.follow_up_date && (
                            <span className="ml-1">
                              by {format(new Date(activity.follow_up_date), 'MMM d, yyyy')}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" asChild>
                    <Link to={`/activities/edit/${activity.id}`}>
                      <Edit className="h-3 w-3" />
                    </Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
