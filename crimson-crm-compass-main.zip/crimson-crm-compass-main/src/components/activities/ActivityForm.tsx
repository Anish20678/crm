import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ArrowLeft, Save, Plus, X } from "lucide-react";

interface ActivityFormProps {
  activityId?: string;
  relatedTo?: {
    type: string;
    id: string;
    name: string;
  };
}

export function ActivityForm({ activityId, relatedTo }: ActivityFormProps) {
  const navigate = useNavigate();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    activity_type: "note",
    activity_date: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
    duration_minutes: "",
    location: "",
    outcome: "",
    follow_up_required: false,
    follow_up_date: "",
    related_to_type: relatedTo?.type || "",
    related_to_id: relatedTo?.id || "",
  });

  const [participants, setParticipants] = useState<string[]>([]);
  const [tags, setTags] = useState<string[]>([]);
  const [newParticipant, setNewParticipant] = useState("");
  const [newTag, setNewTag] = useState("");

  // Fetch activity data if editing
  const { data: activity, isLoading } = useQuery({
    queryKey: ["activity", activityId],
    queryFn: async () => {
      if (!activityId) return null;
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from("activities")
        .select("*")
        .eq("id", activityId)
        .eq("user_id", user.id)
        .single();

      if (error) throw error;
      return data;
    },
    enabled: !!activityId,
  });

  // Fetch contacts and deals for related to options
  const { data: relatedOptions } = useQuery({
    queryKey: ["related-options"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const [contactsRes, dealsRes] = await Promise.all([
        supabase.from("contacts").select("id, first_name, last_name, company").eq("user_id", user.id),
        supabase.from("deals").select("id, name, contact_id").eq("contact_id", user.id)
      ]);

      return {
        contacts: contactsRes.data || [],
        deals: dealsRes.data || []
      };
    },
  });

  // Change starts here -- useEffect instead of useState
  useEffect(() => {
    if (activity) {
      setFormData({
        title: activity.title,
        description: activity.description || "",
        activity_type: activity.activity_type,
        activity_date: activity.activity_date ? format(new Date(activity.activity_date), "yyyy-MM-dd'T'HH:mm") : "",
        duration_minutes: activity.duration_minutes?.toString() || "",
        location: activity.location || "",
        outcome: activity.outcome || "",
        follow_up_required: activity.follow_up_required || false,
        follow_up_date: activity.follow_up_date ? format(new Date(activity.follow_up_date), "yyyy-MM-dd'T'HH:mm") : "",
        related_to_type: activity.related_to_type,
        related_to_id: activity.related_to_id,
      });
      setParticipants(activity.participants || []);
      setTags(activity.tags || []);
    }
  }, [activity]);
  // Change ends here

  const saveMutation = useMutation({
    mutationFn: async (data: any) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const activityData = {
        ...data,
        user_id: user.id,
        participants,
        tags,
        duration_minutes: data.duration_minutes ? parseInt(data.duration_minutes) : null,
        activity_date: data.activity_date ? new Date(data.activity_date).toISOString() : null,
        follow_up_date: data.follow_up_date ? new Date(data.follow_up_date).toISOString() : null,
      };

      if (activityId) {
        const { data: result, error } = await supabase
          .from("activities")
          .update(activityData)
          .eq("id", activityId)
          .eq("user_id", user.id)
          .select()
          .single();
        if (error) throw error;
        return result;
      } else {
        const { data: result, error } = await supabase
          .from("activities")
          .insert(activityData)
          .select()
          .single();
        if (error) throw error;
        return result;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["activities"] });
      toast({
        title: "Success",
        description: `Activity ${activityId ? "updated" : "created"} successfully`,
      });
      navigate("/activities");
    },
    onError: (error) => {
      console.error("Save error:", error);
      toast({
        title: "Error",
        description: `Failed to ${activityId ? "update" : "create"} activity`,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  const addParticipant = () => {
    if (newParticipant.trim() && !participants.includes(newParticipant.trim())) {
      setParticipants([...participants, newParticipant.trim()]);
      setNewParticipant("");
    }
  };

  const addTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags([...tags, newTag.trim()]);
      setNewTag("");
    }
  };

  const removeParticipant = (participant: string) => {
    setParticipants(participants.filter(p => p !== participant));
  };

  const removeTag = (tag: string) => {
    setTags(tags.filter(t => t !== tag));
  };

  if (isLoading) {
    return <div className="flex justify-center p-8">Loading...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" onClick={() => navigate("/activities")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Activities
        </Button>
        <h1 className="text-2xl font-bold">
          {activityId ? "Edit Activity" : "Create New Activity"}
        </h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Activity Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="activity_type">Activity Type *</Label>
                <Select
                  value={formData.activity_type}
                  onValueChange={(value) => setFormData({ ...formData, activity_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="call">Call</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="meeting">Meeting</SelectItem>
                    <SelectItem value="note">Note</SelectItem>
                    <SelectItem value="task">Task</SelectItem>
                    <SelectItem value="demo">Demo</SelectItem>
                    <SelectItem value="proposal">Proposal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={4}
              />
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="activity_date">Date & Time</Label>
                <Input
                  id="activity_date"
                  type="datetime-local"
                  value={formData.activity_date}
                  onChange={(e) => setFormData({ ...formData, activity_date: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="duration_minutes">Duration (minutes)</Label>
                <Input
                  id="duration_minutes"
                  type="number"
                  value={formData.duration_minutes}
                  onChange={(e) => setFormData({ ...formData, duration_minutes: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="Office, Online, etc."
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Participants & Tags</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Participants</Label>
              <div className="flex gap-2">
                <Input
                  value={newParticipant}
                  onChange={(e) => setNewParticipant(e.target.value)}
                  placeholder="Add participant name or email"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addParticipant())}
                />
                <Button type="button" onClick={addParticipant}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {participants.map((participant, index) => (
                  <Badge key={index} variant="secondary" className="flex items-center gap-1">
                    {participant}
                    <X
                      className="h-3 w-3 cursor-pointer"
                      onClick={() => removeParticipant(participant)}
                    />
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Tags</Label>
              <div className="flex gap-2">
                <Input
                  value={newTag}
                  onChange={(e) => setNewTag(e.target.value)}
                  placeholder="Add tag"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                />
                <Button type="button" onClick={addTag}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {tags.map((tag, index) => (
                  <Badge key={index} variant="outline" className="flex items-center gap-1">
                    {tag}
                    <X
                      className="h-3 w-3 cursor-pointer"
                      onClick={() => removeTag(tag)}
                    />
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Follow-up & Outcome</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="outcome">Outcome</Label>
              <Textarea
                id="outcome"
                value={formData.outcome}
                onChange={(e) => setFormData({ ...formData, outcome: e.target.value })}
                placeholder="What was accomplished or decided?"
                rows={3}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.follow_up_required}
                onCheckedChange={(checked) => setFormData({ ...formData, follow_up_required: checked })}
              />
              <Label>Follow-up required</Label>
            </div>

            {formData.follow_up_required && (
              <div className="space-y-2">
                <Label htmlFor="follow_up_date">Follow-up Date</Label>
                <Input
                  id="follow_up_date"
                  type="datetime-local"
                  value={formData.follow_up_date}
                  onChange={(e) => setFormData({ ...formData, follow_up_date: e.target.value })}
                />
              </div>
            )}
          </CardContent>
        </Card>

        <div className="flex justify-end gap-4">
          <Button type="button" variant="outline" onClick={() => navigate("/activities")}>
            Cancel
          </Button>
          <Button type="submit" disabled={saveMutation.isPending}>
            <Save className="h-4 w-4 mr-2" />
            {saveMutation.isPending ? "Saving..." : "Save Activity"}
          </Button>
        </div>
      </form>
    </div>
  );
}
