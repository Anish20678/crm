
import React from "react";
import { format } from "date-fns";
import { Eye, Edit, Trash2, CheckSquare } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Task } from "@/lib/types";
import { Column, ColumnManager } from "@/components/contacts/ColumnManager";

interface TaskWithDeal extends Task {
  deals?: {
    id: string;
    name: string;
    status: string;
    amount: number | null;
    contacts: {
      first_name: string;
      last_name: string;
      company: string | null;
    };
  } | null;
}

interface TaskListProps {
  tasks: TaskWithDeal[];
  isLoading: boolean;
  onView: (task: Task) => void;
  onEdit: (task: Task) => void;
  onDelete: (task: Task) => void;
  onComplete: (task: Task) => void;
  isColumnManagerOpen: boolean;
  onColumnManagerOpenChange: (open: boolean) => void;
}

export function TaskList({
  tasks,
  isLoading,
  onView,
  onEdit,
  onDelete,
  onComplete,
  isColumnManagerOpen,
  onColumnManagerOpenChange,
}: TaskListProps) {
  const [columns, setColumns] = React.useState<Column[]>([
    { id: "title", label: "Title", visible: true },
    { id: "status", label: "Status", visible: true },
    { id: "priority", label: "Priority", visible: true },
    { id: "dueDate", label: "Due Date", visible: true },
    { id: "deal", label: "Related Deal", visible: true },
    { id: "relatedTo", label: "Related To", visible: true },
    { id: "assignedTo", label: "Assigned To", visible: true },
    { id: "actions", label: "Actions", visible: true },
  ]);

  const handleColumnChange = (newColumns: Column[]) => {
    setColumns(newColumns);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500 text-white";
      case "medium":
        return "bg-yellow-500 text-black";
      case "low":
        return "bg-green-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "todo":
        return "bg-blue-500 text-white";
      case "in_progress":
        return "bg-yellow-500 text-black";
      case "waiting_for_client":
        return "bg-orange-500 text-white";
      case "ready_for_review":
        return "bg-purple-500 text-white";
      case "completed":
        return "bg-green-500 text-white";
      case "cancelled":
        return "bg-gray-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "todo":
        return "To Do";
      case "in_progress":
        return "In Progress";
      case "waiting_for_client":
        return "Waiting for Client";
      case "ready_for_review":
        return "Ready for Review";
      case "completed":
        return "Completed";
      case "cancelled":
        return "Cancelled";
      default:
        return status.charAt(0).toUpperCase() + status.slice(1);
    }
  };

  if (isLoading) {
    return <div className="text-center py-8">Loading tasks...</div>;
  }

  if (tasks.length === 0) {
    return (
      <div className="text-center py-8">
        No tasks found. Create your first task by clicking "Add Task".
      </div>
    );
  }

  const visibleColumns = columns.filter((col) => col.visible);

  return (
    <>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              {columns.find((c) => c.id === "title" && c.visible) && (
                <TableHead>Title</TableHead>
              )}
              {columns.find((c) => c.id === "status" && c.visible) && (
                <TableHead>Status</TableHead>
              )}
              {columns.find((c) => c.id === "priority" && c.visible) && (
                <TableHead>Priority</TableHead>
              )}
              {columns.find((c) => c.id === "dueDate" && c.visible) && (
                <TableHead>Due Date</TableHead>
              )}
              {columns.find((c) => c.id === "deal" && c.visible) && (
                <TableHead>Related Deal</TableHead>
              )}
              {columns.find((c) => c.id === "relatedTo" && c.visible) && (
                <TableHead>Related To</TableHead>
              )}
              {columns.find((c) => c.id === "assignedTo" && c.visible) && (
                <TableHead>Assigned To</TableHead>
              )}
              {columns.find((c) => c.id === "actions" && c.visible) && (
                <TableHead className="text-right">Actions</TableHead>
              )}
            </TableRow>
          </TableHeader>
          <TableBody>
            {tasks.map((task) => (
              <TableRow key={task.id}>
                {columns.find((c) => c.id === "title" && c.visible) && (
                  <TableCell className="font-medium">{task.title}</TableCell>
                )}
                {columns.find((c) => c.id === "status" && c.visible) && (
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={getStatusColor(task.status)}
                    >
                      {getStatusLabel(task.status)}
                    </Badge>
                  </TableCell>
                )}
                {columns.find((c) => c.id === "priority" && c.visible) && (
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={getPriorityColor(task.priority)}
                    >
                      {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                    </Badge>
                  </TableCell>
                )}
                {columns.find((c) => c.id === "dueDate" && c.visible) && (
                  <TableCell>
                    {task.due_date
                      ? format(new Date(task.due_date), "MMM d, yyyy")
                      : "—"}
                  </TableCell>
                )}
                {columns.find((c) => c.id === "deal" && c.visible) && (
                  <TableCell>
                    {task.deals ? (
                      <div className="flex flex-col">
                        <span className="font-medium text-sm">{task.deals.name}</span>
                        <span className="text-xs text-muted-foreground">
                          {task.deals.contacts.company || `${task.deals.contacts.first_name} ${task.deals.contacts.last_name}`}
                          {task.deals.amount && ` • $${Number(task.deals.amount).toLocaleString()}`}
                        </span>
                      </div>
                    ) : (
                      "—"
                    )}
                  </TableCell>
                )}
                {columns.find((c) => c.id === "relatedTo" && c.visible) && (
                  <TableCell>
                    {task.related_to_type && task.related_to_id
                      ? `${task.related_to_type.charAt(0).toUpperCase() + task.related_to_type.slice(1)}`
                      : "—"}
                  </TableCell>
                )}
                {columns.find((c) => c.id === "assignedTo" && c.visible) && (
                  <TableCell>{task.assigned_to || "—"}</TableCell>
                )}
                {columns.find((c) => c.id === "actions" && c.visible) && (
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onView(task)}
                        className="flex items-center gap-1"
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        View
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onEdit(task)}
                        className="flex items-center gap-1"
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                      {task.status !== "completed" && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onComplete(task)}
                          className="flex items-center gap-1 text-green-600"
                        >
                          <CheckSquare className="h-4 w-4 mr-1" />
                          Complete
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onDelete(task)}
                        className="flex items-center gap-1 text-red-600"
                      >
                        <Trash2 className="h-4 w-4 mr-1" />
                        Delete
                      </Button>
                    </div>
                  </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <ColumnManager
        columns={columns}
        open={isColumnManagerOpen}
        onOpenChange={onColumnManagerOpenChange}
        onColumnsChange={handleColumnChange}
      />
    </>
  );
}
