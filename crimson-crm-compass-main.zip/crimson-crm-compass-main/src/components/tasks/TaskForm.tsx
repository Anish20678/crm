
import React from "react";
import { useForm } from "react-hook-form";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { zodResolver } from "@hookform/resolvers/zod";
import { Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { Deal } from "@/lib/types";
import * as z from "zod";

const formSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  status: z.string().min(1, "Status is required"),
  priority: z.string().min(1, "Priority is required"),
  due_date: z.string().optional(),
  assigned_to: z.string().optional(),
  related_to_type: z.string().optional(),
  related_to_id: z.string().optional(),
  deal_id: z.string().optional(),
});

export type TaskFormValues = z.infer<typeof formSchema>;

interface TaskFormProps {
  onSubmit: (data: TaskFormValues) => void;
  defaultValues?: Partial<TaskFormValues>;
  isSubmitting?: boolean;
  taskId?: string;
}

export function TaskForm({
  onSubmit,
  defaultValues = {},
  isSubmitting = false,
  taskId,
}: TaskFormProps) {
  const [open, setOpen] = React.useState(false);

  const form = useForm<TaskFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      status: "todo",
      priority: "medium",
      due_date: "",
      assigned_to: "",
      related_to_type: "",
      related_to_id: "",
      deal_id: "",
      ...defaultValues,
    },
  });

  const { data: deals = [], isLoading: isDealsLoading } = useQuery({
    queryKey: ["deals"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("deals")
        .select(`
          id,
          name,
          status,
          amount,
          contact_id,
          contacts!inner(first_name, last_name, company)
        `)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as (Deal & { contacts: { first_name: string; last_name: string; company: string | null } })[];
    },
  });

  const selectedDeal = deals.find(deal => deal.id === form.watch("deal_id"));

  const getDealStatusOptions = () => {
    const dealId = form.watch("deal_id");
    
    if (dealId) {
      return [
        { value: "todo", label: "To Do" },
        { value: "in_progress", label: "In Progress" },
        { value: "waiting_for_client", label: "Waiting for Client" },
        { value: "ready_for_review", label: "Ready for Review" },
        { value: "completed", label: "Completed" },
        { value: "cancelled", label: "Cancelled" },
      ];
    }
    
    return [
      { value: "todo", label: "To Do" },
      { value: "in_progress", label: "In Progress" },
      { value: "completed", label: "Completed" },
      { value: "cancelled", label: "Cancelled" },
    ];
  };

  // Helper function to convert empty strings to null for UUID fields
  const handleFormSubmit = (data: TaskFormValues) => {
    const cleanedData = {
      ...data,
      deal_id: data.deal_id === "" ? undefined : data.deal_id,
      related_to_id: data.related_to_id === "" ? undefined : data.related_to_id,
      assigned_to: data.assigned_to === "" ? undefined : data.assigned_to,
      due_date: data.due_date === "" ? undefined : data.due_date,
      description: data.description === "" ? undefined : data.description,
    };
    
    console.log("Form data before cleanup:", data);
    console.log("Form data after cleanup:", cleanedData);
    
    onSubmit(cleanedData);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Title*</FormLabel>
              <FormControl>
                <Input placeholder="Task title" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Task description"
                  className="min-h-[100px]"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="deal_id"
          render={({ field }) => (
            <FormItem className="flex flex-col">
              <FormLabel>Related Deal</FormLabel>
              <Popover open={open} onOpenChange={setOpen}>
                <PopoverTrigger asChild>
                  <FormControl>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={open}
                      className={cn(
                        "w-full justify-between",
                        !field.value && "text-muted-foreground"
                      )}
                    >
                      {field.value
                        ? `${selectedDeal?.name} (${selectedDeal?.contacts?.company || `${selectedDeal?.contacts?.first_name} ${selectedDeal?.contacts?.last_name}`})`
                        : "Select deal..."}
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </FormControl>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0">
                  <Command>
                    <CommandInput placeholder="Search deals..." />
                    <CommandList>
                      <CommandEmpty>
                        {isDealsLoading ? "Loading deals..." : "No deals found."}
                      </CommandEmpty>
                      <CommandGroup>
                        <CommandItem
                          value=""
                          onSelect={() => {
                            form.setValue("deal_id", "");
                            setOpen(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              field.value === "" ? "opacity-100" : "opacity-0"
                            )}
                          />
                          No deal
                        </CommandItem>
                        {deals.map((deal) => (
                          <CommandItem
                            key={deal.id}
                            value={`${deal.name} ${deal.contacts?.company || `${deal.contacts?.first_name} ${deal.contacts?.last_name}`}`}
                            onSelect={() => {
                              form.setValue("deal_id", deal.id);
                              setOpen(false);
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                field.value === deal.id ? "opacity-100" : "opacity-0"
                              )}
                            />
                            <div className="flex flex-col">
                              <span className="font-medium">{deal.name}</span>
                              <span className="text-sm text-muted-foreground">
                                {deal.contacts?.company || `${deal.contacts?.first_name} ${deal.contacts?.last_name}`} • 
                                {deal.amount ? ` $${Number(deal.amount).toLocaleString()}` : ' No amount'} • 
                                {deal.status}
                              </span>
                            </div>
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status*</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {getDealStatusOptions().map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="priority"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Priority*</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="due_date"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Due Date</FormLabel>
              <FormControl>
                <Input type="date" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end gap-4">
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting
              ? "Saving..."
              : taskId
              ? "Update Task"
              : "Create Task"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
