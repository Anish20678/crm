
import { Contact } from "@/lib/types";
import { format } from "date-fns";
import { ExternalLink, Mail, MessageSquare, Phone, BadgeDollarSign } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";

interface LeadDetailsProps {
  lead: Contact | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreateDeal: (lead: Contact) => void;
}

export function LeadDetails({
  lead,
  open,
  onOpenChange,
  onCreateDeal,
}: LeadDetailsProps) {
  if (!lead) return null;
  
  const handleCreateDeal = () => {
    if (lead) {
      onCreateDeal(lead);
      onOpenChange(false);
    }
  };
  
  const formatDate = (dateString: string | null) => {
    if (!dateString) return "—";
    try {
      return format(new Date(dateString), "PPP");
    } catch (error) {
      return dateString;
    }
  };

  // Mock timeline entries
  const timelineEntries = [
    {
      id: 1,
      action: "Lead Created",
      description: "Lead was added to the system",
      timestamp: lead.created_at,
    },
    ...(lead.proposal_sent ? [{
      id: 2,
      action: "Proposal Sent",
      description: "Proposal was sent to the lead",
      timestamp: lead.updated_at,
    }] : []),
    ...(lead.follow_up_date ? [{
      id: 3,
      action: "Follow-up Scheduled",
      description: `Follow-up scheduled for ${formatDate(lead.follow_up_date)}`,
      timestamp: lead.updated_at,
    }] : [])
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex justify-between items-center">
            <DialogTitle className="text-2xl">
              {lead.first_name} {lead.last_name}
            </DialogTitle>
            <Badge variant={lead.is_client ? "default" : "secondary"}>
              {lead.is_client ? "Client" : "Lead"}
            </Badge>
          </div>
        </DialogHeader>
        
        <Tabs defaultValue="overview" className="w-full">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="timeline">Timeline</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-6 mt-4">
            {/* Basic Information */}
            <div>
              <h3 className="font-semibold text-lg">Basic Information</h3>
              <Separator className="my-2" />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div>
                    <p className="text-sm text-muted-foreground">First Name</p>
                    <p>{lead.first_name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Email</p>
                    <p>{lead.email || "—"}</p>
                  </div>
                  
                  {/* Additional Phone Numbers */}
                  {Array.isArray(lead.phone_numbers) && lead.phone_numbers.length > 0 && (
                    <div>
                      <p className="text-sm text-muted-foreground">Additional Phone Numbers</p>
                      <div className="space-y-1">
                        {lead.phone_numbers.map((phone, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <span>{phone}</span>
                            <div className="flex space-x-1">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-7 w-7 p-0" 
                                onClick={() => window.open(`https://wa.me/${phone.replace(/\D/g, '')}`, '_blank')}
                              >
                                <MessageSquare className="h-3 w-3 text-green-600" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-7 w-7 p-0" 
                                onClick={() => window.open(`tel:${phone}`, '_blank')}
                              >
                                <Phone className="h-3 w-3 text-blue-600" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="space-y-2">
                  <div>
                    <p className="text-sm text-muted-foreground">Last Name</p>
                    <p>{lead.last_name || "—"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Phone</p>
                    <div className="flex items-center gap-2">
                      <p>{lead.phone || "—"}</p>
                      {lead.phone && (
                        <div className="flex space-x-1">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-7 w-7 p-0" 
                            onClick={() => window.open(`https://wa.me/${lead.phone?.replace(/\D/g, '')}`, '_blank')}
                          >
                            <MessageSquare className="h-3 w-3 text-green-600" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-7 w-7 p-0" 
                            onClick={() => window.open(`tel:${lead.phone}`, '_blank')}
                          >
                            <Phone className="h-3 w-3 text-blue-600" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Business Details */}
            <div>
              <h3 className="font-semibold text-lg">Business Details</h3>
              <Separator className="my-2" />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div>
                    <p className="text-sm text-muted-foreground">Business Name</p>
                    <p>{lead.business_name || lead.company || "—"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Business Type</p>
                    <p>{lead.business_type || "—"}</p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div>
                    <p className="text-sm text-muted-foreground">Emirates</p>
                    <p>{lead.emirates || "—"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Position</p>
                    <p>{lead.position || "—"}</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Lead Information */}
            <div>
              <h3 className="font-semibold text-lg">Lead Information</h3>
              <Separator className="my-2" />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div>
                    <p className="text-sm text-muted-foreground">Lead Source</p>
                    <p>{lead.lead_source || "—"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Inquiry Date</p>
                    <p>{lead.inquiry_date ? formatDate(lead.inquiry_date) : "—"}</p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div>
                    <p className="text-sm text-muted-foreground">Campaign Name</p>
                    <p>{lead.campaign_name || "—"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Preferred Contact Method</p>
                    <p>{lead.preferred_contact_method || "—"}</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Communication & Proposal */}
            <div>
              <h3 className="font-semibold text-lg">Communication & Proposal</h3>
              <Separator className="my-2" />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  {lead.initial_whatsapp_message && (
                    <div>
                      <p className="text-sm text-muted-foreground">Initial WhatsApp Message</p>
                      <p className="whitespace-pre-wrap">{lead.initial_whatsapp_message}</p>
                    </div>
                  )}
                  <div>
                    <p className="text-sm text-muted-foreground">Proposal Sent</p>
                    <p>{lead.proposal_sent ? "Yes" : "No"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Proposal Files</p>
                    {Array.isArray(lead.proposal_files) && lead.proposal_files.length > 0 ? (
                      <div className="space-y-1">
                        {lead.proposal_files.map((file, index) => (
                          <div key={index} className="flex items-center gap-1">
                            <ExternalLink className="h-3 w-3" />
                            <span className="text-sm text-blue-600 hover:underline cursor-pointer">
                              {typeof file === 'string' ? file.split('/').pop() : 'File'}
                            </span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p>No proposal files uploaded</p>
                    )}
                  </div>
                </div>
                
                <div className="space-y-2">
                  {lead.call_notes && (
                    <div>
                      <p className="text-sm text-muted-foreground">Call Notes</p>
                      <p className="whitespace-pre-wrap">{lead.call_notes}</p>
                    </div>
                  )}
                  <div>
                    <p className="text-sm text-muted-foreground">Follow-up Date</p>
                    <p>{lead.follow_up_date ? formatDate(lead.follow_up_date) : "—"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Client Status</p>
                    <Badge variant={lead.is_client ? "default" : "secondary"}>
                      {lead.is_client ? "Client" : "Lead"}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Notes */}
            {lead.notes && (
              <div>
                <h3 className="font-semibold text-lg">Notes</h3>
                <Separator className="my-2" />
                <p className="whitespace-pre-wrap">{lead.notes}</p>
              </div>
            )}
          </TabsContent>
          
          {/* Timeline Tab */}
          <TabsContent value="timeline" className="space-y-4 mt-4">
            {timelineEntries.map((entry) => (
              <Card key={entry.id} className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex justify-between">
                    <h3 className="font-medium">{entry.action}</h3>
                    <p className="text-sm text-muted-foreground">
                      {entry.timestamp ? formatDate(entry.timestamp) : "—"}
                    </p>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {entry.description}
                  </p>
                </CardContent>
              </Card>
            ))}
            
            {timelineEntries.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No activity recorded for this lead yet.
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        <DialogFooter className="mt-6 flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <Button onClick={handleCreateDeal} className="flex items-center gap-1">
            <BadgeDollarSign className="h-4 w-4" />
            Convert to Deal
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
