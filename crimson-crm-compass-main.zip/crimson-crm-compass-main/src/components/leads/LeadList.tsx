
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Contact } from "@/lib/types";
import { format } from "date-fns";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Eye, Edit, Trash2, BadgeDollarSign, Phone, MessageSquare } from "lucide-react";
import { ColumnManager } from "../contacts/ColumnManager";
import { BulkActionBar } from "../bulk-actions/BulkActionBar";
import { BulkActionHeader } from "../bulk-actions/BulkActionHeader";
import { ConfirmationDialog } from "../bulk-actions/ConfirmationDialog";
import { useBulkSelection } from "@/hooks/useBulkSelection";
import { useSystemFieldDisplay, DisplayField } from "@/hooks/useSystemFieldDisplay";

interface LeadListProps {
  leads: Contact[];
  isLoading: boolean;
  onEdit: (lead: Contact) => void;
  onDelete: (lead: Contact) => void;
  onBulkDelete?: (leads: Contact[]) => void;
  onCreateDeal: (lead: Contact) => void;
  onBulkCreateDeals?: (leads: Contact[]) => void;
  isColumnManagerOpen?: boolean;
  onColumnManagerOpenChange?: (open: boolean) => void;
}

// Extended column interface to include width
interface LeadColumn {
  id: string;
  label: string;
  visible: boolean;
  width?: number;
}

export function LeadList({ 
  leads, 
  isLoading, 
  onEdit, 
  onDelete, 
  onBulkDelete,
  onCreateDeal,
  onBulkCreateDeals,
  isColumnManagerOpen = false,
  onColumnManagerOpenChange
}: LeadListProps) {
  const navigate = useNavigate();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showConvertDialog, setShowConvertDialog] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  
  const {
    selectedItems,
    selectedCount,
    isSelected,
    toggleSelection,
    selectAll,
    clearSelection,
  } = useBulkSelection(leads);

  // Use system field configurations
  const { visibleFields, isLoading: isFieldConfigLoading } = useSystemFieldDisplay("lead");

  // Create columns based on system field configurations with width
  const systemColumns: LeadColumn[] = visibleFields.map(field => ({
    id: field.fieldName,
    label: field.label,
    visible: true,
    width: field.width,
  }));

  // Add special columns that are always available
  const [columns, setColumns] = useState<LeadColumn[]>([
    { id: "select", label: "", visible: true },
    ...systemColumns,
    { id: "actions", label: "Actions", visible: true },
  ]);

  const visibleColumns = columns.filter(col => col.visible);

  const handleViewDetails = (lead: Contact) => {
    navigate(`/leads/${lead.id}`);
  };

  const handleColumnChange = (newColumns: any[]) => {
    // Convert back to LeadColumn format
    const updatedColumns: LeadColumn[] = newColumns.map(col => ({
      id: col.id,
      label: col.label,
      visible: col.visible,
      width: col.width,
    }));
    setColumns(updatedColumns);
  };

  const handleBulkDelete = async () => {
    if (!onBulkDelete) return;
    
    setIsProcessing(true);
    try {
      await onBulkDelete(selectedItems);
      clearSelection();
      setShowDeleteDialog(false);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleBulkConvert = async () => {
    if (!onBulkCreateDeals) return;
    
    setIsProcessing(true);
    try {
      await onBulkCreateDeals(selectedItems);
      clearSelection();
      setShowConvertDialog(false);
    } finally {
      setIsProcessing(false);
    }
  };

  const renderFieldValue = (lead: Contact, fieldName: string) => {
    const value = lead[fieldName as keyof Contact];
    
    switch (fieldName) {
      case "first_name":
      case "last_name":
        return <span className="font-medium">{value || '-'}</span>;
      
      case "phone":
        return value ? (
          <div className="flex items-center">
            <span>{value}</span>
            <div className="flex ml-2 space-x-1">
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-6 w-6" 
                onClick={(e) => {
                  e.stopPropagation();
                  // Safely handle phone value - ensure it's a string before calling replace
                  const phoneValue = typeof value === 'string' ? value : String(value);
                  window.open(`https://wa.me/${phoneValue.replace(/\D/g, '')}`, '_blank');
                }}
              >
                <MessageSquare className="h-3 w-3 text-green-600" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-6 w-6" 
                onClick={(e) => {
                  e.stopPropagation();
                  window.open(`tel:${value}`, '_blank');
                }}
              >
                <Phone className="h-3 w-3 text-blue-600" />
              </Button>
            </div>
          </div>
        ) : '-';
      
      case "proposal_sent":
        return (
          <Badge variant={value ? "default" : "outline"}>
            {value ? "Yes" : "No"}
          </Badge>
        );
      
      case "follow_up_date":
      case "inquiry_date":
        return value ? format(new Date(value as string), "MMM dd, yyyy") : '-';
      
      case "business_name":
      case "company":
        return lead.business_name || lead.company || '-';
      
      default:
        return value || '-';
    }
  };

  const bulkActions = [
    {
      id: "delete",
      label: "Delete",
      icon: <Trash2 className="h-4 w-4" />,
      variant: "destructive" as const,
      onClick: () => setShowDeleteDialog(true),
    },
    {
      id: "convert",
      label: "Convert to Deals",
      icon: <BadgeDollarSign className="h-4 w-4" />,
      variant: "default" as const,
      onClick: () => setShowConvertDialog(true),
    },
  ];

  if (isFieldConfigLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <span>Loading field configurations...</span>
      </div>
    );
  }

  return (
    <>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              {visibleColumns.map(column => (
                <TableHead 
                  key={column.id} 
                  className={column.id === 'actions' ? 'text-right' : ''}
                  style={{ 
                    width: column.id !== 'select' && column.id !== 'actions' && column.width 
                      ? `${column.width}%` 
                      : undefined 
                  }}
                >
                  {column.id === 'select' ? (
                    <BulkActionHeader
                      selectedCount={selectedCount}
                      totalCount={leads.length}
                      onSelectAll={selectAll}
                      onClearSelection={clearSelection}
                    />
                  ) : (
                    column.label
                  )}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={visibleColumns.length} className="text-center py-4">
                  Loading leads...
                </TableCell>
              </TableRow>
            ) : leads.length === 0 ? (
              <TableRow>
                <TableCell colSpan={visibleColumns.length} className="text-center py-4">
                  No leads found. Add your first lead to get started.
                </TableCell>
              </TableRow>
            ) : (
              leads.map((lead) => (
                <TableRow key={lead.id}>
                  {visibleColumns.map(column => {
                    if (column.id === "select") {
                      return (
                        <TableCell key={column.id}>
                          <Checkbox
                            checked={isSelected(lead.id)}
                            onCheckedChange={() => toggleSelection(lead.id)}
                            aria-label={`Select ${lead.first_name} ${lead.last_name}`}
                          />
                        </TableCell>
                      );
                    }
                    
                    if (column.id === "actions") {
                      return (
                        <TableCell key={column.id} className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => handleViewDetails(lead)}
                              className="flex items-center gap-1"
                            >
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                            
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onCreateDeal(lead)}
                              className="flex items-center gap-1 text-blue-600"
                            >
                              <BadgeDollarSign className="h-4 w-4 mr-1" />
                              Convert
                            </Button>

                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onEdit(lead)}
                              className="flex items-center gap-1"
                            >
                              <Edit className="h-4 w-4 mr-1" />
                              Edit
                            </Button>

                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onDelete(lead)}
                              className="flex items-center gap-1 text-red-600"
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Delete
                            </Button>
                          </div>
                        </TableCell>
                      );
                    }
                    
                    // Render system field
                    return (
                      <TableCell key={column.id}>
                        {renderFieldValue(lead, column.id)}
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
      
      <BulkActionBar
        selectedCount={selectedCount}
        onClearSelection={clearSelection}
        actions={bulkActions}
      />

      <ConfirmationDialog
        open={showDeleteDialog}
        onOpenChange={setShowDeleteDialog}
        title="Delete Selected Leads"
        description={`Are you sure you want to delete ${selectedCount} lead${selectedCount > 1 ? 's' : ''}? This action cannot be undone.`}
        confirmLabel="Delete"
        confirmVariant="destructive"
        onConfirm={handleBulkDelete}
        isLoading={isProcessing}
      />

      <ConfirmationDialog
        open={showConvertDialog}
        onOpenChange={setShowConvertDialog}
        title="Convert Selected Leads"
        description={`Are you sure you want to convert ${selectedCount} lead${selectedCount > 1 ? 's' : ''} to deals?`}
        confirmLabel="Convert"
        onConfirm={handleBulkConvert}
        isLoading={isProcessing}
      />
      
      <ColumnManager
        columns={columns}
        open={isColumnManagerOpen || false}
        onOpenChange={onColumnManagerOpenChange || (() => {})}
        onColumnsChange={handleColumnChange}
      />
    </>
  );
}
