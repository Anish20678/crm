import { useState } from "react";
import { Contact } from "@/lib/types";
import { format } from "date-fns";
import { ExternalLink, Mail, MessageSquare, Phone } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

interface ContactDetailsProps {
  contact: Contact | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreateDeal: (contact: Contact) => void;
}

export function ContactDetails({
  contact,
  open,
  onOpenChange,
  onCreateDeal,
}: ContactDetailsProps) {
  if (!contact) return null;
  
  const handleCreateDeal = () => {
    if (contact) {
      onCreateDeal(contact);
      onOpenChange(false);
    }
  };
  
  const formatDate = (dateString: string | null) => {
    if (!dateString) return "—";
    try {
      return format(new Date(dateString), "PPP");
    } catch (error) {
      return dateString;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex justify-between items-center">
            <DialogTitle className="text-2xl">
              {contact.first_name} {contact.last_name}
            </DialogTitle>
            <Badge variant={contact.is_client ? "default" : "secondary"}>
              {contact.is_client ? "Client" : "Lead"}
            </Badge>
          </div>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-lg">Contact Information</h3>
              <Separator className="my-2" />
              
              <div className="space-y-2">
                {contact.email && (
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <a href={`mailto:${contact.email}`} className="text-blue-600 hover:underline">
                      {contact.email}
                    </a>
                  </div>
                )}
                
                {contact.phone && (
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{contact.phone}</span>
                    <div className="flex ml-2 space-x-1">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8" 
                        onClick={() => window.open(`https://wa.me/${contact.phone?.replace(/\D/g, '')}`, '_blank')}
                      >
                        <MessageSquare className="h-4 w-4 text-green-600" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8" 
                        onClick={() => window.open(`tel:${contact.phone}`, '_blank')}
                      >
                        <Phone className="h-4 w-4 text-blue-600" />
                      </Button>
                    </div>
                  </div>
                )}
                
                {Array.isArray(contact.phone_numbers) && contact.phone_numbers.map((phone, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{phone}</span>
                    <div className="flex ml-2 space-x-1">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8" 
                        onClick={() => window.open(`https://wa.me/${phone.replace(/\D/g, '')}`, '_blank')}
                      >
                        <MessageSquare className="h-4 w-4 text-green-600" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8" 
                        onClick={() => window.open(`tel:${phone}`, '_blank')}
                      >
                        <Phone className="h-4 w-4 text-blue-600" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold text-lg">Business Information</h3>
              <Separator className="my-2" />
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <p className="text-sm text-muted-foreground">Business Name</p>
                  <p>{contact.business_name || contact.company || "—"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Business Type</p>
                  <p>{contact.business_type || "—"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Position</p>
                  <p>{contact.position || "—"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Emirates</p>
                  <p>{contact.emirates || "—"}</p>
                </div>
              </div>
            </div>
            
            {contact.notes && (
              <div>
                <h3 className="font-semibold text-lg">Notes</h3>
                <Separator className="my-2" />
                <p className="whitespace-pre-wrap">{contact.notes}</p>
              </div>
            )}
          </div>
          
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-lg">Lead Information</h3>
              <Separator className="my-2" />
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <p className="text-sm text-muted-foreground">Lead Source</p>
                  <p>{contact.lead_source || "—"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Campaign</p>
                  <p>{contact.campaign_name || "—"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Inquiry Date</p>
                  <p>{contact.inquiry_date ? formatDate(contact.inquiry_date) : "—"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Preferred Contact</p>
                  <p>{contact.preferred_contact_method || "—"}</p>
                </div>
              </div>
            </div>
            
            {contact.initial_whatsapp_message && (
              <div>
                <h3 className="font-semibold text-lg">Initial WhatsApp Message</h3>
                <Separator className="my-2" />
                <p className="whitespace-pre-wrap">{contact.initial_whatsapp_message}</p>
              </div>
            )}
            
            {contact.call_notes && (
              <div>
                <h3 className="font-semibold text-lg">Call Notes</h3>
                <Separator className="my-2" />
                <p className="whitespace-pre-wrap">{contact.call_notes}</p>
              </div>
            )}
            
            <div>
              <h3 className="font-semibold text-lg">Proposal Information</h3>
              <Separator className="my-2" />
              <div className="grid grid-cols-2 gap-2 mb-2">
                <div>
                  <p className="text-sm text-muted-foreground">Proposal Sent</p>
                  <p>{contact.proposal_sent ? "Yes" : "No"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Follow-up Date</p>
                  <p>{contact.follow_up_date ? formatDate(contact.follow_up_date) : "—"}</p>
                </div>
              </div>
              
              {Array.isArray(contact.proposal_files) && contact.proposal_files.length > 0 && (
                <div className="mt-2">
                  <p className="text-sm text-muted-foreground">Proposal Files</p>
                  <div className="space-y-1 mt-1">
                    {contact.proposal_files.map((file, index) => (
                      <div key={index} className="flex items-center gap-1">
                        <ExternalLink className="h-3 w-3" />
                        <span className="text-sm">{typeof file === 'string' ? file.split('/').pop() : 'File'}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        
        <div className="mt-6 flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <Button onClick={handleCreateDeal}>
            Convert to Deal
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
