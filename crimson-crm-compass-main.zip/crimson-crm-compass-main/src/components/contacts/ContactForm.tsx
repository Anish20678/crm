
import { useEffect, useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Contact } from "@/lib/types";
import { ContactTabs, ContactFormValues, contactFormSchema } from "./ContactTabs";

interface ContactFormProps {
  contact: Contact | null;
  onSubmit: (data: ContactFormValues) => void;
  isSubmitting: boolean;
  dialogAction: string;
  phoneNumbers: string[];
  setPhoneNumbers: React.Dispatch<React.SetStateAction<string[]>>;
  proposalFiles: File[];
  setProposalFiles: React.Dispatch<React.SetStateAction<File[]>>;
}

export function ContactForm({
  contact,
  onSubmit,
  isSubmitting,
  dialogAction,
  phoneNumbers,
  setPhoneNumbers,
  proposalFiles,
  setProposalFiles,
}: ContactFormProps) {
  const [newPhone, setNewPhone] = useState("");

  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      first_name: "",
      last_name: "",
      email: "",
      phone: "",
      company: "",
      position: "",
      notes: "",
      business_name: "",
      business_type: "",
      emirates: "",
      lead_source: "",
      campaign_name: "",
      inquiry_date: null,
      initial_whatsapp_message: "",
      call_notes: "",
      proposal_sent: false,
      follow_up_date: null,
      preferred_contact_method: "",
      is_client: false,
    },
  });

  useEffect(() => {
    if (contact) {
      setPhoneNumbers(contact.phone_numbers as string[] || []);
      
      form.reset({
        first_name: contact.first_name,
        last_name: contact.last_name || "",
        email: contact.email || "",
        phone: contact.phone || "",
        company: contact.company || "",
        position: contact.position || "",
        notes: contact.notes || "",
        business_name: contact.business_name || "",
        business_type: contact.business_type || "",
        emirates: contact.emirates || "",
        lead_source: contact.lead_source || "",
        campaign_name: contact.campaign_name || "",
        inquiry_date: contact.inquiry_date ? new Date(contact.inquiry_date) : null,
        initial_whatsapp_message: contact.initial_whatsapp_message || "",
        call_notes: contact.call_notes || "",
        proposal_sent: contact.proposal_sent || false,
        follow_up_date: contact.follow_up_date ? new Date(contact.follow_up_date) : null,
        preferred_contact_method: contact.preferred_contact_method || "",
        is_client: contact.is_client || false,
      });
    } else {
      form.reset();
      setPhoneNumbers([]);
      setProposalFiles([]);
    }
  }, [contact, form, setPhoneNumbers, setProposalFiles]);

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.files && e.target.files.length > 0) {
      const filesArray = Array.from(e.target.files);
      setProposalFiles([...proposalFiles, ...filesArray]);
    }
  }

  function removeFile(index: number) {
    setProposalFiles(proposalFiles.filter((_, i) => i !== index));
  }

  return (
    <ContactTabs
      form={form}
      onSubmit={onSubmit}
      isSubmitting={isSubmitting}
      dialogAction={dialogAction}
      phoneNumbers={phoneNumbers}
      setPhoneNumbers={setPhoneNumbers}
      newPhone={newPhone}
      setNewPhone={setNewPhone}
      proposalFiles={proposalFiles}
      handleFileChange={handleFileChange}
      removeFile={removeFile}
    />
  );
}
