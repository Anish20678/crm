
import { useState, useEffect } from "react";
import { Check, GripVertical } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";

export interface Column {
  id: string;
  label: string;
  visible: boolean;
}

interface ColumnManagerProps {
  columns: Column[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onColumnsChange: (columns: Column[]) => void;
}

export function ColumnManager({ 
  columns, 
  open, 
  onOpenChange, 
  onColumnsChange 
}: ColumnManagerProps) {
  const [localColumns, setLocalColumns] = useState<Column[]>(columns);

  useEffect(() => {
    setLocalColumns(columns);
  }, [columns]);

  const handleVisibilityChange = (id: string, checked: boolean) => {
    setLocalColumns(prev => 
      prev.map(col => col.id === id ? { ...col, visible: checked } : col)
    );
  };

  const handleSave = () => {
    onColumnsChange(localColumns);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Manage Columns</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2 max-h-[400px] overflow-y-auto">
          {localColumns.map((column) => (
            <div
              key={column.id}
              className="flex items-center justify-between space-x-2 py-1"
            >
              <div className="flex items-center space-x-2">
                <GripVertical className="h-4 w-4 text-muted-foreground" />
                <label
                  htmlFor={`column-${column.id}`}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  {column.label}
                </label>
              </div>
              <Checkbox
                id={`column-${column.id}`}
                checked={column.visible}
                onCheckedChange={(checked) => handleVisibilityChange(column.id, !!checked)}
              />
            </div>
          ))}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
