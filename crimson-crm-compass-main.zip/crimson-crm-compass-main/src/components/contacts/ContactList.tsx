
import { useState } from "react";
import { Contact } from "@/lib/types";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Eye, Edit, Trash2, PlusCircle, Mail, Phone, MessageSquare, ColumnsIcon } from "lucide-react";
import { Column, ColumnManager } from "./ColumnManager";
import { ContactDetails } from "./ContactDetails";

interface ContactListProps {
  contacts: Contact[];
  isLoading: boolean;
  onEdit: (contact: Contact) => void;
  onDelete: (contact: Contact) => void;
  onCreateDeal: (contact: Contact) => void;
}

export function ContactList({ 
  contacts, 
  isLoading, 
  onEdit, 
  onDelete, 
  onCreateDeal 
}: ContactListProps) {
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isColumnManagerOpen, setIsColumnManagerOpen] = useState(false);
  const [columns, setColumns] = useState<Column[]>([
    { id: "name", label: "Name", visible: true },
    { id: "contact", label: "Contact", visible: true },
    { id: "business", label: "Business", visible: true },
    { id: "leadSource", label: "Lead Source", visible: true },
    { id: "status", label: "Status", visible: true },
    { id: "actions", label: "Actions", visible: true },
  ]);

  const visibleColumns = columns.filter(col => col.visible);

  const handleViewDetails = (contact: Contact) => {
    setSelectedContact(contact);
    setIsDetailsOpen(true);
  };

  const handleColumnChange = (newColumns: Column[]) => {
    setColumns(newColumns);
  };

  return (
    <>
      <div className="flex justify-end mb-2">
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => setIsColumnManagerOpen(true)}
          className="flex items-center gap-1"
        >
          <ColumnsIcon className="h-4 w-4" />
          Manage Columns
        </Button>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            {visibleColumns.map(column => (
              <TableHead key={column.id}>
                {column.label}
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <TableRow>
              <TableCell colSpan={visibleColumns.length} className="text-center py-4">
                Loading contacts...
              </TableCell>
            </TableRow>
          ) : contacts.length === 0 ? (
            <TableRow>
              <TableCell colSpan={visibleColumns.length} className="text-center py-4">
                No contacts found. Add your first contact to get started.
              </TableCell>
            </TableRow>
          ) : (
            contacts.map((contact) => (
              <TableRow key={contact.id}>
                {columns.find(c => c.id === "name" && c.visible) && (
                  <TableCell>
                    <div>
                      <div className="font-medium">
                        {contact.first_name} {contact.last_name}
                      </div>
                      {contact.position && (
                        <div className="text-sm text-gray-500">
                          {contact.position}
                        </div>
                      )}
                    </div>
                  </TableCell>
                )}
                
                {columns.find(c => c.id === "contact" && c.visible) && (
                  <TableCell>
                    <div className="space-y-1">
                      {contact.email && (
                        <div className="flex items-center text-sm">
                          <Mail className="h-3 w-3 mr-2" />
                          <span>{contact.email}</span>
                        </div>
                      )}
                      {contact.phone && (
                        <div className="flex items-center text-sm">
                          <Phone className="h-3 w-3 mr-2" />
                          <span>{contact.phone}</span>
                          <div className="flex ml-2 space-x-1">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-6 w-6" 
                              onClick={(e) => {
                                e.stopPropagation();
                                window.open(`https://wa.me/${contact.phone?.replace(/\D/g, '')}`, '_blank');
                              }}
                            >
                              <MessageSquare className="h-3 w-3 text-green-600" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-6 w-6" 
                              onClick={(e) => {
                                e.stopPropagation();
                                window.open(`tel:${contact.phone}`, '_blank');
                              }}
                            >
                              <Phone className="h-3 w-3 text-blue-600" />
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  </TableCell>
                )}
                
                {columns.find(c => c.id === "business" && c.visible) && (
                  <TableCell>
                    <div>
                      {contact.business_name || contact.company || '-'}
                      {contact.emirates && (
                        <div className="text-sm text-gray-500">
                          {contact.emirates}
                        </div>
                      )}
                    </div>
                  </TableCell>
                )}
                
                {columns.find(c => c.id === "leadSource" && c.visible) && (
                  <TableCell>
                    {contact.lead_source || '-'}
                  </TableCell>
                )}
                
                {columns.find(c => c.id === "status" && c.visible) && (
                  <TableCell>
                    <div className="flex items-center">
                      <span className={`w-2 h-2 rounded-full mr-2 ${
                        contact.is_client ? 'bg-green-500' : 'bg-blue-500'
                      }`}></span>
                      <span>{contact.is_client ? 'Client' : 'Lead'}</span>
                    </div>
                  </TableCell>
                )}
                
                {columns.find(c => c.id === "actions" && c.visible) && (
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleViewDetails(contact)}>
                          <Eye className="h-4 w-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => onEdit(contact)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => onCreateDeal(contact)}>
                          <PlusCircle className="h-4 w-4 mr-2" />
                          Create Deal
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => onDelete(contact)}
                          className="text-red-600"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                )}
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
      
      <ColumnManager
        columns={columns}
        open={isColumnManagerOpen}
        onOpenChange={setIsColumnManagerOpen}
        onColumnsChange={handleColumnChange}
      />
      
      <ContactDetails
        contact={selectedContact}
        open={isDetailsOpen}
        onOpenChange={setIsDetailsOpen}
        onCreateDeal={onCreateDeal}
      />
    </>
  );
}
