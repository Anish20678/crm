
import { useState, useEffect, useMemo, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import { Lead } from "@/hooks/useLeadsData";

import { Button } from "@/components/ui/button";
import { Form } from "@/components/ui/form";
import { ChevronLeft } from "lucide-react";
import { EnhancedDynamicFormBuilder } from "@/components/fields/EnhancedDynamicFormBuilder";
import { useCustomFieldValues } from "@/hooks/useCustomFieldValues";
import { useEnhancedSystemFieldDisplay } from "@/hooks/useEnhancedSystemFieldDisplay";

// Create dynamic schema based on system fields
const createLeadFormSchema = (systemFields: any[]) => {
  const schemaFields: Record<string, any> = {};
  
  systemFields.forEach(field => {
    switch (field.type) {
      case "text":
      case "textarea":
        schemaFields[field.fieldName] = field.required 
          ? z.string().min(1, `${field.label} is required`)
          : z.string().optional().nullable();
        break;
      case "email":
        schemaFields[field.fieldName] = field.required
          ? z.string().email("Invalid email")
          : z.string().email("Invalid email").optional().nullable().or(z.literal(""));
        break;
      case "phone":
        schemaFields[field.fieldName] = field.required
          ? z.string().min(1, `${field.label} is required`)
          : z.string().optional().nullable();
        break;
      case "boolean":
        schemaFields[field.fieldName] = z.boolean().optional().nullable();
        break;
      case "date":
        schemaFields[field.fieldName] = field.required
          ? z.string().min(1, `${field.label} is required`)
          : z.string().optional().nullable();
        break;
      case "select":
        schemaFields[field.fieldName] = field.required
          ? z.string().min(1, `${field.label} is required`)
          : z.string().optional().nullable();
        break;
      case "number":
        schemaFields[field.fieldName] = field.required
          ? z.number().min(0, `${field.label} must be positive`)
          : z.number().optional().nullable();
        break;
      default:
        schemaFields[field.fieldName] = z.string().optional().nullable();
    }
  });

  return z.object(schemaFields);
};

export default function DynamicLeadFormPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { id } = useParams();
  const queryClient = useQueryClient();
  const isEditMode = !!id;
  
  // Get system field configurations
  const { visibleFields, isLoading: isFieldConfigLoading } = useEnhancedSystemFieldDisplay("lead");
  
  // Memoize schema creation to prevent recreating on every render
  const leadFormSchema = useMemo(() => {
    return createLeadFormSchema(visibleFields);
  }, [visibleFields]);
  
  type LeadFormValues = z.infer<typeof leadFormSchema>;

  const { data: lead, isLoading } = useQuery({
    queryKey: ["leads", id],
    queryFn: async () => {
      if (!id) return null;
      
      const { data, error } = await supabase
        .from("leads")
        .select("*")
        .eq("id", id)
        .eq("user_id", user?.id)
        .single();
      
      if (error) throw error;
      return data as Lead;
    },
    enabled: !!id && !!user,
  });

  // Memoize default values creation
  const defaultValues = useMemo(() => {
    const defaults: Record<string, any> = {};
    visibleFields.forEach(field => {
      switch (field.type) {
        case "boolean":
          defaults[field.fieldName] = false;
          break;
        case "date":
          defaults[field.fieldName] = null;
          break;
        default:
          defaults[field.fieldName] = "";
      }
    });
    return defaults;
  }, [visibleFields]);

  const form = useForm<LeadFormValues>({
    resolver: zodResolver(leadFormSchema),
    defaultValues,
  });

  // Custom fields state
  const [customFieldValuesState, setCustomFieldValuesState] = useState<Record<string, string>>({});
  const [customFieldErrors, setCustomFieldErrors] = useState<Record<string, string>>({});

  const {
    customFields,
    customFieldValues,
    fieldsLoading: customFieldsLoading,
    valuesLoading: customValuesLoading,
    upsertValues: upsertCustomFieldValues,
    error: customFieldsError,
  } = useCustomFieldValues("lead", id);

  // Memoize custom field values initialization
  const initializeCustomFieldValues = useCallback(() => {
    if (customFieldValues && customFieldValues.length) {
      const fieldMap: Record<string, string> = {};
      customFieldValues.forEach(val => { fieldMap[val.field_id] = val.value ?? ""; });
      setCustomFieldValuesState(fieldMap);
    } else if (customFields && customFields.length && !id) {
      // Initialize empty for create
      const fieldMap: Record<string, string> = {};
      customFields.forEach(f => fieldMap[f.id] = "");
      setCustomFieldValuesState(fieldMap);
    }
  }, [customFieldValues, customFields, id]);

  // Load custom field values into local state with optimized dependencies
  useEffect(() => {
    initializeCustomFieldValues();
  }, [initializeCustomFieldValues]);

  const addLeadMutation = useMutation({
    mutationFn: async (data: LeadFormValues) => {
      if (!user) throw new Error("User not authenticated");
      
      // Since we have a minimal leads table, we only store basic info there
      const { data: insertedLead, error } = await supabase
        .from("leads")
        .insert({
          user_id: user.id,
        })
        .select()
        .single();
      
      if (error) throw error;
      return insertedLead;
    },
    onSuccess: async (inserted: Lead) => {
      toast({
        title: "Lead added",
        description: "Your lead has been added successfully",
      });
      
      // Save custom field values
      const leadId = inserted.id;
      if (leadId && customFields && customFields.length) {
        const valuesToSave = customFields.map(f => ({
          field_id: f.id,
          value: customFieldValuesState[f.id] ?? "",
        }));
        await upsertCustomFieldValues(valuesToSave);
      }
      
      queryClient.invalidateQueries({ queryKey: ["leads"] });
      navigate("/leads");
    },
    onError: (error: any) => {
      toast({
        title: "Error adding lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateLeadMutation = useMutation({
    mutationFn: async (data: LeadFormValues) => {
      if (!id || !lead) throw new Error("No lead selected");
      
      // Update basic lead info
      const { data: updatedLead, error } = await supabase
        .from("leads")
        .update({
          updated_at: new Date().toISOString(),
        })
        .eq("id", id)
        .eq("user_id", user?.id)
        .select()
        .single();
      
      if (error) throw error;
      return updatedLead;
    },
    onSuccess: async () => {
      toast({
        title: "Lead updated",
        description: "Your lead has been updated successfully",
      });
      
      // Save custom fields
      if (customFields && customFields.length) {
        const valuesToSave = customFields.map(f => ({
          field_id: f.id,
          value: customFieldValuesState[f.id] ?? "",
        }));
        await upsertCustomFieldValues(valuesToSave);
      }
      
      queryClient.invalidateQueries({ queryKey: ["leads"] });
      navigate("/leads");
    },
    onError: (error: any) => {
      toast({
        title: "Error updating lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Memoize validation function
  const validateCustomFields = useCallback((): boolean => {
    const errors: Record<string, string> = {};
    customFields
      .filter(f => f.required)
      .forEach(f => {
        if (
          customFieldValuesState[f.id] == null ||
          customFieldValuesState[f.id] === "" ||
          (f.field_type === "boolean" && (customFieldValuesState[f.id] !== "true"))
        ) {
          errors[f.id] = "This field is required";
        }
      });
    setCustomFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }, [customFields, customFieldValuesState]);

  function onSubmit(data: LeadFormValues) {
    // Validate custom fields
    if (!validateCustomFields()) {
      window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
      return;
    }

    if (isEditMode) {
      updateLeadMutation.mutate(data);
    } else {
      addLeadMutation.mutate(data);
    }
  }

  if (isFieldConfigLoading || (isEditMode && isLoading)) {
    return <div className="flex justify-center items-center h-64">Loading...</div>;
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center mb-6">
        <Button 
          variant="ghost" 
          onClick={() => navigate("/leads")} 
          className="mr-2"
        >
          <ChevronLeft className="w-4 h-4 mr-1" />
          Back
        </Button>
        <h1 className="text-2xl font-semibold">
          {isEditMode ? `Edit Lead` : "Add New Lead"}
        </h1>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <EnhancedDynamicFormBuilder
            module="lead"
            form={form}
            recordId={id}
            customFieldValues={customFieldValuesState}
            onCustomFieldChange={(fieldId, value) => 
              setCustomFieldValuesState(prev => ({ ...prev, [fieldId]: value }))
            }
            customFieldErrors={customFieldErrors}
          />

          <div className="flex justify-end gap-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => navigate("/leads")}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isEditMode ? updateLeadMutation.isPending : addLeadMutation.isPending}
            >
              {isEditMode ? 
                (updateLeadMutation.isPending ? "Saving..." : "Update Lead") : 
                (addLeadMutation.isPending ? "Adding..." : "Add Lead")
              }
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
