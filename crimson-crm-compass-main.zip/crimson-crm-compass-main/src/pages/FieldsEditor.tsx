
import React, { useState } from "react";
import { EnhancedFieldsEditor } from "@/components/fields/EnhancedFieldsEditor";
import { FieldEditorWithDragDrop } from "@/components/fields/editor/FieldEditorWithDragDrop";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Settings } from "lucide-react";

const MODULE_OPTIONS = [
  { label: "Leads", value: "lead" },
  { label: "Deals", value: "deal" },
  { label: "Contacts", value: "contact" },
  { label: "Tasks", value: "task" },
];

export default function FieldsEditorPage() {
  // Default to leads module
  const [selectedModule, setSelectedModule] = useState("lead");
  const [activeTab, setActiveTab] = useState("advanced");

  return (
    <div className="max-w-7xl mx-auto mt-8 px-4">
      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-center gap-3 mb-2">
            <h1 className="text-2xl font-bold">Fields Management</h1>
            <Badge variant="outline" className="bg-gradient-to-r from-blue-50 to-purple-50">
              <Sparkles className="h-3 w-3 mr-1" />
              Enhanced Editor
            </Badge>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            {MODULE_OPTIONS.map((mod) => (
              <Button
                key={mod.value}
                variant={selectedModule === mod.value ? "default" : "outline"}
                onClick={() => setSelectedModule(mod.value)}
                size="sm"
              >
                {mod.label}
              </Button>
            ))}
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="advanced" className="flex items-center gap-2">
                <Sparkles className="h-4 w-4" />
                Advanced Editor
              </TabsTrigger>
              <TabsTrigger value="legacy" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Legacy Editor
              </TabsTrigger>
            </TabsList>

            <TabsContent value="advanced" className="mt-6">
              <FieldEditorWithDragDrop module={selectedModule} />
            </TabsContent>

            <TabsContent value="legacy" className="mt-6">
              <EnhancedFieldsEditor module={selectedModule} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
