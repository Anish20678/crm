import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { CalendarIcon, Loader2 } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Deal } from "@/lib/types";

type FormData = {
  name?: string;
  status?: string;
  amount?: number;
  contact_id?: string;
  project_type?: string;
  expected_delivery_date?: string;
  service_package?: string;
  project_scope?: string;
  requirements_received?: string[];
  start_date?: string;
  actual_delivery_date?: string;
  milestones?: { title: string, completed: boolean }[];
  payment_status?: string;
  payment_received_date?: string;
  invoice_file?: string;
  client_notes?: string;
  internal_notes?: string;
  project_files?: string[];
  final_deliverables?: string[];
};

export default function DealForm() {
  const { id } = useParams<{ id: string }>();
  const isEditMode = !!id;
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [expectedDeliveryDate, setExpectedDeliveryDate] = useState<Date | undefined>(undefined);
  const [actualDeliveryDate, setActualDeliveryDate] = useState<Date | undefined>(undefined);
  const [paymentReceivedDate, setPaymentReceivedDate] = useState<Date | undefined>(undefined);
  const [milestones, setMilestones] = useState<{ title: string; completed: boolean }[]>([
    { title: "Requirements Gathered", completed: false },
    { title: "Design Approved", completed: false },
    { title: "Development Complete", completed: false },
    { title: "Testing Complete", completed: false },
    { title: "Delivered to Client", completed: false }
  ]);
  const [newMilestone, setNewMilestone] = useState("");
  const [requirementsList, setRequirementsList] = useState<string[]>([]);
  const [newRequirement, setNewRequirement] = useState("");

  const { register, handleSubmit, setValue, formState: { isSubmitting } } = useForm<FormData>();

  // Fetch contacts for dropdown
  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts-for-deals"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("contacts")
        .select("id, first_name, last_name, business_name");
      
      if (error) throw error;
      return data || [];
    },
  });

  // Fetch deal data for edit mode
  const { data: dealData, isLoading: isDealLoading } = useQuery({
    queryKey: ["deal", id],
    queryFn: async () => {
      if (!id) return null;
      
      const { data, error } = await supabase
        .from("deals")
        .select("*")
        .eq("id", id)
        .single();
      
      if (error) throw error;
      return data as Deal; // Explicitly cast to Deal type
    },
    enabled: isEditMode,
  });

  // Set form values when deal data is loaded
  useEffect(() => {
    if (dealData) {
      const deal = dealData as Deal;
      
      setValue("name", deal.name);
      setValue("status", deal.status || "");
      setValue("contact_id", deal.contact_id);
      setValue("amount", deal.amount || undefined);
      setValue("project_type", deal.project_type || "");
      setValue("service_package", deal.service_package || "");
      setValue("project_scope", deal.project_scope || "");
      setValue("payment_status", deal.payment_status || "");
      setValue("client_notes", deal.client_notes || "");
      setValue("internal_notes", deal.internal_notes || "");
      
      if (deal.requirements_received && Array.isArray(deal.requirements_received)) {
        setRequirementsList(deal.requirements_received);
      }
      
      if (deal.start_date) {
        setStartDate(new Date(deal.start_date));
      }
      
      if (deal.expected_delivery_date) {
        setExpectedDeliveryDate(new Date(deal.expected_delivery_date));
      }
      
      if (deal.actual_delivery_date) {
        setActualDeliveryDate(new Date(deal.actual_delivery_date));
      }
      
      if (deal.payment_received_date) {
        setPaymentReceivedDate(new Date(deal.payment_received_date));
      }
      
      // Set milestones if they exist in the deal data
      if (deal.milestones && Array.isArray(deal.milestones)) {
        setMilestones(deal.milestones);
      }
      
      // Set project files and deliverables
      if (deal.project_files && Array.isArray(deal.project_files)) {
        setValue("project_files", deal.project_files);
      }
      
      if (deal.final_deliverables && Array.isArray(deal.final_deliverables)) {
        setValue("final_deliverables", deal.final_deliverables);
      }
    }
  }, [dealData, setValue]);

  const mutation = useMutation({
    mutationFn: async (data: FormData) => {
      // Check for required fields
      if (!data.contact_id) {
        throw new Error("Contact is required");
      }
      
      if (!data.name) {
        throw new Error("Deal name is required");
      }
      
      // Prepare deal data
      const dealData = {
        ...data,
        start_date: startDate ? startDate.toISOString() : null,
        expected_delivery_date: expectedDeliveryDate ? expectedDeliveryDate.toISOString() : null,
        actual_delivery_date: actualDeliveryDate ? actualDeliveryDate.toISOString() : null,
        payment_received_date: paymentReceivedDate ? paymentReceivedDate.toISOString() : null,
        milestones: milestones,
        requirements_received: requirementsList,
      };
      
      if (isEditMode) {
        // Update existing deal
        const { error } = await supabase
          .from("deals")
          .update(dealData)
          .eq("id", id);
          
        if (error) throw error;
        
        return { id };
      } else {
        // Create new deal
        const { data: newDeal, error } = await supabase
          .from("deals")
          .insert({
            name: dealData.name,
            contact_id: dealData.contact_id,
            status: dealData.status || "new",
            amount: dealData.amount || null,
            project_type: dealData.project_type,
            service_package: dealData.service_package,
            project_scope: dealData.project_scope,
            requirements_received: requirementsList,
            start_date: dealData.start_date,
            expected_delivery_date: dealData.expected_delivery_date,
            actual_delivery_date: dealData.actual_delivery_date,
            milestones: milestones,
            payment_status: dealData.payment_status,
            payment_received_date: dealData.payment_received_date,
            invoice_file: dealData.invoice_file,
            client_notes: dealData.client_notes,
            internal_notes: dealData.internal_notes,
            project_files: dealData.project_files,
            final_deliverables: dealData.final_deliverables
          })
          .select();
          
        if (error) throw error;
        
        return newDeal[0];
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["deals"] });
      queryClient.invalidateQueries({ queryKey: ["deal", data.id] });
      
      toast({
        title: isEditMode ? "Deal updated" : "Deal created",
        description: isEditMode 
          ? "Deal has been updated successfully" 
          : "New deal has been created successfully",
      });
      
      navigate("/deals");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    mutation.mutate(data);
  };

  const addMilestone = () => {
    if (newMilestone.trim()) {
      setMilestones([...milestones, { title: newMilestone, completed: false }]);
      setNewMilestone("");
    }
  };

  const addRequirement = () => {
    if (newRequirement.trim()) {
      setRequirementsList([...requirementsList, newRequirement]);
      setNewRequirement("");
    }
  };

  if (isDealLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Button 
          variant="ghost" 
          onClick={() => navigate("/deals")}
          className="mb-2"
        >
          Back to Deals
        </Button>
        <h1 className="text-3xl font-bold">{isEditMode ? "Edit Deal" : "Add Deal"}</h1>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
        {/* Basic Deal Information */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Deal Information</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name">Deal Name</Label>
              <Input id="name" {...register("name")} placeholder="e.g., Website Project for Client X" />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="contact_id">Client</Label>
              <Select onValueChange={(value) => setValue("contact_id", value)} defaultValue={dealData?.contact_id}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a client" />
                </SelectTrigger>
                <SelectContent>
                  {contacts.map((contact: any) => (
                    <SelectItem key={contact.id} value={contact.id}>
                      {contact.business_name || `${contact.first_name} ${contact.last_name || ""}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="project_type">Project Type</Label>
              <Select onValueChange={(value) => setValue("project_type", value)} defaultValue={dealData?.project_type || ""}>
                <SelectTrigger>
                  <SelectValue placeholder="Select project type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Website">Website</SelectItem>
                  <SelectItem value="Landing Page">Landing Page</SelectItem>
                  <SelectItem value="E-commerce">E-commerce</SelectItem>
                  <SelectItem value="Branding">Branding</SelectItem>
                  <SelectItem value="Maintenance">Maintenance</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="service_package">Service Package</Label>
              <Select onValueChange={(value) => setValue("service_package", value)} defaultValue={dealData?.service_package || ""}>
                <SelectTrigger>
                  <SelectValue placeholder="Select service package" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Basic">Basic</SelectItem>
                  <SelectItem value="Standard">Standard</SelectItem>
                  <SelectItem value="Premium">Premium</SelectItem>
                  <SelectItem value="Custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2 col-span-full">
              <Label htmlFor="project_scope">Project Scope</Label>
              <Textarea 
                id="project_scope" 
                {...register("project_scope")} 
                placeholder="Brief description of the project scope..."
                className="min-h-[100px]"
              />
            </div>
            
            <div className="space-y-2 col-span-full">
              <Label>Requirements Received</Label>
              <div className="space-y-2">
                {requirementsList.map((requirement, index) => (
                  <div key={index} className="flex items-center">
                    <Checkbox checked={true} />
                    <span className="ml-2">{requirement}</span>
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="sm"
                      onClick={() => setRequirementsList(requirementsList.filter((_, i) => i !== index))}
                    >
                      Remove
                    </Button>
                  </div>
                ))}
                <div className="flex gap-2">
                  <Input 
                    value={newRequirement}
                    onChange={(e) => setNewRequirement(e.target.value)}
                    placeholder="Add a new requirement"
                  />
                  <Button type="button" onClick={addRequirement}>Add</Button>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Timeline and Progress */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Timeline & Progress</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="status">Deal Status</Label>
              <Select onValueChange={(value) => setValue("status", value)} defaultValue={dealData?.status || "new"}>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="Lead In">Lead In</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="Delivered">Delivered</SelectItem>
                  <SelectItem value="Closed - Paid">Closed - Paid</SelectItem>
                  <SelectItem value="Canceled">Canceled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>Start Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !startDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {startDate ? format(startDate, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={startDate}
                    onSelect={setStartDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="space-y-2">
              <Label>Expected Delivery Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !expectedDeliveryDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {expectedDeliveryDate ? format(expectedDeliveryDate, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={expectedDeliveryDate}
                    onSelect={setExpectedDeliveryDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="space-y-2">
              <Label>Actual Delivery Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !actualDeliveryDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {actualDeliveryDate ? format(actualDeliveryDate, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={actualDeliveryDate}
                    onSelect={setActualDeliveryDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="space-y-2 col-span-full">
              <Label>Milestones</Label>
              <div className="space-y-2">
                {milestones.map((milestone, index) => (
                  <div key={index} className="flex items-center">
                    <Checkbox 
                      checked={milestone.completed}
                      onCheckedChange={(checked) => {
                        const updatedMilestones = [...milestones];
                        updatedMilestones[index].completed = !!checked;
                        setMilestones(updatedMilestones);
                      }}
                    />
                    <span className="ml-2">{milestone.title}</span>
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="sm"
                      onClick={() => setMilestones(milestones.filter((_, i) => i !== index))}
                    >
                      Remove
                    </Button>
                  </div>
                ))}
                <div className="flex gap-2">
                  <Input 
                    value={newMilestone}
                    onChange={(e) => setNewMilestone(e.target.value)}
                    placeholder="Add a new milestone"
                  />
                  <Button type="button" onClick={addMilestone}>Add</Button>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Financial Details */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Financial Details</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="amount">Quoted Price ($)</Label>
              <Input 
                id="amount" 
                {...register("amount", { valueAsNumber: true })} 
                type="number" 
                placeholder="0.00" 
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="payment_status">Payment Status</Label>
              <Select onValueChange={(value) => setValue("payment_status", value)} defaultValue={dealData?.payment_status || ""}>
                <SelectTrigger>
                  <SelectValue placeholder="Select payment status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Partial">Partial</SelectItem>
                  <SelectItem value="Paid">Paid</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>Payment Received Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !paymentReceivedDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {paymentReceivedDate ? format(paymentReceivedDate, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={paymentReceivedDate}
                    onSelect={setPaymentReceivedDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="invoice_file">Invoice File</Label>
              <Input id="invoice_file" {...register("invoice_file")} placeholder="Invoice file URL" />
              {/* Note: In a real implementation, this would be a file upload component */}
            </div>
          </div>
        </div>
        
        {/* Communication and Notes */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Communication & Notes</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="client_notes">Client Notes</Label>
              <Textarea 
                id="client_notes" 
                {...register("client_notes")} 
                placeholder="Notes visible to the client..."
                className="min-h-[100px]"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="internal_notes">Internal Notes</Label>
              <Textarea 
                id="internal_notes" 
                {...register("internal_notes")} 
                placeholder="Internal notes not visible to the client..."
                className="min-h-[100px]"
              />
            </div>
          </div>
        </div>
        
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={() => navigate("/deals")}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting || mutation.isPending}>
            {isSubmitting || mutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                {isEditMode ? "Updating..." : "Creating..."}
              </>
            ) : (
              <>{isEditMode ? "Update Deal" : "Create Deal"}</>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}
