
import { ActivityList } from "@/components/activities/ActivityList";
import { EmailTemplates } from "@/components/activities/EmailTemplates";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Activity, 
  Plus, 
  Filter,
  Calendar,
  TrendingUp,
  Mail,
  FileText,
  Phone,
  Users
} from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";

const Activities = () => {
  const [filter, setFilter] = useState<string>("all");

  const activityTypes = [
    { value: "all", label: "All Activities", count: 45, icon: Activity },
    { value: "call", label: "Calls", count: 12, icon: Phone },
    { value: "email", label: "Emails", count: 8, icon: Mail },
    { value: "meeting", label: "Meetings", count: 6, icon: Users },
    { value: "note", label: "Notes", count: 15, icon: FileText },
    { value: "task", label: "Tasks", count: 4, icon: Calendar }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Activities</h1>
          <p className="text-gray-600 mt-1">
            Track all your customer interactions and activities
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button asChild>
            <Link to="/activities/add">
              <Plus className="h-4 w-4 mr-2" />
              Add Activity
            </Link>
          </Button>
        </div>
      </div>

      {/* Activity Type Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-blue-600" />
            Activity Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-6">
            {activityTypes.map((type) => {
              const Icon = type.icon;
              return (
                <button
                  key={type.value}
                  onClick={() => setFilter(type.value)}
                  className={`p-4 rounded-lg border text-left transition-all hover:shadow-md ${
                    filter === type.value 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <Icon className="h-4 w-4 text-gray-600" />
                    <Badge variant="secondary">{type.count}</Badge>
                  </div>
                  <div className="font-medium text-sm">{type.label}</div>
                  <div className="text-xs text-gray-500 flex items-center mt-1">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    +12% this week
                  </div>
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Activity Stats */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Today's Activities</p>
                <h3 className="text-2xl font-bold mt-1">8</h3>
              </div>
              <div className="p-3 rounded-full bg-blue-100">
                <Calendar className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="mt-4 text-xs text-green-600">
              +25% from yesterday
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">This Week</p>
                <h3 className="text-2xl font-bold mt-1">45</h3>
              </div>
              <div className="p-3 rounded-full bg-green-100">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="mt-4 text-xs text-green-600">
              +12% from last week
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Follow-ups Due</p>
                <h3 className="text-2xl font-bold mt-1">6</h3>
              </div>
              <div className="p-3 rounded-full bg-orange-100">
                <Activity className="h-6 w-6 text-orange-600" />
              </div>
            </div>
            <div className="mt-4 text-xs text-orange-600">
              3 overdue
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="activities" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="activities" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Activities
          </TabsTrigger>
          <TabsTrigger value="templates" className="flex items-center gap-2">
            <Mail className="h-4 w-4" />
            Email Templates
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="activities" className="space-y-6">
          <ActivityList filter={filter} />
        </TabsContent>
        
        <TabsContent value="templates" className="space-y-6">
          <EmailTemplates />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Activities;
