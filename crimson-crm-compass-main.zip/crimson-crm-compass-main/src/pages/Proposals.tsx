
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ProposalBuilder } from "@/components/proposals/ProposalBuilder";
import { BrandGuidelinesManager } from "@/components/proposals/BrandGuidelinesManager";
import { ProposalList } from "@/components/proposals/ProposalList";

export default function Proposals() {
  return (
    <div className="container mx-auto p-6">
      <Tabs defaultValue="builder" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="builder">Proposal Builder</TabsTrigger>
          <TabsTrigger value="proposals">My Proposals</TabsTrigger>
          <TabsTrigger value="brand">Brand Guidelines</TabsTrigger>
        </TabsList>
        
        <TabsContent value="builder" className="mt-6">
          <ProposalBuilder />
        </TabsContent>
        
        <TabsContent value="proposals" className="mt-6">
          <ProposalList />
        </TabsContent>
        
        <TabsContent value="brand" className="mt-6">
          <BrandGuidelinesManager />
        </TabsContent>
      </Tabs>
    </div>
  );
}
