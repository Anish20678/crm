
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import {
  ChevronLeft,
  Pencil,
  Trash2,
  MessageCircle,
  Phone,
  Mail,
  FileUp,
  Download,
  Eye,
  Check,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { Deal } from "@/lib/types";

export default function DealDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [newNote, setNewNote] = useState("");

  const { data: dealData, isLoading, error } = useQuery({
    queryKey: ["deal", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("deals")
        .select(`
          *,
          contacts(first_name, last_name, business_name, email, phone)
        `)
        .eq("id", id)
        .single();
      
      if (error) throw error;
      return data;
    },
  });

  const handleDelete = async () => {
    try {
      const { error } = await supabase
        .from("deals")
        .delete()
        .eq("id", id);
      
      if (error) throw error;
      
      toast({
        title: "Deal deleted",
        description: "The deal has been successfully deleted.",
      });
      
      navigate("/deals");
    } catch (error) {
      console.error("Error deleting deal:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete the deal. Please try again.",
      });
    }
  };

  const getStatusColor = (status: string | null) => {
    switch (status) {
      case "Lead In":
        return "bg-blue-500";
      case "In Progress":
        return "bg-yellow-500";
      case "Delivered":
        return "bg-green-500";
      case "Closed - Paid":
        return "bg-purple-500";
      case "Canceled":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };

  // Mock function to add note
  const addNote = () => {
    if (!newNote.trim()) return;
    toast({
      title: "Note added",
      description: "Your note has been added to the deal.",
    });
    setNewNote("");
    // In a real implementation, this would update the timeline with the new note
  };

  // Generate dummy timeline events for demonstration
  const generateTimelineEvents = (deal: any) => {
    if (!deal) return [];
    
    const events = [
      {
        type: "creation",
        label: "Deal Created",
        description: `Deal "${deal.name}" was created`,
        date: deal.created_at,
      },
    ];
    
    if (deal.status === "In Progress") {
      events.push({
        type: "status",
        label: "Status Update",
        description: `Deal status changed to "In Progress"`,
        date: new Date(new Date(deal.created_at).getTime() + 86400000).toISOString(),
      });
    }
    
    if (deal.status === "Delivered" || deal.status === "Closed - Paid") {
      events.push({
        type: "status",
        label: "Status Update",
        description: `Deal status changed to "In Progress"`,
        date: new Date(new Date(deal.created_at).getTime() + 86400000).toISOString(),
      });
      
      events.push({
        type: "status",
        label: "Status Update",
        description: `Deal status changed to "Delivered"`,
        date: new Date(new Date(deal.created_at).getTime() + 172800000).toISOString(),
      });
    }
    
    if (deal.status === "Closed - Paid") {
      events.push({
        type: "payment",
        label: "Payment Received",
        description: `Payment of $${deal.amount?.toLocaleString()} received`,
        date: new Date(new Date(deal.created_at).getTime() + 259200000).toISOString(),
      });
      
      events.push({
        type: "status",
        label: "Status Update",
        description: `Deal status changed to "Closed - Paid"`,
        date: new Date(new Date(deal.created_at).getTime() + 259200000).toISOString(),
      });
    }
    
    return events.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        Loading deal details...
      </div>
    );
  }

  if (error || !dealData) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        Error loading deal details. Please try again later.
      </div>
    );
  }

  const deal = dealData as Deal & { contacts: any };
  const contactName = deal.contacts?.business_name || 
    `${deal.contacts?.first_name || ''} ${deal.contacts?.last_name || ''}`;

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header section */}
      <div className="mb-6">
        <Button 
          variant="ghost" 
          onClick={() => navigate("/deals")}
          className="mb-2"
        >
          <ChevronLeft className="mr-2 h-4 w-4" />
          Back to Deals
        </Button>
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <h1 className="text-3xl font-bold">{deal.name}</h1>
            <div className="flex items-center mt-2">
              <Badge variant="outline" className={`${getStatusColor(deal.status)} text-white`}>
                {deal.status || "No Status"}
              </Badge>
              <span className="ml-2">
                {contactName}
              </span>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 mt-4 md:mt-0">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => navigate(`/deals/edit/${deal.id}`)}
            >
              <Pencil className="mr-1 h-4 w-4" />
              Edit
            </Button>

            {deal.contacts?.phone && (
              <Button variant="outline" size="sm">
                <Phone className="mr-1 h-4 w-4" />
                Call
              </Button>
            )}

            {deal.contacts?.email && (
              <Button variant="outline" size="sm">
                <Mail className="mr-1 h-4 w-4" />
                Email
              </Button>
            )}

            <Button variant="outline" size="sm">
              <MessageCircle className="mr-1 h-4 w-4" />
              WhatsApp
            </Button>

            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="text-red-500 hover:bg-red-50">
                  <Trash2 className="mr-1 h-4 w-4" />
                  Delete
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Delete Deal</DialogTitle>
                </DialogHeader>
                <p>Are you sure you want to delete this deal? This action cannot be undone.</p>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setConfirmDelete(false)}>Cancel</Button>
                  <Button variant="destructive" onClick={handleDelete}>Delete</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <div className="grid gap-6">
            {/* Section 1: Basic Information */}
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">Deal Information</h2>
                <Separator className="mb-6" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Project Type</h3>
                    <p className="mt-1">{deal.project_type || "Not specified"}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Service Package</h3>
                    <p className="mt-1">{deal.service_package || "Not specified"}</p>
                  </div>

                  <div className="md:col-span-2">
                    <h3 className="text-sm font-medium text-gray-500">Project Scope</h3>
                    <p className="mt-1 whitespace-pre-line">{deal.project_scope || "No project scope defined"}</p>
                  </div>

                  <div className="md:col-span-2">
                    <h3 className="text-sm font-medium text-gray-500">Requirements Received</h3>
                    <div className="mt-1">
                      {deal.requirements_received && deal.requirements_received.length > 0 ? (
                        <ul className="list-disc pl-5">
                          {deal.requirements_received.map((req: string, index: number) => (
                            <li key={index}>{req}</li>
                          ))}
                        </ul>
                      ) : (
                        <p>No requirements specified</p>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Section 2: Timeline and Progress */}
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">Timeline & Progress</h2>
                <Separator className="mb-6" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Start Date</h3>
                    <p className="mt-1">
                      {deal.start_date 
                        ? format(new Date(deal.start_date), "MMMM d, yyyy") 
                        : "Not set"}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Expected Delivery Date</h3>
                    <p className="mt-1">
                      {deal.expected_delivery_date 
                        ? format(new Date(deal.expected_delivery_date), "MMMM d, yyyy") 
                        : "Not set"}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Actual Delivery Date</h3>
                    <p className="mt-1">
                      {deal.actual_delivery_date 
                        ? format(new Date(deal.actual_delivery_date), "MMMM d, yyyy") 
                        : "Not delivered yet"}
                    </p>
                  </div>

                  <div className="md:col-span-2">
                    <h3 className="text-sm font-medium text-gray-500">Milestones</h3>
                    <div className="mt-3">
                      {deal.milestones && deal.milestones.length > 0 ? (
                        <ul className="space-y-2">
                          {deal.milestones.map((milestone: any, index: number) => (
                            <li key={index} className="flex items-center">
                              {milestone.completed ? (
                                <Check className="h-5 w-5 text-green-500 mr-2" />
                              ) : (
                                <div className="h-5 w-5 border rounded-full mr-2"></div>
                              )}
                              <span className={milestone.completed ? "line-through text-gray-500" : ""}>
                                {milestone.title}
                              </span>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p>No milestones defined</p>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Section 3: Financial Details */}
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">Financial Details</h2>
                <Separator className="mb-6" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Quoted Price</h3>
                    <p className="mt-1 text-xl font-semibold">
                      {deal.amount ? `$${deal.amount.toLocaleString()}` : "Not quoted"}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Payment Status</h3>
                    <p className="mt-1">
                      <Badge variant={deal.payment_status === "Paid" ? "default" : "outline"}>
                        {deal.payment_status || "Not set"}
                      </Badge>
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Payment Received Date</h3>
                    <p className="mt-1">
                      {deal.payment_received_date 
                        ? format(new Date(deal.payment_received_date), "MMMM d, yyyy") 
                        : "Not received yet"}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Invoice</h3>
                    <div className="mt-1">
                      {deal.invoice_file ? (
                        <div className="flex items-center">
                          <Button variant="outline" size="sm" className="text-blue-500">
                            <Download className="mr-2 h-4 w-4" />
                            Download Invoice
                          </Button>
                        </div>
                      ) : (
                        <p>No invoice uploaded</p>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Section 4: Communication and Notes */}
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">Communication & Notes</h2>
                <Separator className="mb-6" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Client Notes</h3>
                    <p className="mt-1 whitespace-pre-line">
                      {deal.client_notes || "No client notes"}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Internal Notes</h3>
                    <p className="mt-1 whitespace-pre-line">
                      {deal.internal_notes || "No internal notes"}
                    </p>
                  </div>
                  
                  <div className="md:col-span-2">
                    <h3 className="text-sm font-medium text-gray-500">Add a Note</h3>
                    <div className="mt-2 flex gap-2">
                      <Textarea
                        value={newNote}
                        onChange={(e) => setNewNote(e.target.value)}
                        placeholder="Add a new note..."
                        className="flex-1"
                      />
                      <Button className="self-end" onClick={addNote}>Add Note</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Section 5: File Management */}
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">File Management</h2>
                <Separator className="mb-6" />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Project Files</h3>
                    <div className="mt-2">
                      {deal.project_files && deal.project_files.length > 0 ? (
                        <ul className="space-y-2">
                          {deal.project_files.map((file: string, index: number) => (
                            <li key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                              <span>{file.split("_")[1] || file}</span>
                              <div className="flex gap-1">
                                <Button variant="ghost" size="sm">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm">
                                  <Download className="h-4 w-4" />
                                </Button>
                              </div>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p>No project files uploaded</p>
                      )}
                      
                      <Button variant="outline" className="mt-4">
                        <FileUp className="mr-2 h-4 w-4" />
                        Upload File
                      </Button>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Final Deliverables</h3>
                    <div className="mt-2">
                      {deal.final_deliverables && deal.final_deliverables.length > 0 ? (
                        <ul className="space-y-2">
                          {deal.final_deliverables.map((file: string, index: number) => (
                            <li key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                              <span>{file.split("_")[1] || file}</span>
                              <div className="flex gap-1">
                                <Button variant="ghost" size="sm">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm">
                                  <Download className="h-4 w-4" />
                                </Button>
                              </div>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p>No deliverables uploaded</p>
                      )}
                      
                      <Button variant="outline" className="mt-4">
                        <FileUp className="mr-2 h-4 w-4" />
                        Upload Deliverable
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="timeline">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Activity Timeline</h2>
              <Separator className="mb-6" />
              
              <div className="space-y-6">
                {generateTimelineEvents(deal).map((event, index) => (
                  <div key={index} className="relative pl-8 pb-6">
                    {/* Timeline vertical line */}
                    {index < generateTimelineEvents(deal).length - 1 && (
                      <div className="absolute top-2 left-2 w-px h-full -ml-px bg-gray-200"></div>
                    )}
                    
                    {/* Circle marker */}
                    <div className={`absolute top-1 left-0 w-4 h-4 rounded-full ${
                      event.type === "creation" ? "bg-green-500" :
                      event.type === "status" ? "bg-blue-500" :
                      event.type === "payment" ? "bg-purple-500" : "bg-gray-500"
                    }`}></div>
                    
                    <div>
                      <p className="font-medium">{event.label}</p>
                      <p className="text-sm text-gray-600">{event.description}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {format(new Date(event.date), "MMM d, yyyy 'at' h:mm a")}
                      </p>
                    </div>
                  </div>
                ))}
                
                {generateTimelineEvents(deal).length === 0 && (
                  <p>No activity recorded yet.</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
