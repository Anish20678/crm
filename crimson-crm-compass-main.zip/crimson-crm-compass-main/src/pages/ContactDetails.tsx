
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Contact, Deal } from "@/lib/types";
import { toast } from "@/hooks/use-toast";
import {
  ArrowLeft,
  Mail,
  MessageSquare,
  Phone,
  Pencil,
  Trash2,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function ContactDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  
  // Fetch contact data
  const {
    data: contact,
    isLoading: isContactLoading,
    error: contactError,
  } = useQuery({
    queryKey: ["contact", id],
    queryFn: async () => {
      if (!id) throw new Error("Contact ID is required");

      const { data, error } = await supabase
        .from("contacts")
        .select("*")
        .eq("id", id)
        .single();

      if (error) {
        toast({
          title: "Error loading contact",
          description: error.message,
          variant: "destructive",
        });
        throw error;
      }

      return data as Contact;
    },
  });
  
  // Fetch deals related to this contact
  const {
    data: deals = [],
    isLoading: isDealsLoading,
  } = useQuery({
    queryKey: ["contact-deals", id],
    queryFn: async () => {
      if (!id) return [];

      const { data, error } = await supabase
        .from("deals")
        .select("*")
        .eq("contact_id", id)
        .order("created_at", { ascending: false });

      if (error) {
        toast({
          title: "Error loading deals",
          description: error.message,
          variant: "destructive",
        });
        throw error;
      }

      return data as Deal[];
    },
    enabled: !!id,
  });

  // Delete contact mutation
  const deleteContactMutation = useMutation({
    mutationFn: async () => {
      if (!id) throw new Error("Contact ID is required");

      const { error } = await supabase.from("contacts").delete().eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Contact deleted",
        description: "Contact has been deleted successfully",
      });
      navigate("/contacts");
    },
    onError: (error: any) => {
      toast({
        title: "Error deleting contact",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function handleDelete() {
    deleteContactMutation.mutate();
  }

  function handleEdit() {
    navigate(`/contacts/edit/${id}`);
  }

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "—";
    try {
      return format(new Date(dateString), "PPP");
    } catch (error) {
      return dateString;
    }
  };

  if (isContactLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div>Loading contact details...</div>
      </div>
    );
  }

  if (contactError || !contact) {
    return (
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <Button variant="ghost" onClick={() => navigate("/contacts")}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Contacts
          </Button>
        </div>
        <div className="flex flex-col items-center justify-center min-h-[40vh]">
          <h2 className="text-xl font-semibold mb-2">Contact not found</h2>
          <p className="text-muted-foreground mb-4">
            The contact you're looking for doesn't exist or has been removed.
          </p>
          <Button onClick={() => navigate("/contacts")}>Return to Contacts</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Back button and header */}
      <div className="flex items-center space-x-2">
        <Button variant="ghost" onClick={() => navigate("/contacts")}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Contacts
        </Button>
      </div>

      {/* Contact header */}
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-semibold">
              {contact.first_name} {contact.last_name}
            </h1>
            <Badge variant="default">Client</Badge>
          </div>
          {contact.business_name && (
            <p className="text-gray-500 mt-1">{contact.business_name}</p>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex space-x-2">
          {contact.phone && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  window.open(
                    `https://wa.me/${contact.phone?.replace(/\D/g, "")}`,
                    "_blank"
                  )
                }
              >
                <MessageSquare className="mr-2 h-4 w-4 text-green-600" />
                WhatsApp
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open(`tel:${contact.phone}`, "_blank")}
              >
                <Phone className="mr-2 h-4 w-4 text-blue-600" />
                Call
              </Button>
            </>
          )}

          {contact.email && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open(`mailto:${contact.email}`, "_blank")}
            >
              <Mail className="mr-2 h-4 w-4" />
              Email
            </Button>
          )}

          <Button onClick={handleEdit} size="sm">
            <Pencil className="mr-2 h-4 w-4" />
            Edit
          </Button>

          <Button
            variant="destructive"
            size="sm"
            onClick={() => setIsDeleteDialogOpen(true)}
          >
            <Trash2 className="mr-2 h-4 w-4" />
            Delete
          </Button>
        </div>
      </div>

      {/* Tabs for Overview and Deals */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="deals">Deals</TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6 mt-6">
          {/* Basic Information Section */}
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Basic Information</h2>
              <Separator className="mb-6" />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">First Name</p>
                    <div>{contact.first_name}</div>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Email</p>
                    <div>{contact.email || "—"}</div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Last Name</p>
                    <div>{contact.last_name || "—"}</div>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Phone</p>
                    <div>{contact.phone || "—"}</div>
                  </div>
                </div>
                
                {/* Additional Phone Numbers */}
                {Array.isArray(contact.phone_numbers) && contact.phone_numbers.length > 0 && (
                  <div className="col-span-2">
                    <p className="text-sm text-muted-foreground">Additional Phone Numbers</p>
                    <div className="space-y-2 mt-1">
                      {contact.phone_numbers.map((phone, index) => (
                        <div key={index} className="flex items-center">
                          <span>{phone}</span>
                          <div className="flex ml-2 space-x-1">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8" 
                              onClick={() => window.open(`https://wa.me/${phone.replace(/\D/g, '')}`, '_blank')}
                            >
                              <MessageSquare className="h-4 w-4 text-green-600" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8" 
                              onClick={() => window.open(`tel:${phone}`, '_blank')}
                            >
                              <Phone className="h-4 w-4 text-blue-600" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Business Details Section */}
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Business Details</h2>
              <Separator className="mb-6" />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Business Name</p>
                    <div>{contact.business_name || "—"}</div>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Business Type</p>
                    <div>{contact.business_type || "—"}</div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Emirates</p>
                    <div>{contact.emirates || "—"}</div>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Position</p>
                    <div>{contact.position || "—"}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact Information Section */}
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Contact Information</h2>
              <Separator className="mb-6" />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Lead Source</p>
                    <div>{contact.lead_source || "—"}</div>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground">Preferred Contact Method</p>
                    <div>{contact.preferred_contact_method || "—"}</div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Creation Date</p>
                    <div>{formatDate(contact.created_at)}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Notes Section - Full Width */}
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Notes</h2>
              <Separator className="mb-6" />
              
              <div>
                <p className="whitespace-pre-wrap">{contact.notes || "No notes available for this contact."}</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Deals Tab */}
        <TabsContent value="deals" className="mt-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Deals</h2>
                <Button onClick={() => navigate(`/deals/add?contact_id=${contact.id}`)}>
                  Add Deal
                </Button>
              </div>
              <Separator className="mb-6" />
              
              {isDealsLoading ? (
                <div className="text-center py-8">Loading deals...</div>
              ) : deals.length === 0 ? (
                <div className="text-center py-8">
                  No deals found for this contact.
                </div>
              ) : (
                <div className="space-y-4">
                  {deals.map((deal) => (
                    <Card key={deal.id} className="overflow-hidden">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-medium">{deal.name}</h3>
                            <div className="flex items-center mt-1">
                              <Badge className={cn(
                                deal.status === "Lead In" && "bg-blue-500",
                                deal.status === "In Progress" && "bg-yellow-500",
                                deal.status === "Delivered" && "bg-green-500",
                                deal.status === "Closed - Paid" && "bg-purple-500",
                                (deal.status !== "Lead In" && 
                                 deal.status !== "In Progress" && 
                                 deal.status !== "Delivered" && 
                                 deal.status !== "Closed - Paid") && "bg-gray-500",
                                "text-white"
                              )}>
                                {deal.status || "No Status"}
                              </Badge>
                              {deal.amount && (
                                <span className="ml-2 text-sm text-muted-foreground">
                                  ${deal.amount.toLocaleString()}
                                </span>
                              )}
                            </div>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => navigate(`/deals/${deal.id}`)}
                          >
                            View
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Delete confirmation dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Contact</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {contact.first_name}{" "}
              {contact.last_name || ""}? This action cannot be undone.
              {deals.length > 0 && (
                <p className="mt-2 text-red-500">
                  Warning: This contact has {deals.length} associated deal(s). Deleting this contact may affect those deals.
                </p>
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={deleteContactMutation.isPending}
            >
              {deleteContactMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
