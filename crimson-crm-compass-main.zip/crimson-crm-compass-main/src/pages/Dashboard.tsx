
import { DashboardMetricsComponent } from "@/components/dashboard/DashboardMetrics";
import { AIInsights } from "@/components/dashboard/AIInsights";
import { SalesChart } from "@/components/dashboard/SalesChart";
import { useDashboardMetrics, useAIInsights, useSalesAnalytics } from "@/hooks/useDashboardData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  CalendarDays, 
  Users, 
  TrendingUp, 
  DollarSign,
  Plus,
  ArrowRight
} from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const navigate = useNavigate();
  const { data: metrics, isLoading: metricsLoading } = useDashboardMetrics();
  const { data: insights, isLoading: insightsLoading } = useAIInsights();
  const { data: salesData, isLoading: salesLoading } = useSalesAnalytics();

  const quickActions = [
    {
      title: "Add Contact",
      description: "Create a new contact",
      icon: Users,
      action: () => navigate("/contacts/add"),
      color: "bg-blue-500 hover:bg-blue-600",
    },
    {
      title: "Create Deal",
      description: "Start a new deal",
      icon: DollarSign,
      action: () => navigate("/deals/add"),
      color: "bg-green-500 hover:bg-green-600",
    },
    {
      title: "Add Task",
      description: "Create a new task",
      icon: CalendarDays,
      action: () => navigate("/tasks/add"),
      color: "bg-purple-500 hover:bg-purple-600",
    },
    {
      title: "View Analytics",
      description: "See detailed reports",
      icon: TrendingUp,
      action: () => navigate("/analytics"),
      color: "bg-orange-500 hover:bg-orange-600",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">Dashboard</h1>
          <p className="text-gray-600 mt-1">
            Welcome back! Here's what's happening with your business.
          </p>
        </div>
        <Badge variant="secondary" className="bg-purple-100 text-purple-800">
          AI-Powered CRM
        </Badge>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Button
                  key={action.title}
                  variant="outline"
                  className={`h-auto p-4 flex flex-col items-center gap-2 ${action.color} text-white border-0 hover:shadow-lg transition-all`}
                  onClick={action.action}
                >
                  <Icon className="h-6 w-6" />
                  <div className="text-center">
                    <div className="font-medium">{action.title}</div>
                    <div className="text-xs opacity-90">{action.description}</div>
                  </div>
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Dashboard Metrics */}
      <DashboardMetricsComponent 
        metrics={metrics || {
          totalContacts: 0,
          totalDeals: 0,
          totalRevenue: 0,
          activeDeals: 0,
          conversionRate: 0,
          avgDealSize: 0,
          overdueTasks: 0,
          upcomingFollowUps: 0,
        }} 
        isLoading={metricsLoading} 
      />

      {/* Charts and AI Insights */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Sales Charts */}
        <div className="space-y-6">
          <SalesChart
            data={salesData || []}
            type="line"
            title="Revenue Trend"
            isLoading={salesLoading}
          />
          <SalesChart
            data={salesData || []}
            type="bar"
            title="Monthly Performance"
            isLoading={salesLoading}
          />
        </div>

        {/* AI Insights */}
        <div className="space-y-6">
          <AIInsights 
            insights={insights || []} 
            isLoading={insightsLoading} 
          />
          
          {/* Recent Activity Summary */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Recent Activity</CardTitle>
              <Button variant="ghost" size="sm" onClick={() => navigate("/activities")}>
                View All <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-gray-500">
                <CalendarDays className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>No recent activity</p>
                <p className="text-sm">Activity will appear here as you use the CRM</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Call-to-action for new users */}
      {metrics?.totalContacts === 0 && (
        <Card className="border-dashed border-2 border-gray-300">
          <CardContent className="p-8 text-center">
            <Plus className="h-12 w-12 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-semibold mb-2">Get Started with Your CRM</h3>
            <p className="text-gray-600 mb-4">
              Start by adding your first contact or creating a deal to see your dashboard come to life.
            </p>
            <div className="flex gap-2 justify-center">
              <Button onClick={() => navigate("/contacts/add")}>
                Add First Contact
              </Button>
              <Button variant="outline" onClick={() => navigate("/deals/add")}>
                Create First Deal
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
