
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Eye, Edit, Trash2, Plus, ColumnsIcon, PlusCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Contact } from "@/lib/types";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Column, ColumnManager } from "@/components/contacts/ColumnManager";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useBulkSelection } from "@/hooks/useBulkSelection";
import { BulkActionHeader } from "@/components/bulk-actions/BulkActionHeader";
import { BulkActionBar } from "@/components/bulk-actions/BulkActionBar";
import { ConfirmationDialog } from "@/components/bulk-actions/ConfirmationDialog";
import { Checkbox } from "@/components/ui/checkbox";
import { format } from "date-fns";

export default function Contacts() {
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [currentContact, setCurrentContact] = useState<Contact | null>(null);
  const [isColumnManagerOpen, setIsColumnManagerOpen] = useState(false);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [showCreateDealsConfirmation, setShowCreateDealsConfirmation] = useState(false);
  const [columns, setColumns] = useState<Column[]>([
    { id: "select", label: "Select", visible: true },
    { id: "name", label: "Name", visible: true },
    { id: "business", label: "Business", visible: true },
    { id: "phone", label: "Phone", visible: true },
    { id: "email", label: "Email", visible: true },
    { id: "emirates", label: "Emirates", visible: true },
    { id: "createdFrom", label: "Created From", visible: true },
    { id: "actions", label: "Actions", visible: true },
  ]);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: contacts = [], isLoading } = useQuery({
    queryKey: ["contacts"],
    queryFn: async () => {
      let query = supabase
        .from("contacts")
        .select("*")
        .eq("is_client", true)
        .order("created_at", { ascending: false });
      
      const { data, error } = await query;
      
      if (error) {
        toast({
          title: "Error loading contacts",
          description: error.message,
          variant: "destructive",
        });
        throw error;
      }
      
      return data as Contact[];
    },
  });

  const {
    selectedIds,
    selectedItems,
    selectedCount,
    isSelected,
    toggleSelection,
    selectAll,
    clearSelection,
  } = useBulkSelection(contacts || []);

  const deleteContactMutation = useMutation({
    mutationFn: async () => {
      if (!currentContact) throw new Error("No contact selected");
      
      const { error } = await supabase
        .from("contacts")
        .delete()
        .eq("id", currentContact.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Contact deleted",
        description: "Contact has been deleted successfully",
      });
      setIsDeleteDialogOpen(false);
      setCurrentContact(null);
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error deleting contact",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const bulkDeleteMutation = useMutation({
    mutationFn: async (contactIds: string[]) => {
      const { error } = await supabase
        .from("contacts")
        .delete()
        .in("id", contactIds);
      
      if (error) throw error;
    },
    onSuccess: (_, contactIds) => {
      toast({
        title: "Contacts deleted",
        description: `${contactIds.length} contact${contactIds.length > 1 ? 's' : ''} deleted successfully`,
      });
      clearSelection();
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error deleting contacts",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const bulkCreateDealsMutation = useMutation({
    mutationFn: async (contacts: Contact[]) => {
      const currentDate = new Date();
      const month = format(currentDate, "MMMM");
      const year = format(currentDate, "yyyy");
      
      // Create deals for all contacts
      const dealsToInsert = contacts.map(contact => ({
        contact_id: contact.id,
        name: contact.business_name 
          ? `${month} ${year} - ${contact.business_name}`
          : `${month} ${year} - ${contact.first_name} ${contact.last_name || ""}`.trim(),
        status: 'new',
      }));
      
      const { data, error } = await supabase
        .from("deals")
        .insert(dealsToInsert)
        .select();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (_, contacts) => {
      toast({
        title: "Deals created",
        description: `${contacts.length} deal${contacts.length > 1 ? 's' : ''} created successfully`,
      });
      clearSelection();
      queryClient.invalidateQueries({ queryKey: ["deals"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error creating deals",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function handleViewContact(contact: Contact) {
    navigate(`/contacts/${contact.id}`);
  }

  function handleEditContact(contact: Contact) {
    navigate(`/contacts/edit/${contact.id}`);
  }

  function handleAddContact() {
    navigate("/contacts/add");
  }

  function handleDeleteContact(contact: Contact) {
    setCurrentContact(contact);
    setIsDeleteDialogOpen(true);
  }

  const handleBulkDelete = () => {
    setShowDeleteConfirmation(true);
  };

  const handleBulkCreateDeals = () => {
    setShowCreateDealsConfirmation(true);
  };

  const confirmBulkDelete = () => {
    const selectedContactIds = selectedItems.map(contact => contact.id);
    bulkDeleteMutation.mutate(selectedContactIds);
    setShowDeleteConfirmation(false);
  };

  const confirmBulkCreateDeals = () => {
    bulkCreateDealsMutation.mutate(selectedItems);
    setShowCreateDealsConfirmation(false);
  };

  const handleColumnChange = (newColumns: Column[]) => {
    setColumns(newColumns);
  };

  const visibleColumns = columns.filter(col => col.visible);

  const bulkActions = [
    {
      id: "create-deals",
      label: "Create Deals",
      icon: <PlusCircle className="h-4 w-4" />,
      variant: "default" as const,
      onClick: handleBulkCreateDeals,
    },
    {
      id: "delete",
      label: "Delete",
      icon: <Trash2 className="h-4 w-4" />,
      variant: "destructive" as const,
      onClick: handleBulkDelete,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-semibold">Contacts</h1>
        <Button onClick={handleAddContact}>
          <Plus className="h-4 w-4 mr-2" /> Add Contact
        </Button>
      </div>

      <div className="flex justify-end mb-2">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setIsColumnManagerOpen(true)}
              >
                <ColumnsIcon className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Manage Columns</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      {isLoading ? (
        <div className="text-center py-8">Loading contacts...</div>
      ) : contacts.length === 0 ? (
        <div className="text-center py-8">
          No contacts found. Create your first contact by clicking "Add Contact" or by converting leads to clients.
        </div>
      ) : (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                {columns.find(c => c.id === "select" && c.visible) && (
                  <TableHead className="w-12">
                    <BulkActionHeader
                      selectedCount={selectedCount}
                      totalCount={contacts.length}
                      onSelectAll={selectAll}
                      onClearSelection={clearSelection}
                    />
                  </TableHead>
                )}
                {columns.find(c => c.id === "name" && c.visible) && (
                  <TableHead>Name</TableHead>
                )}
                {columns.find(c => c.id === "business" && c.visible) && (
                  <TableHead>Business</TableHead>
                )}
                {columns.find(c => c.id === "phone" && c.visible) && (
                  <TableHead>Phone</TableHead>
                )}
                {columns.find(c => c.id === "email" && c.visible) && (
                  <TableHead>Email</TableHead>
                )}
                {columns.find(c => c.id === "emirates" && c.visible) && (
                  <TableHead>Emirates</TableHead>
                )}
                {columns.find(c => c.id === "createdFrom" && c.visible) && (
                  <TableHead>Created From</TableHead>
                )}
                {columns.find(c => c.id === "actions" && c.visible) && (
                  <TableHead className="text-right">Actions</TableHead>
                )}
              </TableRow>
            </TableHeader>
            <TableBody>
              {contacts.map((contact) => (
                <TableRow key={contact.id}>
                  {columns.find(c => c.id === "select" && c.visible) && (
                    <TableCell>
                      <Checkbox
                        checked={isSelected(contact.id)}
                        onCheckedChange={() => toggleSelection(contact.id)}
                        aria-label={`Select contact ${contact.first_name} ${contact.last_name}`}
                      />
                    </TableCell>
                  )}
                  {columns.find(c => c.id === "name" && c.visible) && (
                    <TableCell className="font-medium">
                      {contact.first_name} {contact.last_name || ""}
                    </TableCell>
                  )}
                  {columns.find(c => c.id === "business" && c.visible) && (
                    <TableCell>{contact.business_name || contact.company || "—"}</TableCell>
                  )}
                  {columns.find(c => c.id === "phone" && c.visible) && (
                    <TableCell>{contact.phone || "—"}</TableCell>
                  )}
                  {columns.find(c => c.id === "email" && c.visible) && (
                    <TableCell>{contact.email || "—"}</TableCell>
                  )}
                  {columns.find(c => c.id === "emirates" && c.visible) && (
                    <TableCell>{contact.emirates || "—"}</TableCell>
                  )}
                  {columns.find(c => c.id === "createdFrom" && c.visible) && (
                    <TableCell>
                      <Badge variant={contact.lead_source ? "secondary" : "outline"}>
                        {contact.lead_source ? "Lead" : "Manual"}
                      </Badge>
                    </TableCell>
                  )}
                  {columns.find(c => c.id === "actions" && c.visible) && (
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleViewContact(contact)}
                          className="flex items-center gap-1"
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleEditContact(contact)}
                          className="flex items-center gap-1"
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleDeleteContact(contact)}
                          className="flex items-center gap-1 text-red-600"
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
      
      <BulkActionBar
        selectedCount={selectedCount}
        onClearSelection={clearSelection}
        actions={bulkActions}
      />

      <ConfirmationDialog
        open={showDeleteConfirmation}
        onOpenChange={setShowDeleteConfirmation}
        title="Delete Contacts"
        description={`Are you sure you want to delete ${selectedCount} contact${selectedCount > 1 ? 's' : ''}? This action cannot be undone.`}
        confirmLabel="Delete"
        confirmVariant="destructive"
        onConfirm={confirmBulkDelete}
        isLoading={bulkDeleteMutation.isPending}
      />

      <ConfirmationDialog
        open={showCreateDealsConfirmation}
        onOpenChange={setShowCreateDealsConfirmation}
        title="Create Deals"
        description={`Are you sure you want to create deals for ${selectedCount} contact${selectedCount > 1 ? 's' : ''}?`}
        confirmLabel="Create Deals"
        confirmVariant="default"
        onConfirm={confirmBulkCreateDeals}
        isLoading={bulkCreateDealsMutation.isPending}
      />

      <ColumnManager
        columns={columns}
        open={isColumnManagerOpen}
        onOpenChange={setIsColumnManagerOpen}
        onColumnsChange={handleColumnChange}
      />

      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Contact</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete{" "}
              {currentContact ? `${currentContact.first_name} ${currentContact.last_name || ""}` : ""}?
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={() => deleteContactMutation.mutate()} disabled={deleteContactMutation.isPending}>
              {deleteContactMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
