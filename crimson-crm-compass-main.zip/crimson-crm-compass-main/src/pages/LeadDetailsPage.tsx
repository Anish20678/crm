
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Contact } from "@/lib/types";
import { format } from "date-fns";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import {
  Mail,
  MessageSquare,
  Phone,
  BadgeDollarSign,
  Pencil,
  Check,
  X,
  Trash2,
  ArrowLeft,
  ExternalLink,
  FileText,
  Calendar,
  Clock,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { DealForm, DealFormValues } from "@/components/contacts/DealForm";

export default function LeadDetailsPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDealDialogOpen, setIsDealDialogOpen] = useState(false);
  const [editingField, setEditingField] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<string | boolean | null>(null);

  // Fetch lead data
  const {
    data: lead,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["lead", id],
    queryFn: async () => {
      if (!id) throw new Error("Lead ID is required");

      const { data, error } = await supabase
        .from("contacts")
        .select("*")
        .eq("id", id)
        .single();

      if (error) {
        toast({
          title: "Error loading lead",
          description: error.message,
          variant: "destructive",
        });
        throw error;
      }

      return data as Contact;
    },
    enabled: !!user && !!id,
  });

  // Update field mutation
  const updateFieldMutation = useMutation({
    mutationFn: async ({
      field,
      value,
    }: {
      field: string;
      value: string | boolean | null;
    }) => {
      if (!id) throw new Error("Lead ID is required");

      const { error } = await supabase
        .from("contacts")
        .update({ [field]: value })
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["lead", id] });
      toast({
        title: "Lead updated",
        description: "Field has been updated successfully",
      });
      setEditingField(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error updating lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete lead mutation
  const deleteLeadMutation = useMutation({
    mutationFn: async () => {
      if (!id) throw new Error("Lead ID is required");

      const { error } = await supabase.from("contacts").delete().eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Lead deleted",
        description: "Lead has been deleted successfully",
      });
      navigate("/leads");
    },
    onError: (error: any) => {
      toast({
        title: "Error deleting lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Create deal mutation
  const createDealMutation = useMutation({
    mutationFn: async (dealData: DealFormValues) => {
      if (!lead) throw new Error("No lead selected");

      // First update the contact to mark as client
      await supabase
        .from("contacts")
        .update({ is_client: true })
        .eq("id", lead.id);

      // Generate deal name if not provided
      if (!dealData.name || dealData.name.trim() === "") {
        const currentDate = new Date();
        const month = format(currentDate, "MMMM");
        const year = format(currentDate, "yyyy");

        if (lead.business_name) {
          dealData.name = `${month} ${year} - ${lead.business_name}`;
        } else {
          const fullName = `${lead.first_name} ${lead.last_name || ""}`.trim();
          dealData.name = `${month} ${year} - ${fullName}`;
        }
      }

      // Create the deal - Parse amount to number or null if empty
      const dealToInsert = {
        contact_id: lead.id,
        name: dealData.name,
        amount: dealData.amount ? parseFloat(dealData.amount) : null,
        status: dealData.status || "new",
      };

      const { data, error } = await supabase
        .from("deals")
        .insert(dealToInsert)
        .select();

      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      toast({
        title: "Deal created",
        description: "New deal has been created successfully",
      });
      setIsDealDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["lead", id] });

      // Navigate to deal detail page if available
      if (data && data[0]) {
        navigate(`/deals/${data[0].id}`);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error creating deal",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function handleStartEdit(field: string, currentValue: any) {
    setEditingField(field);
    setEditValue(currentValue);
  }

  function handleCancelEdit() {
    setEditingField(null);
  }

  function handleSaveEdit(field: string) {
    updateFieldMutation.mutate({ field, value: editValue });
  }

  function handleDelete() {
    deleteLeadMutation.mutate();
  }

  function handleConvertToDeal() {
    setIsDealDialogOpen(true);
  }

  function onDealSubmit(data: DealFormValues) {
    createDealMutation.mutate(data);
  }

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "—";
    try {
      return format(new Date(dateString), "PPP");
    } catch (error) {
      return dateString;
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div>Loading lead details...</div>
      </div>
    );
  }

  if (error || !lead) {
    return (
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <Button variant="ghost" onClick={() => navigate("/leads")}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Leads
          </Button>
        </div>
        <div className="flex flex-col items-center justify-center min-h-[40vh]">
          <h2 className="text-xl font-semibold mb-2">Lead not found</h2>
          <p className="text-muted-foreground mb-4">
            The lead you're looking for doesn't exist or has been removed.
          </p>
          <Button onClick={() => navigate("/leads")}>Return to Lead List</Button>
        </div>
      </div>
    );
  }

  // Render field based on type and edit state
  const renderField = (
    label: string,
    field: keyof Contact,
    type: "text" | "textarea" | "date" | "boolean" = "text"
  ) => {
    const value = lead[field];
    const isEditing = editingField === field;

    // Format value based on type for display
    let displayValue: React.ReactNode;
    switch (type) {
      case "date":
        displayValue = formatDate(value as string);
        break;
      case "boolean":
        displayValue = value ? "Yes" : "No";
        break;
      default:
        displayValue = value || "—";
    }

    return (
      <div className="group relative">
        <p className="text-sm text-muted-foreground">{label}</p>
        {isEditing ? (
          <div className="flex items-center space-x-2">
            {type === "textarea" ? (
              <Textarea
                value={(editValue as string) || ""}
                onChange={(e) => setEditValue(e.target.value)}
                className="min-h-[100px]"
              />
            ) : type === "boolean" ? (
              <div className="flex items-center space-x-2">
                <Switch
                  checked={!!editValue}
                  onCheckedChange={setEditValue}
                />
                <Label>{editValue ? "Yes" : "No"}</Label>
              </div>
            ) : type === "date" ? (
              <Input
                type="date"
                value={editValue as string}
                onChange={(e) => setEditValue(e.target.value)}
              />
            ) : (
              <Input
                value={(editValue as string) || ""}
                onChange={(e) => setEditValue(e.target.value)}
              />
            )}
            <div className="flex space-x-1">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleSaveEdit(field)}
                className="h-8 w-8 p-0"
                disabled={updateFieldMutation.isPending}
              >
                <Check className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={handleCancelEdit}
                className="h-8 w-8 p-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex items-start">
            <div
              className={cn(
                "pr-8",
                type === "textarea" ? "whitespace-pre-wrap" : ""
              )}
            >
              {displayValue}
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="opacity-0 group-hover:opacity-100 h-6 w-6 p-0 absolute right-0 top-0"
              onClick={() => handleStartEdit(field, value)}
            >
              <Pencil className="h-3.5 w-3.5" />
            </Button>
          </div>
        )}
      </div>
    );
  };

  // Create mock timeline entries (this would be fetched from the database in a real app)
  const timelineEntries = [
    {
      id: 1,
      action: "Lead Created",
      description: "Lead was added to the system",
      timestamp: lead.created_at,
      icon: <FileText className="h-4 w-4" />
    },
    ...(lead.proposal_sent ? [{
      id: 2,
      action: "Proposal Sent",
      description: "Proposal was sent to the lead",
      timestamp: lead.updated_at,
      icon: <ExternalLink className="h-4 w-4" />
    }] : []),
    ...(lead.follow_up_date ? [{
      id: 3,
      action: "Follow-up Scheduled",
      description: `Follow-up scheduled for ${formatDate(lead.follow_up_date)}`,
      timestamp: lead.updated_at,
      icon: <Calendar className="h-4 w-4" />
    }] : [])
  ];

  return (
    <div className="space-y-6">
      {/* Back button and header */}
      <div className="flex items-center space-x-2">
        <Button variant="ghost" onClick={() => navigate("/leads")}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Leads
        </Button>
      </div>

      {/* Lead header */}
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-semibold">
              {lead.first_name} {lead.last_name}
            </h1>
            <Badge variant={lead.is_client ? "default" : "secondary"}>
              {lead.is_client ? "Client" : "Lead"}
            </Badge>
          </div>
          {lead.business_name && (
            <p className="text-gray-500 mt-1">{lead.business_name}</p>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex space-x-2">
          {lead.phone && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  window.open(
                    `https://wa.me/${lead.phone?.replace(/\D/g, "")}`,
                    "_blank"
                  )
                }
              >
                <MessageSquare className="mr-2 h-4 w-4 text-green-600" />
                WhatsApp
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open(`tel:${lead.phone}`, "_blank")}
              >
                <Phone className="mr-2 h-4 w-4 text-blue-600" />
                Call
              </Button>
            </>
          )}

          {lead.email && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open(`mailto:${lead.email}`, "_blank")}
            >
              <Mail className="mr-2 h-4 w-4" />
              Email
            </Button>
          )}

          <Button onClick={handleConvertToDeal} size="sm">
            <BadgeDollarSign className="mr-2 h-4 w-4" />
            Convert to Deal
          </Button>

          <Button
            variant="destructive"
            size="sm"
            onClick={() => setIsDeleteDialogOpen(true)}
          >
            <Trash2 className="mr-2 h-4 w-4" />
            Delete
          </Button>
        </div>
      </div>

      {/* Tabs for Overview and Timeline */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6 mt-6">
          {/* Basic Information Section */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Basic Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                {renderField("First Name", "first_name")}
                {renderField("Email", "email")}
                
                {/* Additional Phone Numbers */}
                {Array.isArray(lead.phone_numbers) && lead.phone_numbers.length > 0 && (
                  <div>
                    <p className="text-sm text-muted-foreground">Additional Phone Numbers</p>
                    <div className="space-y-2">
                      {lead.phone_numbers.map((phone, index) => (
                        <div key={index} className="flex items-center">
                          <span>{phone}</span>
                          <div className="flex ml-2 space-x-1">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8" 
                              onClick={() => window.open(`https://wa.me/${phone.replace(/\D/g, '')}`, '_blank')}
                            >
                              <MessageSquare className="h-4 w-4 text-green-600" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8" 
                              onClick={() => window.open(`tel:${phone}`, '_blank')}
                            >
                              <Phone className="h-4 w-4 text-blue-600" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              
              <div className="space-y-4">
                {renderField("Last Name", "last_name")}
                {renderField("Phone", "phone")}
              </div>
            </div>
          </div>

          {/* Business Details Section */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Business Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                {renderField("Business Name", "business_name")}
                {renderField("Business Type", "business_type")}
              </div>
              
              <div className="space-y-4">
                {renderField("Emirates", "emirates")}
                {renderField("Position", "position")}
              </div>
            </div>
          </div>

          {/* Lead Information Section */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Lead Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                {renderField("Lead Source", "lead_source")}
                {renderField("Inquiry Date", "inquiry_date", "date")}
              </div>
              
              <div className="space-y-4">
                {renderField("Campaign Name", "campaign_name")}
                {renderField("Preferred Contact Method", "preferred_contact_method")}
              </div>
            </div>
          </div>

          {/* Communication & Proposal Section */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Communication & Proposal</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                {renderField("Initial WhatsApp Message", "initial_whatsapp_message", "textarea")}
                {renderField("Proposal Sent", "proposal_sent", "boolean")}
                
                {/* Proposal Files */}
                <div>
                  <p className="text-sm text-muted-foreground">Proposal Files</p>
                  {Array.isArray(lead.proposal_files) && lead.proposal_files.length > 0 ? (
                    <div className="space-y-2 mt-1">
                      {lead.proposal_files.map((file, index) => (
                        <div key={index} className="flex items-center gap-2 group">
                          <ExternalLink className="h-4 w-4 text-blue-600" />
                          <span className="text-blue-600 hover:underline cursor-pointer">
                            {typeof file === "string" ? file.split("/").pop() : "File"}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p>No proposal files uploaded</p>
                  )}
                </div>
              </div>
              
              <div className="space-y-4">
                {renderField("Call Notes", "call_notes", "textarea")}
                {renderField("Follow-up Date", "follow_up_date", "date")}
                <div>
                  <p className="text-sm text-muted-foreground">Client Status</p>
                  <div className="mt-1">
                    <Badge variant={lead.is_client ? "default" : "secondary"}>
                      {lead.is_client ? "Client" : "Lead"}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Notes Section - Full Width */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Notes</h2>
            {renderField("General Notes", "notes", "textarea")}
          </div>
        </TabsContent>
        
        {/* Timeline Tab */}
        <TabsContent value="timeline" className="space-y-4 mt-6">
          <div className="space-y-4">
            {timelineEntries.map((entry) => (
              <Card key={entry.id} className="overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-start space-x-4">
                    <div className="mt-1 bg-muted rounded-full p-2">
                      {entry.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <h3 className="font-medium">{entry.action}</h3>
                        <p className="text-sm text-muted-foreground">
                          {entry.timestamp ? formatDate(entry.timestamp) : "—"}
                        </p>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        {entry.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {timelineEntries.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No activity recorded for this lead yet.
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Delete confirmation dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Lead</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {lead.first_name}{" "}
              {lead.last_name || ""}? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={deleteLeadMutation.isPending}
            >
              {deleteLeadMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Deal creation dialog */}
      <Dialog open={isDealDialogOpen} onOpenChange={setIsDealDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Convert to Deal</DialogTitle>
            <DialogDescription>
              Create a new deal for {lead.first_name} {lead.last_name || ""}
            </DialogDescription>
          </DialogHeader>
          <DealForm
            onSubmit={onDealSubmit}
            isSubmitting={createDealMutation.isPending}
            leadName={`${lead.first_name} ${lead.last_name || ""}`}
            defaultDealName={
              `${format(new Date(), "MMMM yyyy")} - ${
                lead.business_name || `${lead.first_name} ${lead.last_name || ""}`
              }`.trim()
            }
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
