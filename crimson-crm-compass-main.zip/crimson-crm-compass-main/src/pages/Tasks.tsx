
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Task } from "@/lib/types";
import { toast } from "@/hooks/use-toast";
import { Plus, ColumnsIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { TaskList } from "@/components/tasks/TaskList";

interface TaskWithDeal extends Task {
  deals?: {
    id: string;
    name: string;
    status: string;
    amount: number | null;
    contacts: {
      first_name: string;
      last_name: string;
      company: string | null;
    };
  } | null;
}

export default function Tasks() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isCompleteDialogOpen, setIsCompleteDialogOpen] = useState(false);
  const [currentTask, setCurrentTask] = useState<Task | null>(null);
  const [isColumnManagerOpen, setIsColumnManagerOpen] = useState(false);

  const { data: tasks = [], isLoading } = useQuery({
    queryKey: ["tasks"],
    queryFn: async () => {
      // Use type casting to handle the Supabase schema mismatch
      const { data, error } = await supabase
        .from("tasks" as any)
        .select(`
          *,
          deals:deal_id (
            id,
            name,
            status,
            amount,
            contacts!inner (
              first_name,
              last_name,
              company
            )
          )
        `)
        .order("created_at", { ascending: false });

      if (error) {
        toast({
          title: "Error loading tasks",
          description: error.message,
          variant: "destructive",
        });
        throw error;
      }

      return data as unknown as TaskWithDeal[];
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async () => {
      if (!currentTask) throw new Error("No task selected");

      // Use type casting to handle the Supabase schema mismatch
      const { error } = await supabase
        .from("tasks" as any)
        .delete()
        .eq("id", currentTask.id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Task deleted",
        description: "Task has been deleted successfully",
      });
      setIsDeleteDialogOpen(false);
      setCurrentTask(null);
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error deleting task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const completeTaskMutation = useMutation({
    mutationFn: async () => {
      if (!currentTask) throw new Error("No task selected");

      // Use type casting to handle the Supabase schema mismatch
      const { error } = await supabase
        .from("tasks" as any)
        .update({ status: "completed" })
        .eq("id", currentTask.id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Task completed",
        description: "Task has been marked as completed",
      });
      setIsCompleteDialogOpen(false);
      setCurrentTask(null);
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error completing task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function handleViewTask(task: Task) {
    navigate(`/tasks/${task.id}`);
  }

  function handleEditTask(task: Task) {
    navigate(`/tasks/edit/${task.id}`);
  }

  function handleAddTask() {
    navigate("/tasks/add");
  }

  function handleDeleteTask(task: Task) {
    setCurrentTask(task);
    setIsDeleteDialogOpen(true);
  }

  function handleCompleteTask(task: Task) {
    setCurrentTask(task);
    setIsCompleteDialogOpen(true);
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-semibold">Tasks</h1>
        <Button onClick={handleAddTask}>
          <Plus className="h-4 w-4 mr-2" /> Add Task
        </Button>
      </div>

      <div className="flex justify-end mb-2">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsColumnManagerOpen(true)}
              >
                <ColumnsIcon className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Manage Columns</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      <TaskList
        tasks={tasks}
        isLoading={isLoading}
        onView={handleViewTask}
        onEdit={handleEditTask}
        onDelete={handleDeleteTask}
        onComplete={handleCompleteTask}
        isColumnManagerOpen={isColumnManagerOpen}
        onColumnManagerOpenChange={setIsColumnManagerOpen}
      />

      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Task</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{currentTask?.title}"? This action
              cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => deleteTaskMutation.mutate()}
              disabled={deleteTaskMutation.isPending}
            >
              {deleteTaskMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isCompleteDialogOpen} onOpenChange={setIsCompleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Complete Task</DialogTitle>
            <DialogDescription>
              Mark "{currentTask?.title}" as completed?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsCompleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="default"
              onClick={() => completeTaskMutation.mutate()}
              disabled={completeTaskMutation.isPending}
            >
              {completeTaskMutation.isPending ? "Marking as completed..." : "Complete Task"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
