
import React, { useState } from "react";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ImportComponent } from "@/components/import-export/ImportComponent";
import { ExportComponent } from "@/components/import-export/ExportComponent";

export default function ImportExportPage() {
  const [tab, setTab] = useState<"import" | "export">("import");

  return (
    <div className="max-w-3xl mx-auto mt-8">
      <Card>
        <CardHeader>
          <div className="flex gap-3 mb-2">
            <Button 
              variant={tab === "import" ? "default" : "outline"} 
              onClick={() => setTab("import")}
            >Import Data</Button>
            <Button 
              variant={tab === "export" ? "default" : "outline"} 
              onClick={() => setTab("export")}
            >Export Data</Button>
          </div>
        </CardHeader>
        <CardContent>
          {tab === "import" ? <ImportComponent /> : <ExportComponent />}
        </CardContent>
      </Card>
    </div>
  );
}
