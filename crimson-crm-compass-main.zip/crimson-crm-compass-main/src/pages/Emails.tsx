
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, Send, FileText, BarChart3, History, Settings } from "lucide-react";
import { EmailComposer } from "@/components/emails/EmailComposer";
import { EmailTemplateManager } from "@/components/emails/EmailTemplateManager";
import { EmailCampaignManager } from "@/components/emails/EmailCampaignManager";
import { EmailAnalytics } from "@/components/emails/EmailAnalytics";
import { EmailHistory } from "@/components/emails/EmailHistory";
import { EmailSettings } from "@/components/emails/EmailSettings";

export default function Emails() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold">Email Management</h1>
        <p className="text-muted-foreground">
          Compose, manage campaigns, and track all email communications
        </p>
      </div>

      {/* Overview Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sent</CardTitle>
            <Send className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2,847</div>
            <p className="text-xs text-muted-foreground">
              +12% from last month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Open Rate</CardTitle>
            <Mail className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24.5%</div>
            <p className="text-xs text-muted-foreground">
              +2.1% from last month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Templates</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">18</div>
            <p className="text-xs text-muted-foreground">
              +3 new this month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Campaigns</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5</div>
            <p className="text-xs text-muted-foreground">
              2 scheduled
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="compose" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="compose">Compose</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="compose" className="space-y-4">
          <EmailComposer />
        </TabsContent>
        
        <TabsContent value="templates" className="space-y-4">
          <EmailTemplateManager />
        </TabsContent>
        
        <TabsContent value="campaigns" className="space-y-4">
          <EmailCampaignManager />
        </TabsContent>
        
        <TabsContent value="analytics" className="space-y-4">
          <EmailAnalytics />
        </TabsContent>
        
        <TabsContent value="history" className="space-y-4">
          <EmailHistory />
        </TabsContent>
        
        <TabsContent value="settings" className="space-y-4">
          <EmailSettings />
        </TabsContent>
      </Tabs>
    </div>
  );
}
