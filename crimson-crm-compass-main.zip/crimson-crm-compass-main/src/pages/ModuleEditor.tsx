
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Contact2, 
  BadgeDollarSign, 
  User, 
  CheckSquare, 
  Settings,
  Grid2X2,
  ArrowRight
} from "lucide-react";
import { Link } from "react-router-dom";
import { useModuleFieldCounts } from "@/hooks/useModuleFieldCounts";

interface ModuleInfo {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
}

const modules: ModuleInfo[] = [
  {
    id: "lead",
    name: "Leads",
    description: "Simplified lead management with custom fields",
    icon: Contact2,
    color: "blue",
  },
  {
    id: "deal",
    name: "Deals",
    description: "Track sales opportunities and revenue",
    icon: BadgeDollarSign,
    color: "green",
  },
  {
    id: "contact",
    name: "Contacts",
    description: "Manage customer and business contacts",
    icon: User,
    color: "purple",
  },
  {
    id: "task",
    name: "Tasks",
    description: "Organize and track team activities",
    icon: CheckSquare,
    color: "orange",
  },
];

function ModuleCard({ module }: { module: ModuleInfo }) {
  const { data: fieldCounts, isLoading } = useModuleFieldCounts(module.id);
  const IconComponent = module.icon;
  
  return (
    <Card className="hover:shadow-lg transition-all duration-200 group h-full flex flex-col">
      <CardHeader className="pb-3 flex-1">
        <div className="flex items-center justify-between mb-3">
          <div className={`p-3 rounded-lg bg-${module.color}-100`}>
            <IconComponent className={`h-6 w-6 text-${module.color}-600`} />
          </div>
          <Badge variant="outline" className="text-xs">
            {isLoading ? "..." : fieldCounts ? `${fieldCounts.totalFields} field${fieldCounts.totalFields !== 1 ? 's' : ''}` : "0 fields"}
          </Badge>
        </div>
        
        <CardTitle className="text-lg">{module.name}</CardTitle>
        <p className="text-sm text-muted-foreground">
          {module.description}
        </p>
      </CardHeader>
      
      <CardContent className="pt-0 mt-auto">
        <div className="space-y-3">
          {/* Field Statistics */}
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">System Fields:</span>
            <span className="font-medium">
              {isLoading ? "..." : fieldCounts?.systemFields || 0}
            </span>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Custom Fields:</span>
            <span className="font-medium">
              {isLoading ? "..." : fieldCounts?.customFields || 0}
            </span>
          </div>
          
          {/* Edit Button */}
          <Button 
            asChild 
            className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
            variant="outline"
          >
            <Link to={`/fields-editor/advanced/${module.id}`}>
              <Settings className="h-4 w-4 mr-2" />
              Edit Fields
              <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ModuleEditor() {
  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <Grid2X2 className="h-8 w-8 text-blue-600" />
          <div>
            <h1 className="text-3xl font-bold">Module Editor</h1>
            <p className="text-muted-foreground">
              Customize fields and layouts for all CRM modules
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <Settings className="h-5 w-5 text-blue-600" />
          <div className="flex-1">
            <p className="text-sm font-medium text-blue-900">
              Enhanced Field Management
            </p>
            <p className="text-xs text-blue-700">
              Configure system fields, create custom fields, and organize field groups for each module
            </p>
          </div>
        </div>
      </div>

      {/* Modules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {modules.map((module) => (
          <ModuleCard key={module.id} module={module} />
        ))}
      </div>

      {/* Quick Actions */}
      <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Global Settings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Configure global field settings and templates that apply across all modules.
            </p>
            <Button variant="outline" className="w-full" asChild>
              <Link to="/fields-editor">
                <Settings className="h-4 w-4 mr-2" />
                Open Legacy Editor
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Grid2X2 className="h-5 w-5" />
              Field Templates
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Create reusable field templates that can be applied across different modules.
            </p>
            <Button variant="outline" className="w-full" disabled>
              <Grid2X2 className="h-4 w-4 mr-2" />
              Coming Soon
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
