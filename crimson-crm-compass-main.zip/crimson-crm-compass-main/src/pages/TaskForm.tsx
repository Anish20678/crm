
import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useQueryClient, useMutation, useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Task } from "@/lib/types";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { TaskForm, TaskFormValues } from "@/components/tasks/TaskForm";

export default function TaskFormPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const queryClient = useQueryClient();
  const isEditMode = !!id;

  const { data: task, isLoading: isTaskLoading } = useQuery({
    queryKey: ["task", id],
    queryFn: async () => {
      if (!id) return null;

      console.log("Loading task with ID:", id);

      // Use type casting to handle the Supabase schema mismatch
      const { data, error } = await supabase
        .from("tasks" as any)
        .select("*")
        .eq("id", id)
        .single();

      if (error) {
        console.error("Error loading task:", error);
        toast({
          title: "Error loading task",
          description: error.message,
          variant: "destructive",
        });
        throw error;
      }

      console.log("Loaded task data:", data);
      return data as unknown as Task;
    },
    enabled: isEditMode,
  });

  const createTaskMutation = useMutation({
    mutationFn: async (values: TaskFormValues) => {
      console.log("Creating task with values:", values);

      // Get current user ID
      const currentUser = await supabase.auth.getUser();
      const userId = currentUser.data?.user?.id;
      
      if (!userId) {
        throw new Error("User not authenticated");
      }

      // Prepare task data - properly handle UUID fields
      const taskData = {
        title: values.title,
        description: values.description || null,
        status: values.status,
        priority: values.priority,
        due_date: values.due_date || null,
        assigned_to: values.assigned_to || null,
        related_to_type: values.related_to_type || null,
        related_to_id: values.related_to_id || null,
        deal_id: values.deal_id || null,
        user_id: userId,
      };

      console.log("Prepared task data for insert:", taskData);

      // Use type casting to handle the Supabase schema mismatch
      const { data, error } = await supabase
        .from("tasks" as any)
        .insert([taskData])
        .select();

      if (error) {
        console.error("Error creating task:", error);
        throw error;
      }

      console.log("Task created successfully:", data);
      return data;
    },
    onSuccess: () => {
      toast({
        title: "Task created",
        description: "New task has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      navigate("/tasks");
    },
    onError: (error: any) => {
      console.error("Task creation failed:", error);
      toast({
        title: "Error creating task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async (values: TaskFormValues) => {
      if (!id) throw new Error("Task ID is required for updates");

      console.log("Updating task with values:", values);

      // Prepare task data - properly handle UUID fields
      const taskData = {
        title: values.title,
        description: values.description || null,
        status: values.status,
        priority: values.priority,
        due_date: values.due_date || null,
        assigned_to: values.assigned_to || null,
        related_to_type: values.related_to_type || null,
        related_to_id: values.related_to_id || null,
        deal_id: values.deal_id || null,
      };

      console.log("Prepared task data for update:", taskData);

      // Use type casting to handle the Supabase schema mismatch
      const { data, error } = await supabase
        .from("tasks" as any)
        .update(taskData)
        .eq("id", id)
        .select();

      if (error) {
        console.error("Error updating task:", error);
        throw error;
      }

      console.log("Task updated successfully:", data);
      return data;
    },
    onSuccess: () => {
      toast({
        title: "Task updated",
        description: "Task has been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      queryClient.invalidateQueries({ queryKey: ["task", id] });
      navigate("/tasks");
    },
    onError: (error: any) => {
      console.error("Task update failed:", error);
      toast({
        title: "Error updating task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: TaskFormValues) => {
    console.log("Form submitted with data:", data);
    
    if (isEditMode) {
      updateTaskMutation.mutate(data);
    } else {
      createTaskMutation.mutate(data);
    }
  };

  if (isEditMode && isTaskLoading) {
    return <div className="text-center py-8">Loading task data...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <Button variant="ghost" onClick={() => navigate("/tasks")}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Tasks
        </Button>
      </div>

      <h1 className="text-3xl font-semibold">
        {isEditMode ? "Edit Task" : "Add New Task"}
      </h1>

      <div className="max-w-3xl">
        <TaskForm
          onSubmit={handleSubmit}
          defaultValues={task ? {
            ...task,
            deal_id: task.deal_id || "",
            due_date: task.due_date ? new Date(task.due_date).toISOString().split('T')[0] : "",
            assigned_to: task.assigned_to || "",
            related_to_type: task.related_to_type || "",
            related_to_id: task.related_to_id || "",
            description: task.description || "",
          } : {}}
          isSubmitting={createTaskMutation.isPending || updateTaskMutation.isPending}
          taskId={id}
        />
      </div>
    </div>
  );
}
