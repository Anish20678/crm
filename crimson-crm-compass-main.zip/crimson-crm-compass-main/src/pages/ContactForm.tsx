
import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft, Loader2 } from "lucide-react";
import { Contact } from "@/lib/types";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";

type FormValues = {
  first_name: string;
  last_name?: string;
  email?: string;
  phone?: string;
  business_name?: string;
  business_type?: string;
  position?: string;
  emirates?: string;
  lead_source?: string;
  preferred_contact_method?: string;
  notes?: string;
  is_client: boolean;
};

export default function ContactForm() {
  const { id } = useParams<{ id: string }>();
  const isEditMode = !!id;
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [phoneNumbers, setPhoneNumbers] = useState<string[]>([]);
  const [newPhoneNumber, setNewPhoneNumber] = useState("");

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors, isSubmitting },
    reset,
  } = useForm<FormValues>({
    defaultValues: {
      is_client: true, // Since this is a contact form, default to client
    },
  });

  // Fetch contact data when in edit mode
  const { data: contactData, isLoading } = useQuery({
    queryKey: ["contact", id],
    queryFn: async () => {
      if (!id) return null;

      const { data, error } = await supabase
        .from("contacts")
        .select("*")
        .eq("id", id)
        .single();

      if (error) throw error;
      return data as Contact;
    },
    enabled: isEditMode,
  });

  // Set form values when contact data is loaded
  useEffect(() => {
    if (contactData) {
      reset({
        first_name: contactData.first_name,
        last_name: contactData.last_name || "",
        email: contactData.email || "",
        phone: contactData.phone || "",
        business_name: contactData.business_name || "",
        business_type: contactData.business_type || "",
        position: contactData.position || "",
        emirates: contactData.emirates || "",
        lead_source: contactData.lead_source || "",
        preferred_contact_method: contactData.preferred_contact_method || "",
        notes: contactData.notes || "",
        is_client: contactData.is_client || true,
      });

      // Set phone numbers
      if (contactData.phone_numbers && Array.isArray(contactData.phone_numbers)) {
        setPhoneNumbers(contactData.phone_numbers as string[]);
      }
    }
  }, [contactData, reset]);

  // Create or update contact
  const mutation = useMutation({
    mutationFn: async (data: FormValues) => {
      if (!user) throw new Error("No user logged in");

      const contactData = {
        ...data,
        phone_numbers: phoneNumbers,
        user_id: user.id,
      };

      if (isEditMode && id) {
        // Update existing contact
        const { error } = await supabase
          .from("contacts")
          .update(contactData)
          .eq("id", id);

        if (error) throw error;
        return { id };
      } else {
        // Create new contact
        const { data: newContact, error } = await supabase
          .from("contacts")
          .insert([contactData])
          .select();

        if (error) throw error;
        return newContact[0];
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
      if (isEditMode && id) {
        queryClient.invalidateQueries({ queryKey: ["contact", id] });
      }

      toast({
        title: isEditMode ? "Contact updated" : "Contact created",
        description: isEditMode
          ? "Contact details have been updated successfully"
          : "New contact has been created successfully",
      });

      navigate("/contacts");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormValues) => {
    mutation.mutate(data);
  };

  const addPhoneNumber = () => {
    if (newPhoneNumber.trim() && !phoneNumbers.includes(newPhoneNumber.trim())) {
      setPhoneNumbers([...phoneNumbers, newPhoneNumber.trim()]);
      setNewPhoneNumber("");
    }
  };

  const removePhoneNumber = (index: number) => {
    setPhoneNumbers(phoneNumbers.filter((_, i) => i !== index));
  };

  if (isLoading && isEditMode) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <div className="mb-6">
        <Button
          variant="ghost"
          onClick={() => navigate("/contacts")}
          className="mb-2"
        >
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Contacts
        </Button>
        <h1 className="text-3xl font-bold">
          {isEditMode ? "Edit Contact" : "Add New Contact"}
        </h1>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
        {/* Basic Information */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-2">Basic Information</h2>
          <Separator className="mb-6" />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="first_name">
                First Name <span className="text-red-500">*</span>
              </Label>
              <Input
                id="first_name"
                {...register("first_name", { required: "First name is required" })}
                placeholder="First name"
                className={errors.first_name ? "border-red-500" : ""}
              />
              {errors.first_name && (
                <p className="text-red-500 text-sm">{errors.first_name.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="last_name">Last Name</Label>
              <Input
                id="last_name"
                {...register("last_name")}
                placeholder="Last name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                {...register("email")}
                type="email"
                placeholder="Email address"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Primary Phone</Label>
              <Input
                id="phone"
                {...register("phone")}
                placeholder="Phone number"
              />
            </div>
            
            <div className="space-y-2 col-span-2">
              <Label>Additional Phone Numbers</Label>
              <div className="space-y-2">
                {phoneNumbers.map((phone, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input value={phone} disabled />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removePhoneNumber(index)}
                    >
                      Remove
                    </Button>
                  </div>
                ))}
                <div className="flex gap-2">
                  <Input
                    value={newPhoneNumber}
                    onChange={(e) => setNewPhoneNumber(e.target.value)}
                    placeholder="Add another phone number"
                  />
                  <Button type="button" onClick={addPhoneNumber}>
                    Add
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Business Details */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-2">Business Details</h2>
          <Separator className="mb-6" />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="business_name">Business Name</Label>
              <Input
                id="business_name"
                {...register("business_name")}
                placeholder="Business name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="business_type">Business Type</Label>
              <Input
                id="business_type"
                {...register("business_type")}
                placeholder="Business type"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="position">Position</Label>
              <Input
                id="position"
                {...register("position")}
                placeholder="Position in company"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="emirates">Emirates</Label>
              <Input
                id="emirates"
                {...register("emirates")}
                placeholder="Emirates"
              />
            </div>
          </div>
        </div>

        {/* Additional Information */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-2">Additional Information</h2>
          <Separator className="mb-6" />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="lead_source">Lead Source</Label>
              <Input
                id="lead_source"
                {...register("lead_source")}
                placeholder="How did you find this contact?"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="preferred_contact_method">Preferred Contact Method</Label>
              <Input
                id="preferred_contact_method"
                {...register("preferred_contact_method")}
                placeholder="Email, Phone, WhatsApp, etc."
              />
            </div>
          </div>
          
          <div className="mt-4 flex items-center space-x-2">
            <Switch
              id="is_client"
              checked={Boolean(null)}
              onCheckedChange={(checked) => setValue("is_client", checked)}
            />
            <Label htmlFor="is_client">Is a Client</Label>
          </div>
        </div>

        {/* Notes */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-2">Notes</h2>
          <Separator className="mb-6" />

          <div className="space-y-2">
            <Label htmlFor="notes">General Notes</Label>
            <Textarea
              id="notes"
              {...register("notes")}
              placeholder="Add any additional notes about this contact"
              className="min-h-[100px]"
            />
          </div>
        </div>

        {/* Form Actions */}
        <div className="flex justify-end gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate("/contacts")}
          >
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting || mutation.isPending}>
            {isSubmitting || mutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                {isEditMode ? "Updating..." : "Creating..."}
              </>
            ) : (
              <>{isEditMode ? "Update Contact" : "Create Contact"}</>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}
