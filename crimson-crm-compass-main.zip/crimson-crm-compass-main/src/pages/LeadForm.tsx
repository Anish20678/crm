import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import { Contact } from "@/lib/types";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Separator } from "@/components/ui/separator";
import { ChevronLeft, Calendar as CalendarIcon, MessageSquare, Phone, X, FileText, Upload, Plus } from "lucide-react";

// Define the form schema
const leadFormSchema = z.object({
  first_name: z.string().min(1, "First name is required"),
  last_name: z.string().optional().nullable(),
  email: z.string().email("Invalid email").optional().nullable().or(z.literal("")),
  phone: z.string().optional().nullable(),
  company: z.string().optional().nullable(),
  position: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
  business_name: z.string().optional().nullable(),
  business_type: z.string().optional().nullable(),
  emirates: z.string().optional().nullable(),
  lead_source: z.string().optional().nullable(),
  campaign_name: z.string().optional().nullable(),
  inquiry_date: z.date().optional().nullable(),
  initial_whatsapp_message: z.string().optional().nullable(),
  call_notes: z.string().optional().nullable(),
  proposal_sent: z.boolean().optional().nullable(),
  follow_up_date: z.date().optional().nullable(),
  preferred_contact_method: z.string().optional().nullable(),
  is_client: z.boolean().optional().nullable(),
});

export type LeadFormValues = z.infer<typeof leadFormSchema>;

import { useCustomFieldValues } from "@/hooks/useCustomFieldValues";
import { CustomFieldsFormSection } from "@/components/fields/CustomFieldsFormSection";

export default function LeadFormPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { id } = useParams();
  const queryClient = useQueryClient();
  const [phoneNumbers, setPhoneNumbers] = useState<string[]>([]);
  const [newPhone, setNewPhone] = useState("");
  const [proposalFiles, setProposalFiles] = useState<File[]>([]);
  const isEditMode = !!id;
  
  const { data: lead, isLoading } = useQuery({
    queryKey: ["contacts", id],
    queryFn: async () => {
      if (!id) return null;
      
      const { data, error } = await supabase
        .from("contacts")
        .select("*")
        .eq("id", id)
        .single();
      
      if (error) throw error;
      return data as Contact;
    },
    enabled: !!id && !!user,
  });

  const form = useForm<LeadFormValues>({
    resolver: zodResolver(leadFormSchema),
    defaultValues: {
      first_name: "",
      last_name: "",
      email: "",
      phone: "",
      company: "",
      position: "",
      notes: "",
      business_name: "",
      business_type: "",
      emirates: "",
      lead_source: "",
      campaign_name: "",
      inquiry_date: null,
      initial_whatsapp_message: "",
      call_notes: "",
      proposal_sent: false,
      follow_up_date: null,
      preferred_contact_method: "",
      is_client: false,
    },
  });

  useEffect(() => {
    if (lead) {
      setPhoneNumbers(lead.phone_numbers as string[] || []);
      
      form.reset({
        first_name: lead.first_name,
        last_name: lead.last_name || "",
        email: lead.email || "",
        phone: lead.phone || "",
        company: lead.company || "",
        position: lead.position || "",
        notes: lead.notes || "",
        business_name: lead.business_name || "",
        business_type: lead.business_type || "",
        emirates: lead.emirates || "",
        lead_source: lead.lead_source || "",
        campaign_name: lead.campaign_name || "",
        inquiry_date: lead.inquiry_date ? new Date(lead.inquiry_date) : null,
        initial_whatsapp_message: lead.initial_whatsapp_message || "",
        call_notes: lead.call_notes || "",
        proposal_sent: lead.proposal_sent || false,
        follow_up_date: lead.follow_up_date ? new Date(lead.follow_up_date) : null,
        preferred_contact_method: lead.preferred_contact_method || "",
        is_client: lead.is_client || false,
      });
    }
  }, [lead, form]);

  const addLeadMutation = useMutation({
    mutationFn: async (data: LeadFormValues) => {
      if (!user) throw new Error("User not authenticated");
      
      const leadToInsert = {
        user_id: user.id,
        status: 'active',
        first_name: data.first_name,
        last_name: data.last_name,
        email: data.email,
        phone: data.phone,
        company: data.company,
        position: data.position,
        notes: data.notes,
        business_name: data.business_name,
        business_type: data.business_type,
        emirates: data.emirates,
        phone_numbers: phoneNumbers,
        lead_source: data.lead_source,
        campaign_name: data.campaign_name,
        inquiry_date: data.inquiry_date ? data.inquiry_date.toISOString() : null,
        initial_whatsapp_message: data.initial_whatsapp_message,
        call_notes: data.call_notes,
        proposal_sent: data.proposal_sent,
        proposal_files: [], // Will be updated with uploaded files
        follow_up_date: data.follow_up_date ? data.follow_up_date.toISOString() : null,
        preferred_contact_method: data.preferred_contact_method,
        is_client: data.is_client,
      };
      
      const { data: insertedLead, error } = await supabase
        .from("contacts")
        .insert(leadToInsert)
        .select();
      
      if (error) throw error;
      
      // Upload proposal files if any
      if (proposalFiles.length > 0 && insertedLead && insertedLead[0]) {
        const leadId = insertedLead[0].id;
        const uploadedFiles = [];
        
        for (const file of proposalFiles) {
          const filePath = `proposals/${leadId}/${file.name}`;
          const { error: uploadError } = await supabase.storage
            .from('proposals')
            .upload(filePath, file);
            
          if (!uploadError) {
            uploadedFiles.push(filePath);
          }
        }
        
        if (uploadedFiles.length > 0) {
          await supabase
            .from("contacts")
            .update({ proposal_files: uploadedFiles })
            .eq("id", leadId);
        }
      }
      
      return insertedLead;
    },
    onSuccess: () => {
      toast({
        title: "Lead added",
        description: "Your lead has been added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
      navigate("/leads");
    },
    onError: (error: any) => {
      toast({
        title: "Error adding lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateLeadMutation = useMutation({
    mutationFn: async (data: LeadFormValues) => {
      if (!id || !lead) throw new Error("No lead selected");
      
      const leadToUpdate = {
        first_name: data.first_name,
        last_name: data.last_name,
        email: data.email,
        phone: data.phone,
        company: data.company,
        position: data.position,
        notes: data.notes,
        business_name: data.business_name,
        business_type: data.business_type,
        emirates: data.emirates,
        phone_numbers: phoneNumbers,
        lead_source: data.lead_source,
        campaign_name: data.campaign_name,
        inquiry_date: data.inquiry_date ? data.inquiry_date.toISOString() : null,
        initial_whatsapp_message: data.initial_whatsapp_message,
        call_notes: data.call_notes,
        proposal_sent: data.proposal_sent,
        follow_up_date: data.follow_up_date ? data.follow_up_date.toISOString() : null,
        preferred_contact_method: data.preferred_contact_method,
        is_client: data.is_client,
      };
      
      const { data: updatedLead, error } = await supabase
        .from("contacts")
        .update(leadToUpdate)
        .eq("id", id)
        .select();
      
      if (error) throw error;
      
      // Upload and update proposal files if any
      if (proposalFiles.length > 0 && updatedLead && updatedLead[0]) {
        const leadId = updatedLead[0].id;
        const existingFiles = Array.isArray(updatedLead[0].proposal_files) ? updatedLead[0].proposal_files : [];
        const uploadedFiles = [...existingFiles];
        
        for (const file of proposalFiles) {
          const filePath = `proposals/${leadId}/${file.name}`;
          const { error: uploadError } = await supabase.storage
            .from('proposals')
            .upload(filePath, file);
            
          if (!uploadError) {
            uploadedFiles.push(filePath);
          }
        }
        
        await supabase
          .from("contacts")
          .update({ proposal_files: uploadedFiles })
          .eq("id", leadId);
      }
      
      return updatedLead;
    },
    onSuccess: () => {
      toast({
        title: "Lead updated",
        description: "Your lead has been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
      navigate("/leads");
    },
    onError: (error: any) => {
      toast({
        title: "Error updating lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // ---- Custom Fields State ----
  // For existing record (edit), use id; for create, manage state until record is created
  const [customFieldValuesState, setCustomFieldValuesState] = useState<Record<string, string>>({});
  const [customFieldErrors, setCustomFieldErrors] = useState<Record<string, string>>({});

  // Only load custom field values if editing or once lead is created
  const {
    customFields,
    customFieldValues,
    fieldsLoading: customFieldsLoading,
    valuesLoading: customValuesLoading,
    upsertValues: upsertCustomFieldValues,
    error: customFieldsError,
  } = useCustomFieldValues("lead", id);

  // Load values into local state upon load (editing mode)
  useEffect(() => {
    if (customFieldValues && customFieldValues.length) {
      const fieldMap: Record<string, string> = {};
      customFieldValues.forEach(val => { fieldMap[val.field_id] = val.value ?? ""; });
      setCustomFieldValuesState(fieldMap);
    } else if (customFields && customFields.length && !id) {
      // Initialize empty for create
      const fieldMap: Record<string, string> = {};
      customFields.forEach(f => fieldMap[f.id] = "");
      setCustomFieldValuesState(fieldMap);
    }
  }, [customFieldValues, customFields, id]);

  // Validate required custom fields
  function validateCustomFields(): boolean {
    const errors: Record<string, string> = {};
    customFields
      .filter(f => f.required)
      .forEach(f => {
        if (
          customFieldValuesState[f.id] == null ||
          customFieldValuesState[f.id] === "" ||
          (f.field_type === "boolean" && (customFieldValuesState[f.id] !== "true"))
        ) {
          errors[f.id] = "This field is required";
        }
      });
    setCustomFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }

  function onSubmit(data: LeadFormValues) {
    // Validate custom fields
    if (!validateCustomFields()) {
      // Scroll to bottom where the errors are
      window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
      return;
    }

    if (isEditMode) {
      updateLeadMutation.mutate(data, {
        onSuccess: async (updatedLead: any) => {
          // Save custom fields
          if (customFields && customFields.length) {
            const valuesToSave = customFields.map(f => ({
              field_id: f.id,
              value: customFieldValuesState[f.id] ?? "",
            }));
            await upsertCustomFieldValues(valuesToSave);
          }
        }
      });
    } else {
      addLeadMutation.mutate(data, {
        onSuccess: async (inserted: any) => {
          // After lead is created, save custom field values
          const leadId = inserted?.[0]?.id;
          if (leadId && customFields && customFields.length) {
            const valuesToSave = customFields.map(f => ({
              field_id: f.id,
              value: customFieldValuesState[f.id] ?? "",
            }));
            // Use the hook with that record id just to run upsert
            await upsertCustomFieldValues(valuesToSave);
          }
        }
      });
    }
  }

  function addPhoneNumber() {
    if (newPhone && !phoneNumbers.includes(newPhone)) {
      setPhoneNumbers([...phoneNumbers, newPhone]);
      setNewPhone("");
    }
  }

  function removePhoneNumber(phone: string) {
    setPhoneNumbers(phoneNumbers.filter(p => p !== phone));
  }

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.files && e.target.files.length > 0) {
      const filesArray = Array.from(e.target.files);
      setProposalFiles([...proposalFiles, ...filesArray]);
    }
  }

  function removeFile(index: number) {
    setProposalFiles(proposalFiles.filter((_, i) => i !== index));
  }

  if (isEditMode && isLoading) {
    return <div className="flex justify-center items-center h-64">Loading lead details...</div>;
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center mb-6">
        <Button 
          variant="ghost" 
          onClick={() => navigate("/leads")} 
          className="mr-2"
        >
          <ChevronLeft className="w-4 h-4 mr-1" />
          Back
        </Button>
        <h1 className="text-2xl font-semibold">
          {isEditMode ? `Edit Lead: ${lead?.first_name} ${lead?.last_name}` : "Add New Lead"}
        </h1>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Left Column */}
            <div className="space-y-8">
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-medium mb-4">Basic Information</h2>
                <Separator className="mb-6" />
                
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="first_name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>First Name *</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="last_name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Last Name</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone</FormLabel>
                        <FormControl>
                          <Input type="tel" {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div>
                    <FormLabel>Additional Phone Numbers</FormLabel>
                    <div className="flex space-x-2 mb-2">
                      <Input 
                        type="tel" 
                        value={newPhone} 
                        onChange={(e) => setNewPhone(e.target.value)} 
                        placeholder="Add phone number" 
                      />
                      <Button type="button" onClick={addPhoneNumber}>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    {phoneNumbers.length > 0 && (
                      <div className="grid gap-2 mt-2">
                        {phoneNumbers.map((phone, index) => (
                          <div key={index} className="flex items-center justify-between px-3 py-2 bg-muted rounded-md">
                            <span>{phone}</span>
                            <div className="flex space-x-2">
                              <Button type="button" size="icon" variant="ghost" onClick={() => window.open(`https://wa.me/${phone.replace(/\D/g, '')}`)}>
                                <MessageSquare className="h-4 w-4" />
                              </Button>
                              <Button type="button" size="icon" variant="ghost" onClick={() => window.open(`tel:${phone}`)}>
                                <Phone className="h-4 w-4" />
                              </Button>
                              <Button type="button" size="icon" variant="ghost" onClick={() => removePhoneNumber(phone)}>
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-medium mb-4">Business Details</h2>
                <Separator className="mb-6" />
                
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="business_name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Business Name</FormLabel>
                        <FormControl>
                          <Input {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="business_type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Business Type</FormLabel>
                        <FormControl>
                          <Input {...field} value={field.value || ""} placeholder="e.g., Salon, Real Estate, Coaching" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="emirates"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Emirates</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value || ""}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select Emirates" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Abu Dhabi">Abu Dhabi</SelectItem>
                            <SelectItem value="Dubai">Dubai</SelectItem>
                            <SelectItem value="Sharjah">Sharjah</SelectItem>
                            <SelectItem value="Ajman">Ajman</SelectItem>
                            <SelectItem value="Umm Al Quwain">Umm Al Quwain</SelectItem>
                            <SelectItem value="Ras Al Khaimah">Ras Al Khaimah</SelectItem>
                            <SelectItem value="Fujairah">Fujairah</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="company"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Company</FormLabel>
                        <FormControl>
                          <Input {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="position"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Position</FormLabel>
                        <FormControl>
                          <Input {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-medium mb-4">Notes</h2>
                <Separator className="mb-6" />
                
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Textarea {...field} value={field.value || ""} rows={5} placeholder="Enter general notes about this lead" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            {/* Right Column */}
            <div className="space-y-8">
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-medium mb-4">Lead Information</h2>
                <Separator className="mb-6" />
                
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="lead_source"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Lead Source</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value || ""}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select Lead Source" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Meta Ads">Meta Ads</SelectItem>
                            <SelectItem value="Google Ads">Google Ads</SelectItem>
                            <SelectItem value="Referral">Referral</SelectItem>
                            <SelectItem value="Direct">Direct</SelectItem>
                            <SelectItem value="Other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="campaign_name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Campaign Name</FormLabel>
                        <FormControl>
                          <Input {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="inquiry_date"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Inquiry Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={`w-full text-left font-normal ${!field.value ? "text-muted-foreground" : ""}`}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value || undefined}
                              onSelect={field.onChange}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="preferred_contact_method"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Preferred Contact Method</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value || ""}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select Preferred Method" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="WhatsApp">WhatsApp</SelectItem>
                            <SelectItem value="Call">Call</SelectItem>
                            <SelectItem value="Email">Email</SelectItem>
                            <SelectItem value="SMS">SMS</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="initial_whatsapp_message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Initial WhatsApp Message</FormLabel>
                        <FormControl>
                          <Textarea {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-medium mb-4">Communication & Proposal</h2>
                <Separator className="mb-6" />
                
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="call_notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Call Notes</FormLabel>
                        <FormControl>
                          <Textarea {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="follow_up_date"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Follow-up Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={`w-full text-left font-normal ${!field.value ? "text-muted-foreground" : ""}`}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value || undefined}
                              onSelect={field.onChange}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="proposal_sent"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Proposal Sent</FormLabel>
                          <FormDescription>
                            Has a proposal been sent to the lead?
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value || false}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <div className="space-y-2">
                    <FormLabel>Proposal Files</FormLabel>
                    <div className="border rounded-md p-4">
                      <label className="flex flex-col items-center gap-2 cursor-pointer">
                        <Upload className="h-8 w-8 text-muted-foreground" />
                        <span className="text-sm font-medium">
                          Click to upload proposal files
                        </span>
                        <span className="text-xs text-muted-foreground">
                          PDF, DOCX, files up to 10MB
                        </span>
                        <Input 
                          type="file" 
                          className="hidden" 
                          onChange={handleFileChange} 
                          accept=".pdf,.docx,.doc"
                          multiple
                        />
                      </label>
                      
                      {proposalFiles.length > 0 && (
                        <div className="mt-4 space-y-2">
                          {proposalFiles.map((file, index) => (
                            <div key={index} className="flex items-center justify-between px-3 py-2 bg-muted rounded-md">
                              <div className="flex items-center">
                                <FileText className="h-4 w-4 mr-2" />
                                <span className="text-sm">{file.name}</span>
                              </div>
                              <Button type="button" size="icon" variant="ghost" onClick={() => removeFile(index)}>
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="is_client"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Client Status</FormLabel>
                          <FormDescription>
                            Mark this lead as a client
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value || false}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            </div>
          </div>
          
          {/* Custom Field Section - always at bottom */}
          <CustomFieldsFormSection
            fields={customFields}
            values={customFieldValuesState}
            onChange={(fieldId, value) => setCustomFieldValuesState(prev => ({ ...prev, [fieldId]: value }))}
            errors={customFieldErrors}
          />

          <div className="flex justify-end gap-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => navigate("/leads")}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isEditMode ? updateLeadMutation.isPending : addLeadMutation.isPending}
            >
              {isEditMode ? 
                (updateLeadMutation.isPending ? "Saving..." : "Update Lead") : 
                (addLeadMutation.isPending ? "Adding..." : "Add Lead")
              }
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
