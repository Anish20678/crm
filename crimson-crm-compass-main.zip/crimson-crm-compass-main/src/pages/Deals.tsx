
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Eye, Edit, Trash2, Plus, ColumnsIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Deal } from "@/lib/types";
import { format } from "date-fns";
import { Column, ColumnManager } from "@/components/contacts/ColumnManager";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useBulkSelection } from "@/hooks/useBulkSelection";
import { BulkActionHeader } from "@/components/bulk-actions/BulkActionHeader";
import { BulkActionBar } from "@/components/bulk-actions/BulkActionBar";
import { ConfirmationDialog } from "@/components/bulk-actions/ConfirmationDialog";
import { Checkbox } from "@/components/ui/checkbox";

export default function Deals() {
  const [isColumnManagerOpen, setIsColumnManagerOpen] = useState(false);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [columns, setColumns] = useState<Column[]>([
    { id: "select", label: "Select", visible: true },
    { id: "title", label: "Deal Title", visible: true },
    { id: "client", label: "Client", visible: true },
    { id: "projectType", label: "Project Type", visible: true },
    { id: "status", label: "Status", visible: true },
    { id: "price", label: "Quoted Price", visible: true },
    { id: "delivery", label: "Expected Delivery", visible: true },
    { id: "actions", label: "Actions", visible: true },
  ]);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: deals, isLoading, error, refetch } = useQuery({
    queryKey: ["deals"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("deals")
        .select(`
          *,
          contacts(first_name, last_name, business_name)
        `);

      if (error) throw error;
      return data || [];
    },
  });

  const {
    selectedIds,
    selectedItems,
    selectedCount,
    isSelected,
    toggleSelection,
    selectAll,
    clearSelection,
  } = useBulkSelection(deals || []);

  const bulkDeleteMutation = useMutation({
    mutationFn: async (dealIds: string[]) => {
      const { error } = await supabase
        .from("deals")
        .delete()
        .in("id", dealIds);
      
      if (error) throw error;
    },
    onSuccess: (_, dealIds) => {
      toast({
        title: "Deals deleted",
        description: `${dealIds.length} deal${dealIds.length > 1 ? 's' : ''} deleted successfully`,
      });
      clearSelection();
      queryClient.invalidateQueries({ queryKey: ["deals"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error deleting deals",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase.from("deals").delete().eq("id", id);
      
      if (error) throw error;
      
      toast({
        title: "Deal deleted",
        description: "The deal has been successfully deleted.",
      });
      
      refetch();
    } catch (error) {
      console.error("Error deleting deal:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete the deal. Please try again.",
      });
    }
  };

  const handleBulkDelete = () => {
    setShowDeleteConfirmation(true);
  };

  const confirmBulkDelete = () => {
    const selectedDealIds = selectedItems.map(deal => deal.id);
    bulkDeleteMutation.mutate(selectedDealIds);
    setShowDeleteConfirmation(false);
  };

  const getStatusColor = (status: string | null) => {
    switch (status) {
      case "Lead In":
        return "bg-blue-500 text-white";
      case "In Progress":
        return "bg-yellow-500 text-black";
      case "Delivered":
        return "bg-green-500 text-white";
      case "Closed - Paid":
        return "bg-purple-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  const handleColumnChange = (newColumns: Column[]) => {
    setColumns(newColumns);
  };

  const visibleColumns = columns.filter(col => col.visible);

  const bulkActions = [
    {
      id: "delete",
      label: "Delete",
      icon: <Trash2 className="h-4 w-4" />,
      variant: "destructive" as const,
      onClick: handleBulkDelete,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-semibold">Deals</h1>
        <Button onClick={() => navigate("/deals/add")}>
          <Plus className="h-4 w-4 mr-2" /> Add Deal
        </Button>
      </div>

      <div className="flex justify-end mb-2">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setIsColumnManagerOpen(true)}
              >
                <ColumnsIcon className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Manage Columns</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      {isLoading ? (
        <div className="text-center py-8">Loading deals...</div>
      ) : error ? (
        <div className="text-center py-8 text-red-500">Error loading deals. Please try again.</div>
      ) : deals && deals.length > 0 ? (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                {columns.find(c => c.id === "select" && c.visible) && (
                  <TableHead className="w-12">
                    <BulkActionHeader
                      selectedCount={selectedCount}
                      totalCount={deals.length}
                      onSelectAll={selectAll}
                      onClearSelection={clearSelection}
                    />
                  </TableHead>
                )}
                {columns.find(c => c.id === "title" && c.visible) && (
                  <TableHead>Deal Title</TableHead>
                )}
                {columns.find(c => c.id === "client" && c.visible) && (
                  <TableHead>Client</TableHead>
                )}
                {columns.find(c => c.id === "projectType" && c.visible) && (
                  <TableHead>Project Type</TableHead>
                )}
                {columns.find(c => c.id === "status" && c.visible) && (
                  <TableHead>Status</TableHead>
                )}
                {columns.find(c => c.id === "price" && c.visible) && (
                  <TableHead>Quoted Price</TableHead>
                )}
                {columns.find(c => c.id === "delivery" && c.visible) && (
                  <TableHead>Expected Delivery</TableHead>
                )}
                {columns.find(c => c.id === "actions" && c.visible) && (
                  <TableHead className="text-right">Actions</TableHead>
                )}
              </TableRow>
            </TableHeader>
            <TableBody>
              {deals.map((deal: any) => (
                <TableRow key={deal.id}>
                  {columns.find(c => c.id === "select" && c.visible) && (
                    <TableCell>
                      <Checkbox
                        checked={isSelected(deal.id)}
                        onCheckedChange={() => toggleSelection(deal.id)}
                        aria-label={`Select deal ${deal.name}`}
                      />
                    </TableCell>
                  )}
                  {columns.find(c => c.id === "title" && c.visible) && (
                    <TableCell className="font-medium">{deal.name}</TableCell>
                  )}
                  {columns.find(c => c.id === "client" && c.visible) && (
                    <TableCell>
                      {deal.contacts?.business_name || 
                       `${deal.contacts?.first_name || ''} ${deal.contacts?.last_name || ''}`}
                    </TableCell>
                  )}
                  {columns.find(c => c.id === "projectType" && c.visible) && (
                    <TableCell>{deal.project_type || "N/A"}</TableCell>
                  )}
                  {columns.find(c => c.id === "status" && c.visible) && (
                    <TableCell>
                      {deal.status && (
                        <Badge variant="outline" className={getStatusColor(deal.status)}>
                          {deal.status}
                        </Badge>
                      )}
                    </TableCell>
                  )}
                  {columns.find(c => c.id === "price" && c.visible) && (
                    <TableCell>
                      {deal.amount ? `$${deal.amount.toLocaleString()}` : "N/A"}
                    </TableCell>
                  )}
                  {columns.find(c => c.id === "delivery" && c.visible) && (
                    <TableCell>
                      {deal.expected_delivery_date 
                        ? format(new Date(deal.expected_delivery_date), "MMM d, yyyy")
                        : "N/A"
                      }
                    </TableCell>
                  )}
                  {columns.find(c => c.id === "actions" && c.visible) && (
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => navigate(`/deals/${deal.id}`)}
                          className="flex items-center gap-1"
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => navigate(`/deals/edit/${deal.id}`)}
                          className="flex items-center gap-1"
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleDelete(deal.id)}
                          className="flex items-center gap-1 text-red-600"
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className="text-center py-8">
          No deals found. Create your first deal by clicking "Add Deal".
        </div>
      )}

      <BulkActionBar
        selectedCount={selectedCount}
        onClearSelection={clearSelection}
        actions={bulkActions}
      />

      <ConfirmationDialog
        open={showDeleteConfirmation}
        onOpenChange={setShowDeleteConfirmation}
        title="Delete Deals"
        description={`Are you sure you want to delete ${selectedCount} deal${selectedCount > 1 ? 's' : ''}? This action cannot be undone.`}
        confirmLabel="Delete"
        confirmVariant="destructive"
        onConfirm={confirmBulkDelete}
        isLoading={bulkDeleteMutation.isPending}
      />

      <ColumnManager
        columns={columns}
        open={isColumnManagerOpen}
        onOpenChange={setIsColumnManagerOpen}
        onColumnsChange={handleColumnChange}
      />
    </div>
  );
}
