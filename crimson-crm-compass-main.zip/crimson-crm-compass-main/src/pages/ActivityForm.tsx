
import { ActivityForm } from "@/components/activities/ActivityForm";
import { useParams, useSearchParams } from "react-router-dom";

const ActivityFormPage = () => {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  
  const relatedTo = searchParams.get('relatedTo') ? {
    type: searchParams.get('relatedType') || '',
    id: searchParams.get('relatedTo') || '',
    name: searchParams.get('relatedName') || ''
  } : undefined;

  return <ActivityForm activityId={id} relatedTo={relatedTo} />;
};

export default ActivityFormPage;
