
import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Settings, Sparkles, AlertTriangle, ArrowLeft } from "lucide-react";
import { FieldEditorSidebar } from "@/components/fields/editor/FieldEditorSidebar";
import { FieldEditorMain } from "@/components/fields/editor/FieldEditorMain";
import { FieldConfigurationPanel } from "@/components/fields/editor/FieldConfigurationPanel";
import { FieldDragDropProvider } from "@/components/fields/editor/DragDropContext";
import { useFieldGroups } from "@/hooks/useFieldGroups";

// Supported modules for the advanced field editor
const SUPPORTED_MODULES = ["lead", "deal", "contact", "task"] as const;
type SupportedModule = typeof SUPPORTED_MODULES[number];

function isSupportedModule(module: string): module is SupportedModule {
  return SUPPORTED_MODULES.includes(module as SupportedModule);
}

export default function AdvancedFieldEditor() {
  const { module } = useParams<{ module: string }>();
  const navigate = useNavigate();
  const [selectedField, setSelectedField] = useState<string | null>(null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeView, setActiveView] = useState<"form" | "list">("form");

  // Field groups management
  const { upsertGroup } = useFieldGroups(module || "");

  // Validate module parameter
  if (!module) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-50">
        <Card className="w-96">
          <CardHeader>
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-600" />
              <CardTitle>Module Required</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">
              Please specify a module to edit fields for.
            </p>
            <Button onClick={() => navigate("/module-editor")} className="w-full">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Module Editor
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!isSupportedModule(module)) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-50">
        <Card className="w-96">
          <CardHeader>
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-600" />
              <CardTitle>Unsupported Module</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">
              The module "{module}" is not supported by the advanced field editor.
            </p>
            <p className="text-sm text-muted-foreground">
              Supported modules: {SUPPORTED_MODULES.join(", ")}
            </p>
            <Button onClick={() => navigate("/module-editor")} className="w-full">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Module Editor
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleCreateGroup = (group: {
    id: string;
    label: string;
    description?: string;
    defaultExpanded: boolean;
  }) => {
    upsertGroup({
      id: group.id,
      label: group.label,
      description: group.description,
      default_expanded: group.defaultExpanded,
      group_order: 0 // Will be handled by the hook
    });
  };

  const handleFieldCreated = (fieldId: string) => {
    setSelectedField(fieldId);
  };

  return (
    <FieldDragDropProvider module={module}>
      <div className="h-screen flex bg-gray-50">
        {/* Enhanced Sidebar */}
        <FieldEditorSidebar
          module={module}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          selectedField={selectedField}
          onFieldSelect={setSelectedField}
          onCreateGroup={handleCreateGroup}
        />

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Simplified Header */}
          <div className="bg-white border-b px-6 py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div>
                  <h1 className="text-lg font-semibold">Advanced Field Editor</h1>
                  <p className="text-sm text-muted-foreground">
                    {module.charAt(0).toUpperCase() + module.slice(1)} Module
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Editor Content */}
          <div className="flex-1 flex overflow-hidden">
            {/* Main Editor */}
            <FieldEditorMain
              module={module}
              selectedField={selectedField}
              onFieldSelect={setSelectedField}
              activeView={activeView}
              onViewChange={setActiveView}
            />

            {/* Configuration Panel */}
            {selectedField && (
              <>
                <Separator orientation="vertical" />
                <div className="w-80 bg-white border-l overflow-auto">
                  <FieldConfigurationPanel
                    module={module}
                    fieldId={selectedField}
                    onClose={() => setSelectedField(null)}
                  />
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </FieldDragDropProvider>
  );
}
