
import { useParams, useNavigate } from "react-router-dom";
import { ProposalEditor } from "@/components/proposals/ProposalEditor";

export default function ProposalEdit() {
  const { id } = useParams();
  const navigate = useNavigate();

  const handleSave = () => {
    navigate('/proposals');
  };

  return <ProposalEditor proposalId={id} onSave={handleSave} />;
}
