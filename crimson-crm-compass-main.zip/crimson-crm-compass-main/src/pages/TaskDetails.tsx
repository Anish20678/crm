
import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Task } from "@/lib/types";
import { format } from "date-fns";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import {
  ArrowLeft,
  Edit,
  Trash2,
  CheckSquare,
  Clock,
  Calendar,
  AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";

export default function TaskDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isCompleteDialogOpen, setIsCompleteDialogOpen] = useState(false);

  const { data: task, isLoading } = useQuery({
    queryKey: ["task", id],
    queryFn: async () => {
      if (!id) throw new Error("Task ID is required");

      // Use type casting to handle the Supabase schema mismatch
      const { data, error } = await supabase
        .from("tasks" as any)
        .select("*")
        .eq("id", id)
        .single();

      if (error) {
        toast({
          title: "Error loading task",
          description: error.message,
          variant: "destructive",
        });
        throw error;
      }

      return data as unknown as Task;
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async () => {
      if (!id) throw new Error("Task ID is required");

      // Use type casting to handle the Supabase schema mismatch
      const { error } = await supabase.from("tasks" as any).delete().eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Task deleted",
        description: "Task has been deleted successfully",
      });
      navigate("/tasks");
    },
    onError: (error: any) => {
      toast({
        title: "Error deleting task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const completeTaskMutation = useMutation({
    mutationFn: async () => {
      if (!id) throw new Error("Task ID is required");

      // Use type casting to handle the Supabase schema mismatch
      const { error } = await supabase
        .from("tasks" as any)
        .update({ status: "completed" })
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Task completed",
        description: "Task has been marked as completed",
      });
      setIsCompleteDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["task", id] });
    },
    onError: (error: any) => {
      toast({
        title: "Error completing task",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function handleEditTask() {
    navigate(`/tasks/edit/${id}`);
  }

  function handleDeleteTask() {
    setIsDeleteDialogOpen(true);
  }

  function handleCompleteTask() {
    setIsCompleteDialogOpen(true);
  }

  const formatDate = (dateString: string | undefined) => {
    if (!dateString) return "—";
    try {
      return format(new Date(dateString), "PPP");
    } catch (error) {
      return dateString;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500 text-white";
      case "medium":
        return "bg-yellow-500 text-black";
      case "low":
        return "bg-green-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "todo":
        return "bg-blue-500 text-white";
      case "in_progress":
        return "bg-yellow-500 text-black";
      case "completed":
        return "bg-green-500 text-white";
      case "cancelled":
        return "bg-gray-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div>Loading task details...</div>
      </div>
    );
  }

  if (!task) {
    return (
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <Button variant="ghost" onClick={() => navigate("/tasks")}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Tasks
          </Button>
        </div>
        <div className="flex flex-col items-center justify-center min-h-[40vh]">
          <h2 className="text-xl font-semibold mb-2">Task not found</h2>
          <p className="text-muted-foreground mb-4">
            The task you're looking for doesn't exist or has been removed.
          </p>
          <Button onClick={() => navigate("/tasks")}>Return to Task List</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Back button and header */}
      <div className="flex items-center space-x-2">
        <Button variant="ghost" onClick={() => navigate("/tasks")}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Tasks
        </Button>
      </div>

      {/* Task header */}
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-semibold">{task.title}</h1>
            <Badge variant="outline" className={getStatusColor(task.status)}>
              {task.status.charAt(0).toUpperCase() + task.status.slice(1)}
            </Badge>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" onClick={handleEditTask}>
            <Edit className="mr-2 h-4 w-4" />
            Edit
          </Button>

          {task.status !== "completed" && (
            <Button size="sm" onClick={handleCompleteTask}>
              <CheckSquare className="mr-2 h-4 w-4" />
              Complete
            </Button>
          )}

          <Button variant="destructive" size="sm" onClick={handleDeleteTask}>
            <Trash2 className="mr-2 h-4 w-4" />
            Delete
          </Button>
        </div>
      </div>

      {/* Task information */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-1">
                  Priority
                </h3>
                <Badge
                  variant="outline"
                  className={getPriorityColor(task.priority)}
                >
                  {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                </Badge>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-1">
                  Due Date
                </h3>
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                  <span>{formatDate(task.due_date)}</span>
                </div>
              </div>
            </div>

            {task.assigned_to && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-1">
                  Assigned To
                </h3>
                <p>{task.assigned_to}</p>
              </div>
            )}

            {task.description && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-1">
                  Description
                </h3>
                <p className="whitespace-pre-wrap">{task.description}</p>
              </div>
            )}

            <Separator />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {task.related_to_type && task.related_to_id && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">
                    Related To
                  </h3>
                  <p>
                    {task.related_to_type.charAt(0).toUpperCase() +
                      task.related_to_type.slice(1)}
                  </p>
                </div>
              )}

              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-1">
                  Created On
                </h3>
                <p>{formatDate(task.created_at)}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Due date warning */}
      {task.status !== "completed" &&
        task.due_date &&
        new Date(task.due_date) < new Date() && (
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
            <div className="flex">
              <AlertTriangle className="h-6 w-6 text-yellow-400 mr-3" />
              <div>
                <p className="text-sm text-yellow-700">
                  This task is overdue. The due date was{" "}
                  {formatDate(task.due_date)}.
                </p>
              </div>
            </div>
          </div>
        )}

      {/* Delete confirmation dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Task</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{task.title}"? This action cannot
              be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => deleteTaskMutation.mutate()}
              disabled={deleteTaskMutation.isPending}
            >
              {deleteTaskMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Complete confirmation dialog */}
      <Dialog
        open={isCompleteDialogOpen}
        onOpenChange={setIsCompleteDialogOpen}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Complete Task</DialogTitle>
            <DialogDescription>
              Mark "{task.title}" as completed?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsCompleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="default"
              onClick={() => completeTaskMutation.mutate()}
              disabled={completeTaskMutation.isPending}
            >
              {completeTaskMutation.isPending
                ? "Marking as completed..."
                : "Complete Task"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
