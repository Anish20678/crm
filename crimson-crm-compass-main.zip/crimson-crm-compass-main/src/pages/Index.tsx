
import { DashboardMetricsComponent } from "@/components/dashboard/DashboardMetrics";
import { AIInsights } from "@/components/dashboard/AIInsights";
import { SalesChart } from "@/components/dashboard/SalesChart";
import { ActivityList } from "@/components/activities/ActivityList";
import { useDashboardMetrics, useAIInsights, useSalesAnalytics } from "@/hooks/useDashboardData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  Users, 
  DollarSign, 
  Target,
  Calendar,
  ArrowUpRight,
  BarChart3,
  Brain
} from "lucide-react";
import { Link } from "react-router-dom";

const Index = () => {
  const { data: metrics, isLoading: metricsLoading } = useDashboardMetrics();
  const { data: insights, isLoading: insightsLoading } = useAIInsights();
  const { data: salesData, isLoading: salesLoading } = useSalesAnalytics();

  const quickActions = [
    {
      title: "Add New Lead",
      description: "Capture a new potential customer",
      href: "/leads/add",
      icon: Users,
      color: "bg-blue-500 hover:bg-blue-600"
    },
    {
      title: "Create Deal",
      description: "Start tracking a new opportunity",
      href: "/deals/add",
      icon: DollarSign,
      color: "bg-green-500 hover:bg-green-600"
    },
    {
      title: "Add Task",
      description: "Create a new task or reminder",
      href: "/tasks/add",
      icon: Target,
      color: "bg-purple-500 hover:bg-purple-600"
    },
    {
      title: "Schedule Follow-up",
      description: "Plan your next customer interaction",
      href: "/contacts/add",
      icon: Calendar,
      color: "bg-orange-500 hover:bg-orange-600"
    }
  ];

  const todaysHighlights = [
    {
      title: "High Priority Follow-ups",
      value: metrics?.upcomingFollowUps || 0,
      change: "+12%",
      trend: "up",
      action: "View All",
      href: "/contacts"
    },
    {
      title: "Overdue Tasks",
      value: metrics?.overdueTasks || 0,
      change: "-8%",
      trend: "down",
      action: "Complete",
      href: "/tasks"
    },
    {
      title: "Active Deals",
      value: metrics?.activeDeals || 0,
      change: "+23%",
      trend: "up",
      action: "Review",
      href: "/deals"
    }
  ];

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            CRM Dashboard
          </h1>
          <p className="text-lg text-gray-600 mt-2">
            Welcome back! Here's what's happening with your business today.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="outline" className="px-3 py-1">
            <Brain className="h-4 w-4 mr-1" />
            AI Powered
          </Badge>
          <Button asChild>
            <Link to="/reports">
              <BarChart3 className="h-4 w-4 mr-2" />
              View Reports
            </Link>
          </Button>
        </div>
      </div>

      {/* Key Metrics Dashboard */}
      <DashboardMetricsComponent metrics={metrics || {
        totalContacts: 0,
        totalDeals: 0,
        totalRevenue: 0,
        activeDeals: 0,
        conversionRate: 0,
        avgDealSize: 0,
        overdueTasks: 0,
        upcomingFollowUps: 0
      }} isLoading={metricsLoading} />

      {/* Today's Highlights */}
      <div className="grid gap-6 md:grid-cols-3">
        {todaysHighlights.map((highlight, index) => (
          <Card key={index} className="relative overflow-hidden">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  {highlight.title}
                </CardTitle>
                <div className={`flex items-center text-xs ${
                  highlight.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  <TrendingUp className={`h-3 w-3 mr-1 ${
                    highlight.trend === 'down' ? 'rotate-180' : ''
                  }`} />
                  {highlight.change}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-3xl font-bold">{highlight.value}</div>
                <Button variant="outline" size="sm" asChild>
                  <Link to={highlight.href}>
                    {highlight.action}
                    <ArrowUpRight className="h-3 w-3 ml-1" />
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid gap-8 lg:grid-cols-3">
        {/* Left Column - Charts and Analytics */}
        <div className="lg:col-span-2 space-y-6">
          {/* Sales Performance Chart */}
          <SalesChart 
            data={salesData || []} 
            title="Sales Performance Trends" 
            type="line"
            isLoading={salesLoading}
          />
          
          {/* Revenue Analytics */}
          <SalesChart 
            data={salesData || []} 
            title="Monthly Revenue Breakdown" 
            type="bar"
            isLoading={salesLoading}
          />
        </div>

        {/* Right Column - Insights and Activities */}
        <div className="space-y-6">
          {/* AI Insights */}
          <AIInsights insights={insights || []} isLoading={insightsLoading} />
          
          {/* Recent Activities */}
          <ActivityList />
        </div>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-blue-600" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {quickActions.map((action, index) => {
              const Icon = action.icon;
              return (
                <Button
                  key={index}
                  asChild
                  variant="outline"
                  className="h-auto p-4 flex flex-col items-center space-y-2 hover:shadow-md transition-all"
                >
                  <Link to={action.href}>
                    <div className={`p-3 rounded-full ${action.color} text-white`}>
                      <Icon className="h-6 w-6" />
                    </div>
                    <div className="text-center">
                      <div className="font-medium">{action.title}</div>
                      <div className="text-xs text-gray-500">{action.description}</div>
                    </div>
                  </Link>
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Index;
