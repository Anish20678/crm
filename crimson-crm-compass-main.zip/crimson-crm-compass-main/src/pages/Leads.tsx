
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Contact } from "@/lib/types";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Plus, ColumnsIcon } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

// Import our component files
import { LeadList } from "@/components/leads/LeadList";
import { DealForm, DealFormValues } from "@/components/contacts/DealForm";

export default function Leads() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDealDialogOpen, setIsDealDialogOpen] = useState(false);
  const [currentContact, setCurrentContact] = useState<Contact | null>(null);
  const [isColumnManagerOpen, setIsColumnManagerOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: contacts = [], isLoading } = useQuery({
    queryKey: ["contacts"],
    queryFn: async () => {
      let query = supabase
        .from("contacts")
        .select("*")
        .eq("is_client", false)
        .order("created_at", { ascending: false });
      
      const { data, error } = await query;
      
      if (error) {
        toast({
          title: "Error loading leads",
          description: error.message,
          variant: "destructive",
        });
        throw error;
      }
      
      return data as Contact[];
    },
    enabled: !!user,
  });

  const deleteContactMutation = useMutation({
    mutationFn: async () => {
      if (!currentContact) throw new Error("No lead selected");
      
      const { error } = await supabase
        .from("contacts")
        .delete()
        .eq("id", currentContact.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Lead deleted",
        description: "Your lead has been deleted successfully",
      });
      setIsDeleteDialogOpen(false);
      setCurrentContact(null);
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error deleting lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const bulkDeleteMutation = useMutation({
    mutationFn: async (leads: Contact[]) => {
      const leadIds = leads.map(lead => lead.id);
      
      const { error } = await supabase
        .from("contacts")
        .delete()
        .in("id", leadIds);
      
      if (error) throw error;
    },
    onSuccess: (_, leads) => {
      toast({
        title: "Leads deleted",
        description: `${leads.length} lead${leads.length > 1 ? 's' : ''} deleted successfully`,
      });
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error deleting leads",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createDealMutation = useMutation({
    mutationFn: async (dealData: DealFormValues) => {
      if (!currentContact) throw new Error("No lead selected");
      
      // First update the contact to mark as client
      await supabase
        .from("contacts")
        .update({ is_client: true })
        .eq("id", currentContact.id);
      
      // Generate deal name if not provided
      if (!dealData.name || dealData.name.trim() === "") {
        const currentDate = new Date();
        const month = format(currentDate, "MMMM");
        const year = format(currentDate, "yyyy");
        
        if (currentContact.business_name) {
          dealData.name = `${month} ${year} - ${currentContact.business_name}`;
        } else {
          const fullName = `${currentContact.first_name} ${currentContact.last_name || ""}`.trim();
          dealData.name = `${month} ${year} - ${fullName}`;
        }
      }
      
      // Create the deal - Parse amount to number or null if empty
      const dealToInsert = {
        contact_id: currentContact.id,
        name: dealData.name,
        amount: dealData.amount ? parseFloat(dealData.amount) : null,
        status: dealData.status || 'new',
      };
      
      const { data, error } = await supabase
        .from("deals")
        .insert(dealToInsert)
        .select();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      toast({
        title: "Deal created",
        description: "New deal has been created successfully",
      });
      setIsDealDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
      
      // Navigate to deal detail page if available
      if (data && data[0]) {
        navigate(`/deals/${data[0].id}`);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error creating deal",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const bulkCreateDealsMutation = useMutation({
    mutationFn: async (leads: Contact[]) => {
      const currentDate = new Date();
      const month = format(currentDate, "MMMM");
      const year = format(currentDate, "yyyy");
      
      // Update all contacts to mark as clients
      const contactIds = leads.map(lead => lead.id);
      await supabase
        .from("contacts")
        .update({ is_client: true })
        .in("id", contactIds);
      
      // Create deals for all leads
      const dealsToInsert = leads.map(lead => ({
        contact_id: lead.id,
        name: lead.business_name 
          ? `${month} ${year} - ${lead.business_name}`
          : `${month} ${year} - ${lead.first_name} ${lead.last_name || ""}`.trim(),
        status: 'new',
      }));
      
      const { data, error } = await supabase
        .from("deals")
        .insert(dealsToInsert)
        .select();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (_, leads) => {
      toast({
        title: "Deals created",
        description: `${leads.length} deal${leads.length > 1 ? 's' : ''} created successfully`,
      });
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error creating deals",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function handleEditLead(contact: Contact) {
    navigate(`/leads/edit/${contact.id}`);
  }

  function handleAddLead() {
    navigate("/leads/add");
  }

  function handleDeleteLead() {
    deleteContactMutation.mutate();
  }

  function handleCreateDeal(contact: Contact) {
    setCurrentContact(contact);
    setIsDealDialogOpen(true);
  }

  function onDealSubmit(data: DealFormValues) {
    createDealMutation.mutate(data);
  }

  const handleBulkDelete = async (leads: Contact[]) => {
    await bulkDeleteMutation.mutateAsync(leads);
  };

  const handleBulkCreateDeals = async (leads: Contact[]) => {
    await bulkCreateDealsMutation.mutateAsync(leads);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-semibold">Leads</h1>
        <Button onClick={handleAddLead}>
          <Plus className="h-4 w-4 mr-2" /> Add Lead
        </Button>
      </div>

      <div className="flex justify-end mb-2">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setIsColumnManagerOpen(true)}
              >
                <ColumnsIcon className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Manage Columns</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      <LeadList 
        leads={contacts}
        isLoading={isLoading}
        onEdit={handleEditLead}
        onDelete={(contact) => {
          setCurrentContact(contact);
          setIsDeleteDialogOpen(true);
        }}
        onBulkDelete={handleBulkDelete}
        onCreateDeal={handleCreateDeal}
        onBulkCreateDeals={handleBulkCreateDeals}
        isColumnManagerOpen={isColumnManagerOpen}
        onColumnManagerOpenChange={setIsColumnManagerOpen}
      />

      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Lead</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete{" "}
              {currentContact ? `${currentContact.first_name} ${currentContact.last_name || ""}` : ""}?
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteLead} disabled={deleteContactMutation.isPending}>
              {deleteContactMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isDealDialogOpen} onOpenChange={setIsDealDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Convert to Deal</DialogTitle>
            <DialogDescription>
              Create a new deal for{" "}
              {currentContact ? `${currentContact.first_name} ${currentContact.last_name || ""}` : ""}
            </DialogDescription>
          </DialogHeader>
          <DealForm 
            onSubmit={onDealSubmit} 
            isSubmitting={createDealMutation.isPending} 
            leadName={currentContact ? `${currentContact.first_name} ${currentContact.last_name || ""}` : ""}
            defaultDealName={
              currentContact ? 
                `${format(new Date(), "MMMM yyyy")} - ${currentContact.business_name || `${currentContact.first_name} ${currentContact.last_name || ""}`}`.trim() : 
                ""
            }
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
